import test from 'node:test';
import assert from 'node:assert/strict';
import { Battle } from '../src/engine.js';
import { generateStage, validateStage, normalizeStage, offsetToAxial } from '../src/maps.js';
import { V2_MAPS, V2_PLAYLIST_ORDER } from '../src/v2-reference.js';
import { MASTERS, SUMMONS, masterStats, LIMITS } from '../src/data.js';
import { key, distance } from '../src/hex.js';

function arena(){return {id:1,name:'Test',gridWidth:9,gridHeight:7,playerMasterStart:{q:1,r:3},enemyMasterStart:{q:7,r:3,classId:'duke',level:2},manaStones:[{q:2,r:3}],tiles:Array.from({length:63},(_,i)=>({q:i%9,r:Math.floor(i/9),terrain:'grass',elevation:0}))};}

test('video preparation screen: Adol Lv1 and Valdarts Lv2',()=>{
  const b=new Battle(generateStage(0),'adol'),a=b.units[0],e=b.units[1];
  assert.deepEqual([a.maxMana,a.attack,a.defense,a.magicAttack,a.magicDefense,a.speed,a.move],[60,10,9,5,7,11,4]);
  assert.deepEqual([e.maxMana,e.attack,e.defense,e.magicAttack,e.magicDefense,e.speed,e.move],[62,4,3,7,4,11,3]);
  assert.equal(e.name,'Valdarts');assert.deepEqual(b.mana,[60,62]);
});
test('Lake source coordinates, ownership and elevations match independent reference observations',()=>{
  const s=generateStage(0);assert.equal(s.sourceIndex,1);assert.equal(s.name,'출렁이는 호수');
  assert.deepEqual([s.playerMasterStart.q,s.playerMasterStart.r],[17,15]);
  assert.deepEqual([s.enemyMasterStart.q,s.enemyMasterStart.r],[-3,16]);
  const expected=[[21,14,null],[25,14,0],[18,16,null],[22,17,0],[25,17,0],[28,17,0]];
  assert.deepEqual(s.manaStones,expected.map(([x,y,owner])=>({...offsetToAxial(x,y),owner})));
  for(const stone of s.manaStones)assert.equal(s.tiles.find(t=>key(t)===key(stone)).elevation,4);
  assert.equal(new Battle(s).owned(0),4);assert.equal(s.startMinutes,780);
});
test('Hill retains six neutral stones, original starts, and no generated corridor',()=>{
  const s=generateStage(2);assert.equal(s.sourceIndex,0);
  assert.deepEqual([s.playerMasterStart.sourceX,s.playerMasterStart.sourceY],[13,4]);
  assert.deepEqual([s.enemyMasterStart.sourceX,s.enemyMasterStart.sourceY],[20,22]);
  assert.deepEqual(s.manaStones,[[11,1],[14,1],[11,4],[15,4],[11,7],[14,7]].map(([x,y])=>({...offsetToAxial(x,y),owner:null})));
  assert.equal(s.generatedLayout,false);assert.equal(s.enemyMasterStart.classId,'paladin');
});
test('all 30 maps retain every source height/type/secondary height/flag, with independent instances',()=>{
  assert.equal(new Set(V2_PLAYLIST_ORDER).size,30);
  for(let i=0;i<30;i++){
    const s=validateStage(generateStage(i)),src=V2_MAPS[s.sourceIndex];assert.equal(s.tiles.length,1024);
    s.tiles.forEach((t,n)=>{assert.deepEqual([t.elevation,t.terrainCode,t.secondaryHeight,t.sourceFlags],src.cells.slice(n*4,n*4+4));assert.deepEqual({q:t.q,r:t.r},offsetToAxial(n%32,Math.floor(n/32)));});
    assert.equal(s.manaStones.length,s.tiles.filter(t=>t.terrainCode>=12&&t.terrainCode<=15).length);
    assert.equal(s.enemyAllies,undefined);assert.deepEqual(s.portals,[]);assert.equal(normalizeStage(s).id,i+1);
  }
  const a=generateStage(0);a.tiles[0].elevation=31;assert.notEqual(generateStage(0).tiles[0].elevation,31);
  const last=generateStage(29);assert.equal(last.enemyMasterStart.classId,'beast');assert.equal(last.enemyMasterStart.level,30);
});
test('all 27 master growth tables and 24 natials are retained without GDD aliases',()=>{
  assert.equal(MASTERS.length,27);assert.equal(SUMMONS.length,24);
  for(const m of MASTERS){assert.equal(m.levels.length,40);assert.equal(masterStats(m,40).maxMana,200);}
  for(const n of SUMMONS){assert.equal(n.hp,10);assert.equal(n.levels.length,3);}
  assert.equal(MASTERS.find(m=>m.id==='witch').speed,8);
  assert.equal(SUMMONS.find(n=>n.id==='regna-croxe').element,'wind');
});
test('observed four starter costs, upkeep and basic stats',()=>{
  for(const [id,cost,upkeep,stats] of [
    ['fa-rancell',16,2,[8,6,3,7,11,5]],['reque',16,2,[9,5,2,7,13,5]],
    ['hepitus',24,3,[10,8,4,9,7,6]],['guene-foss',32,4,[5,5,8,9,10,6]]]){
    const n=SUMMONS.find(s=>s.id===id);assert.deepEqual([n.cost,n.upkeep],[cost,upkeep]);
    assert.deepEqual([n.attack,n.defense,n.magicAttack,n.magicDefense,n.speed,n.move],stats);
  }
});
test('summoning is adjacent, costs 32 for Guene-Foss and rejects occupied/distant cells',()=>{
  const b=new Battle(arena(),'adol');assert.equal(b.summonTiles(b.active,'guene-foss').length,6);
  assert.ok(b.summonTiles(b.active,'guene-foss').every(t=>distance(t,b.active)===1));
  assert.equal(b.summon('guene-foss',{q:3,r:3}),false);assert.equal(b.summon('guene-foss',b.active),false);
  assert.equal(b.summon('guene-foss',{q:2,r:3},false),true);assert.equal(b.mana[0],28);assert.equal(b.upkeep(0),4);
  assert.equal(b.owned(0),0); // A newly summoned unit has not finished an action yet.
});
test('flight crosses water but cannot land or summon there; no void or wall landing',()=>{
  const b=new Battle(arena());b.tiles.get('2,3').terrain='deep_water';
  const u=b.addUnit('guene-foss',0,{q:1,r:2});
  assert.equal(b.terrainCost(u)(b.tiles.get('2,3')),1);assert.equal(b.canLand(u,b.tiles.get('2,3')),false);
  assert.equal(b.reachable(u).dist.has('2,3'),false);assert.equal(b.reachable(u).dist.has('3,3'),true);
  assert.ok(!b.summonTiles(b.active,'guene-foss').some(t=>key(t)==='2,3'));
  for(const terrain of ['void','wall']){b.tiles.get('2,3').terrain=terrain;assert.equal(b.canLand(u,b.tiles.get('2,3')),false);}
});
test('Guene-Foss has melee attack and separate range-4, cost-4 obstacle-independent Blitz',()=>{
  const b=new Battle(arena()),u=b.addUnit('guene-foss',0,{q:3,r:3}),t=b.units[1];
  b.activeId=u.id;b.tiles.get('5,3').terrain='wall';
  assert.equal(b.canAttack(u,t),false);assert.equal(b.availableSpells()[0].cost,4);
  assert.ok(b.spellTargets(u,'v2-blitz').includes(t));
  t.q=8;assert.ok(!b.spellTargets(u,'v2-blitz').includes(t));
});
test('clock economy uses master magic power and does not run on each master action',()=>{
  const b=new Battle(arena());b.mana=[20,20];b.wait();assert.deepEqual(b.mana,[20,20]);
  b.settleClock(60);assert.deepEqual(b.mana,[30,34]);
  const c=new Battle(arena(),'witch');c.addUnit('guene-foss',0,{q:2,r:2});c.mana[0]=28;c.time=48;c.settleClock(60);assert.equal(c.mana[0],38);
});
test('restore v4 preserves source tiles, initial ownership and deterministic continuation',()=>{
  const b=new Battle(generateStage(0),'adol');b.mana[0]=30;
  const r=Battle.restore(JSON.parse(JSON.stringify(b.serialize())));assert.deepEqual(r.serialize(),b.serialize());
  for(let i=0;i<12;i++){b.wait();r.wait();assert.deepEqual(r.serialize(),b.serialize());}
  assert.throws(()=>Battle.restore({...b.serialize(),version:3}));
});
test('source-height maps normalize without changing water stones or filling axial gaps',()=>{
  const s=generateStage(0),r=normalizeStage(s);assert.deepEqual(r.tiles,s.tiles);
  const invalid=arena();invalid.tiles[0].elevation=32;assert.throws(()=>validateStage(invalid));
  const duplicated=arena();duplicated.tiles.push(duplicated.tiles[0]);assert.throws(()=>validateStage(duplicated));
});
test('AI produces legal scheduled actions on every fixed map (bounded smoke, not balance proof)',()=>{
  for(let i=0;i<30;i++){
    const b=new Battle(generateStage(i),'adol');
    for(let action=0;action<18&&b.winner===null;action++){
      const before=b.time;b.aiTurn();assert.ok(b.time>=before);assert.ok(b.active||b.winner!==null);
      assert.equal(new Set(b.living.map(key)).size,b.living.length);
      assert.ok(b.living.every(u=>b.canLand(u,b.tiles.get(key(u)))),'stage '+(i+1));
      assert.ok(b.mana.every(m=>m>=0&&m<=LIMITS.maxMana));
    }
  }
});
