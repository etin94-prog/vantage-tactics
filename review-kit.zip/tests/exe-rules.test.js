import test from 'node:test';
import assert from 'node:assert/strict';
import { Battle } from '../src/engine.js';
import { actionMinutes, originalDamage, originalHealing, originalStatusMinutes, originalMoveCost, originalCanLand, originalTerrainPercent, originalInRange, ruleHeight, ruleTerrain } from '../src/rules.js';
import { targetArea } from '../src/target-area.js';
import { SPELLS } from '../src/spells.js';
import { key } from '../src/hex.js';

function arena(){return {id:1,name:'Static regression',gridWidth:11,gridHeight:7,playerMasterStart:{q:1,r:3},enemyMasterStart:{q:9,r:3,classId:'duke'},manaStones:[{q:2,r:3}],tiles:Array.from({length:77},(_,i)=>({q:i%11,r:Math.floor(i/11),terrain:'grass',elevation:0}))};}

test('EXE OA fixed-point rounding, including endpoints and non-anchor speed',()=>{
  assert.deepEqual([actionMinutes(0),actionMinutes(7),actionMinutes(12),actionMinutes(20)],[56,36,26,16]);
  assert.equal(actionMinutes(12,25,true),62);
});
test('EXE damage thresholds allow zero and apply terrain before rounding',()=>{
  assert.deepEqual([4,8,13,20,23,39].map(n=>originalDamage(n)),[0,0,1,2,4,10]);
  assert.equal(originalDamage(23,70),3);assert.equal(originalDamage(23,80),3);
  assert.equal(originalHealing(8,0),2);assert.equal(originalHealing(15,0),3);
  assert.deepEqual([0,10,20,30].map(n=>originalStatusMinutes(n,0)),[10,60,180,380]);
});
test('standing place: grass, water depth and all stone depths retain numeric defense',()=>{
  assert.deepEqual([0,2,7,8,9,12,13,14,15].map(terrainCode=>originalTerrainPercent({terrainCode})),[100,80,90,80,75,70,70,70,70]);
});
test('standing place: marsh, desert, snow and floating footing differ by movement type',()=>{
  const tile=terrainCode=>({terrainCode,secondaryHeight:0});
  assert.equal(originalMoveCost({movementType:0},tile(3)),Infinity);
  assert.equal(originalMoveCost({movementType:1},tile(3)),2);
  assert.equal(originalMoveCost({movementType:2},tile(3)),1);
  assert.equal(originalMoveCost({movementType:0},tile(1)),2);
  assert.equal(originalMoveCost({movementType:0},tile(4)),2);
  assert.equal(originalCanLand({movementType:0},tile(6)),true);
  assert.equal(originalCanLand({movementType:2},tile(6)),false);
  assert.equal(originalMoveCost({movementType:4},tile(7)),1);
  assert.equal(originalCanLand({movementType:4},tile(7)),false);
});
test('movement uses physical height; ground climbs one level with surcharge, flying ignores it',()=>{
  const from={elevation:9,secondaryHeight:0},to={terrainCode:0,elevation:0,secondaryHeight:1};
  assert.equal(originalMoveCost({movementType:0},to,from),2);
  to.secondaryHeight=2;assert.equal(originalMoveCost({movementType:0},to,from),Infinity);
  assert.equal(originalMoveCost({movementType:4},to,from),1);
});
test('tide updates coded terrain rules and floating physical height, then restores after save',()=>{
  const s=arena();Object.assign(s.tiles.find(t=>key(t)==='3,3'),{terrain:'water',terrainCode:7,elevation:1,secondaryHeight:0});
  Object.assign(s.tiles.find(t=>key(t)==='4,3'),{terrainCode:0,secondaryHeight:0});
  Object.assign(s.tiles.find(t=>key(t)==='5,3'),{terrain:'floating',terrainCode:6,elevation:1,secondaryHeight:1});
  const b=new Battle(s),u=b.addUnit('hepitus',0,{q:4,r:3});b.changeTide(2);
  assert.equal(b.canLand(u,b.tiles.get('4,3')),false);assert.equal(ruleTerrain(b.tiles.get('4,3')),9);
  assert.equal(ruleHeight(b.tiles.get('5,3')),3);assert.equal(ruleTerrain(b.tiles.get('5,3')),6);
  const restored=Battle.restore(JSON.parse(JSON.stringify(b.serialize())));restored.time=restored.tide.expiresAt;restored.expireWorld();
  assert.equal(ruleTerrain(restored.tiles.get('4,3')),0);assert.equal(ruleHeight(restored.tiles.get('5,3')),1);
});
test('bankruptcy removes the oldest summon even when a younger one costs more',()=>{
  const b=new Battle(arena()),old=b.addUnit('fa-rancell',0,{q:3,r:2}),young=b.addUnit('guene-foss',0,{q:4,r:2});
  b.units[0].magicAttack=0;b.mana[0]=5;b.economy(0);
  assert.equal(old.hp,0);assert.equal(young.hp,10);assert.equal(b.mana[0],0);
});
test('disability pauses OA, replacement keeps longer effect, cleanse resumes remaining OA',()=>{
  const b=new Battle(arena()),u=b.units[1];b.reschedule(u,b.time+10);const original=u.nextTime;
  b.applyTimedDisability(u,'freeze',100);assert.equal(u.nextTime,original+100);
  b.applyTimedDisability(u,'petrify',30);assert.ok(u.statuses.freeze);assert.equal(u.nextTime,original+100);
  b.time+=20;b.clearStatus(u,'freeze');assert.equal(u.nextTime,original+20);
});
test('straight range is blocked by units; trajectory 3 magic ignores line obstacles',()=>{
  const a={q:0,r:0},z={q:3,r:0},tileAt=()=>({terrainCode:0,secondaryHeight:0});
  assert.equal(originalInRange(a,z,{range:3,trajectory:2},tileAt,p=>p.q===1?{}:null),false);
  assert.equal(originalInRange(a,z,{range:3,trajectory:3},tileAt,()=>({})),true);
});
test('range display distinguishes current attack from move + attack without mutating battle',()=>{
  const b=new Battle(arena()),before=JSON.stringify(b.serialize());
  const current=targetArea(b,b.active,{mode:'attack'}),future=targetArea(b,b.active,{view:'move-attack'});
  assert.equal(current.range.has('3,3'),false);assert.equal(future.range.has('3,3'),true);
  assert.equal(JSON.stringify(b.serialize()),before);
});
test('magic area preview includes friendly victims and matches actual damage execution',()=>{
  const b=new Battle(arena()),u=b.addUnit('currier-bell',0,{q:3,r:3}),friend=b.addUnit('fa-rancell',0,{q:4,r:2}),enemy=b.addUnit('reque',1,{q:4,r:3});b.activeId=u.id;
  const area=targetArea(b,u,{mode:'spell',spellId:'v2-20',target:enemy});
  assert.ok(area.victims.some(v=>v.id===friend.id&&v.friendly));
  for(const v of area.victims)assert.equal(v.amount,b.damage(u,b.units.find(t=>t.id===v.id),true,SPELLS['v2-20'],enemy).amount);
  assert.ok(area.effect.has(key(enemy)));assert.ok(area.targets.has(key(enemy)));
});
