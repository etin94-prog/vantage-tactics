import test from 'node:test';
import assert from 'node:assert/strict';
import {Battle} from '../src/engine.js';
import {generateStage} from '../src/maps.js';
import {Renderer} from '../src/renderer.js';
import {key} from '../src/hex.js';

function view(stageIndex,width,height,scale,panX,panY){
  const r=Object.create(Renderer.prototype);
  Object.assign(r,{width,height,scale,pan:{x:panX,y:panY},battle:new Battle(generateStage(stageIndex),'adol')});
  return r;
}
test('off-screen culling never drops a tile whose drawing reaches the viewport (all 30 stages)',()=>{
  let seed=7;const rand=()=>(seed=(seed*16807)%2147483647)/2147483647;
  for(let stage=0;stage<30;stage++)for(let n=0;n<6;n++){
    const width=[320,390,844,1280][n%4],height=[400,586,338,700][n%4],scale=.2+rand()*1.6;
    const probe=view(stage,width,height,scale,0,0),xs=probe.battle.stage.tiles.map(t=>probe.point(t));
    const minX=Math.min(...xs.map(p=>p.x)),maxX=Math.max(...xs.map(p=>p.x)),minY=Math.min(...xs.map(p=>p.y)),maxY=Math.max(...xs.map(p=>p.y));
    const r=view(stage,width,height,scale,-(minX+(maxX-minX)*rand())*scale+width/2,-(minY+(maxY-minY)*rand())*scale+height/2);
    const drawn=new Set(r.drawTiles().map(key));
    for(const t of r.battle.stage.tiles){
      if(t.terrain==='void')continue;
      const p=r.point(t),k=r.scale,x=p.x*k+r.pan.x,y=p.y*k+r.pan.y;
      // conservative paint box: hex/side ±40, trees up to 100 above, side face 12+5*elevation+28 below
      const reaches=x+40*k>0&&x-40*k<width&&y+(12+5*t.elevation+28)*k>0&&y-100*k<height;
      if(reaches)assert.ok(drawn.has(key(t)),`stage ${stage} tile ${key(t)} culled while visible`);
    }
    assert.ok(drawn.size<r.battle.stage.tiles.length||scale<.6,'culling actually skips tiles when zoomed in');
  }
});
test('sorted tile order is computed once per stage and void tiles are skipped',()=>{
  const r=view(1,390,586,1,0,0);const first=r.drawTiles();const cache=r.tileCache;r.drawTiles();
  assert.equal(r.tileCache,cache);
  const all=view(1,99999,99999,.01,50000,50000).drawTiles();
  for(let i=1;i<all.length;i++)assert.ok(all[i-1].r<all[i].r||all[i-1].r===all[i].r&&all[i-1].q<all[i].q);
  assert.ok(first.every(t=>t.terrain!=='void'));
});
test('adaptive frame interval drops to 30fps when frames are slow and recovers with hysteresis',()=>{
  const realNow=performance.now.bind(performance);let clock=0,cost=0;
  Object.defineProperty(performance,'now',{configurable:true,value:()=>clock});
  const raf=globalThis.requestAnimationFrame,doc=globalThis.document;globalThis.requestAnimationFrame=()=>0;globalThis.document={hidden:false};
  try{
    const r=Object.create(Renderer.prototype);r.lastFrame=0;r.draw=function(now){this.lastFrame=now;clock+=cost;};
    let t=0;const run=(frames,c)=>{cost=c;for(let i=0;i<frames;i++){t+=40;clock=t;r.loop(t);}};
    run(5,2);assert.equal(r.frameInterval,15);
    run(40,14);assert.equal(r.frameInterval,31,'slow frames → 30fps');
    run(3,7);assert.equal(r.frameInterval,31,'between thresholds keeps 30fps');
    run(60,2);assert.equal(r.frameInterval,15,'fast again → 60fps');
    r.lastFrame=t;r.draw=()=>{throw new Error('must skip a frame inside the interval');};r.loop(t+10);
  }finally{Object.defineProperty(performance,'now',{configurable:true,value:realNow});globalThis.requestAnimationFrame=raf;if(doc===undefined)delete globalThis.document;else globalThis.document=doc;}
});
