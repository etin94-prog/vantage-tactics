import test from 'node:test';
import assert from 'node:assert/strict';
import {Battle} from '../src/engine.js';
import {Renderer} from '../src/renderer.js';

function encounter(attacker='fa-rancell',defender='fa-rancell',gap=1){
  const stage={id:1,name:'Forecast',gridWidth:10,gridHeight:5,playerMasterStart:{q:0,r:0},enemyMasterStart:{q:9,r:4,classId:'duke'},manaStones:[],tiles:Array.from({length:50},(_,i)=>({q:i%10,r:Math.floor(i/10),terrain:'grass',elevation:0}))};
  const b=new Battle(stage,'fighter');
  const a=b.addUnit(attacker,0,{q:3,r:2}),d=b.addUnit(defender,1,{q:3+gap,r:2});
  d.facing=3;b.activeId=a.id;b.events=[];return {b,a,d};
}
const outcome=b=>{const pick=k=>b.events.filter(e=>e.type==='damage'&&e.kind===k).map(e=>[e.id,e.amount,e.hpBefore,e.hpAfter]);return {hits:pick('공격'),counter:pick('반격')};};
const shape=f=>({hits:f.hits.map(h=>[h.id,h.amount,h.hpBefore,h.hpAfter]),counter:f.counter?[[f.counter.id,f.counter.amount,f.counter.hpBefore,f.counter.hpAfter]]:[]});

test('attack forecast equals the real attack and leaves the battle untouched',()=>{
  for(const setup of [()=>encounter(),()=>{const e=encounter();e.d.hp=1;return e;},()=>{const e=encounter();e.a.hp=1;return e;},()=>encounter('ae-ferrion','fa-rancell',3)]){
    const {b,d}=setup();const before=JSON.stringify(b.serialize());
    const f=b.previewAttack(d.id);assert.ok(f,'forecast exists');
    assert.equal(JSON.stringify(b.serialize()),before,'preview must not mutate');
    assert.equal(b.attack(d.id),true);
    assert.deepEqual(shape(f),outcome(b));
  }
});
test('forecast reports lethal hits without a counter and ranged hits without a counter',()=>{
  let {b,d}=encounter();d.hp=1;let f=b.previewAttack(d.id);assert.equal(f.hits[0].hpAfter,0);assert.equal(f.counter,null);
  ({b,d}=encounter('ae-ferrion','fa-rancell',3));f=b.previewAttack(d.id);assert.ok(f.hits[0].amount>=0);assert.equal(f.counter,null);
  ({b,d}=encounter());f=b.previewAttack(d.id);assert.ok(f.counter,'adjacent melee defender counters');
});
test('forecast refuses targets the attack itself would refuse',()=>{
  const {b,d}=encounter('fa-rancell','fa-rancell',4);assert.equal(b.previewAttack(d.id),null);assert.equal(b.attack(d.id),false);
  const e=encounter();e.b.winner=0;assert.equal(e.b.previewAttack(e.d.id),null);
});

function holdHarness(){
  const listeners={},canvas={getBoundingClientRect:()=>({left:0,top:0}),setPointerCapture(){},addEventListener:(name,fn)=>listeners[name]=fn};
  const r=Object.create(Renderer.prototype);let clicks=0,holds=0;
  Object.assign(r,{canvas,pointers:new Map(),pan:{x:0,y:0},pick:()=>({q:0,r:0}),zoom(){},callbacks:{click:()=>clicks++,longPress:()=>holds++}});r.bind();
  return {send:(type,id,x,y)=>listeners['pointer'+type]({pointerId:id,clientX:x,clientY:y}),counts:()=>({clicks,holds}),listeners};
}
test('long press opens info once and its release is not a tap',t=>{
  t.mock.timers.enable({apis:['setTimeout']});
  let h=holdHarness();h.send('down',1,20,20);t.mock.timers.tick(460);h.send('up',1,20,20);assert.deepEqual(h.counts(),{clicks:0,holds:1});
  h=holdHarness();h.send('down',1,20,20);t.mock.timers.tick(200);h.send('up',1,20,20);t.mock.timers.tick(500);assert.deepEqual(h.counts(),{clicks:1,holds:0});
  h=holdHarness();h.send('down',1,20,20);h.send('move',1,40,20);t.mock.timers.tick(500);h.send('up',1,40,20);assert.deepEqual(h.counts(),{clicks:0,holds:0});
  h=holdHarness();h.send('down',1,20,20);h.send('down',2,60,20);t.mock.timers.tick(500);h.send('up',2,60,20);h.send('up',1,20,20);assert.deepEqual(h.counts(),{clicks:0,holds:0});
  h=holdHarness();h.send('down',1,20,20);h.send('cancel',1,20,20);t.mock.timers.tick(500);assert.deepEqual(h.counts(),{clicks:0,holds:0});
  let prevented=false;h.listeners.contextmenu({preventDefault:()=>prevented=true});assert.equal(prevented,true);
});
