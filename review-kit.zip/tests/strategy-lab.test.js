import test from 'node:test';
import assert from 'node:assert/strict';
import {validateBenchmark,createStrategyBattle,chooseStrategyAction,strategyRandom,runStrategyBenchmark,summarizeMatches} from '../src/strategy-lab.js';
import {LabSession,createLabBattle,stateHash,replayBundle} from '../src/lab-core.js';

test('benchmark rejects invalid grids and records independent progression loadouts',()=>{
  for(const bad of [{stages:[30]},{seeds:[1,1]},{maxActions:501},{opponents:['expert']},{strategies:['no']},{master:'unknown'},{loadout:'campaign-win'}])assert.throws(()=>validateBenchmark(bad));
  const c=validateBenchmark(),first=createStrategyBattle(c,0),last=createStrategyBattle(c,29);
  assert.equal(first.units[0].level,1);assert.equal(first.unlocked.length,4);assert.equal(first.extraSpells.length,0);
  assert.equal(last.units[0].level,30);assert.ok(last.unlocked.length>4);
  assert.equal(createStrategyBattle(validateBenchmark({loadout:'starter',level:5}),29).units[0].level,5);
});
test('strategic agent selects a lethal master attack and records a legal replay',()=>{
  const b=createLabBattle({scenario:'undo'});b.units[1].q=2;b.units[1].r=3;b.units[1].hp=1;
  const s=new LabSession(b),d=chooseStrategyAction(b,'rush');
  assert.equal(d.action.type,'attack');assert.equal(d.action.target,b.units[1].id);assert.ok(s.act(d.action));assert.equal(b.winner,0);replayBundle(s.bundle());
});
test('ranged agent can choose actual Blitz outside melee range without mutating while planning',()=>{
  const b=createLabBattle({scenario:'undo'}),u=b.addUnit('guene-foss',0,{q:4,r:3});b.activeId=u.id;u.nextTime=b.time;b.units[1].q=7;
  const before=stateHash(b),d=chooseStrategyAction(b,'ranged');assert.equal(stateHash(b),before);assert.equal(d.action.type,'cast');assert.equal(d.action.spell,'v2-blitz');
});
test('rate denominator includes limits and excludes errors/cancelled/unrun',()=>{
  const r=summarizeMatches(['win','loss','limit','error','cancelled'].map(status=>({status})),8);
  assert.equal(r.winRate,1/3);assert.equal(r.decidedWinRate,.5);assert.equal(r.unrun,3);assert.equal(r.errors,1);
});
test('seeded matrix matches reproduce, stopping preserves partial outcomes',async()=>{
  const c={stages:[0],strategies:['economy'],opponents:['medium','hard'],seeds:[7],maxActions:8};
  const a=await runStrategyBenchmark(c,'test'),b=await runStrategyBenchmark(c,'test');
  assert.equal(a.results.length,2);assert.equal(a.summary.errors,0);assert.equal(a.summary.limits,2);
  assert.deepEqual(a.results.map(r=>r.bundle),b.results.map(r=>r.bundle));assert.ok(a.results.every(r=>r.replayVerified));
  let stop=false;const partial=await runStrategyBenchmark(c,'test',{yield:async()=>{stop=true;},cancelled:()=>stop});
  assert.equal(partial.summary.cancelled,1);assert.equal(partial.summary.unrun,1);assert.equal(partial.summary.winRate,null);
  const r1=strategyRandom(12),r2=strategyRandom(12);assert.equal(r1(),r2());
});
