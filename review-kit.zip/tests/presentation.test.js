import test from 'node:test';
import assert from 'node:assert/strict';
import {Battle} from '../src/engine.js';
import {distance,key} from '../src/hex.js';
import {planPresentation,sampleMove,placeLabel,overlaps,presentationRate,sampleCombatPose,COMBAT_TIMING} from '../src/presentation.js';
import {Renderer} from '../src/renderer.js';

function arena(){return {id:1,name:'Route',gridWidth:8,gridHeight:5,playerMasterStart:{q:0,r:2},enemyMasterStart:{q:7,r:4,classId:'duke'},manaStones:[],tiles:Array.from({length:40},(_,i)=>({q:i%8,r:Math.floor(i/8),terrain:i===18?'wall':'grass',elevation:0}))};}
test('combat interpolation adds distinct in-betweens, returns home and respects reduced motion',()=>{
  for(const state of ['attack','cast']){
    const frames=Array.from({length:61},(_,i)=>sampleCombatPose(state,i/60));
    assert.deepEqual(frames[0],frames.at(-1));
    assert.ok(new Set(frames.map(p=>p.reach.toFixed(3))).size>35);
    for(let i=1;i<frames.length;i++){
      assert.ok(Math.abs(frames[i].reach-frames[i-1].reach)<5,'no positional jump');
      assert.ok(frames[i].sx>=.95&&frames[i].sx<=1.06,'preserve silhouette');
      const reduced=sampleCombatPose(state,i/60,true);
      assert.deepEqual([reduced.reach,reduced.lift,reduced.sx,reduced.sy,reduced.tilt],[0,0,1,1,0]);
    }
    assert.equal(sampleCombatPose(state,.7).frame,2,'recovery uses middle original pose');
  }
});
test('impact pose, HP cue and counter recovery stay synchronized at all supported speeds',()=>{
  for(const speed of [.75,1,2,3]){
    const cues=planPresentation([{type:'attack',id:1},{type:'damage',id:2},{type:'damage',id:1,kind:'반격',sourceId:2,q:0,r:0}],{units:[{id:2,q:1,r:0}]},100,speed);
    const swings=cues.filter(e=>e.type==='attack'),hits=cues.filter(e=>e.type==='damage');
    for(let i=0;i<2;i++){
      const t=(hits[i].start-swings[i].start)/swings[i].duration;
      assert.ok(Math.abs(t-COMBAT_TIMING.attackImpact/COMBAT_TIMING.attack)<1e-9);
      assert.equal(sampleCombatPose('attack',t).frame,4);
      assert.ok(sampleCombatPose('attack',t).reach>11);
    }
    assert.ok(swings[1].start>=swings[0].start+swings[0].duration,'counter waits for return');
  }
});
test('movement stores the legal route around obstacles and undo reverses it',()=>{
  const b=new Battle(arena(),'fighter');b.activeId=b.units[0].id;b.active.move=9;b.events=[];
  assert.ok(b.move({q:4,r:2}));const movement=b.events.find(e=>e.type==='move');
  assert.deepEqual(movement.path[0],{q:0,r:2});assert.deepEqual(movement.path.at(-1),{q:4,r:2});
  for(let i=1;i<movement.path.length;i++){assert.equal(distance(movement.path[i-1],movement.path[i]),1);assert.notEqual(b.tiles.get(key(movement.path[i])).terrain,'wall');}
  assert.ok(b.undoMove());assert.deepEqual(b.events[0].path.map(key),movement.path.map(key).reverse());
});
test('move then attack, damage and counter play in order at every speed',()=>{
  const battle={units:[{id:2,q:4,r:2,element:'earth'}]};
  const events=[{type:'move',id:1,from:{q:0,r:2},to:{q:3,r:2},path:[{q:0,r:2},{q:1,r:2},{q:2,r:2},{q:3,r:2}]},{type:'attack',id:1},{type:'damage',id:2,kind:'공격'},{type:'damage',id:1,sourceId:2,kind:'반격',q:3,r:2}];
  for(const speed of [.75,1,2,3]){
    const [move,attack,hit,counter,retaliation]=planPresentation(events,battle,100,speed);
    assert.equal(attack.start,move.start+move.duration);assert.ok(hit.start>attack.start);assert.ok(counter.start>hit.start);assert.ok(retaliation.start>counter.start);
    assert.equal(move.duration,780/speed);
  }
  assert.equal(presentationRate(undefined),1);assert.equal(presentationRate('2'),2);assert.equal(presentationRate(99),1);
});
test('sprite and badge share route interpolation; portal segments never slide through walls',()=>{
  const move={start:0,duration:1000,path:[{q:0,r:0},{q:1,r:0},{q:1,r:1}]},point=p=>({x:p.q*100,y:p.r*100});
  assert.deepEqual([sampleMove(move,250,point).x,sampleMove(move,250,point).y],[50,0]);
  assert.deepEqual([sampleMove(move,750,point).x,sampleMove(move,750,point).y],[100,50]);
  const warp={start:0,duration:500,path:[{q:0,r:0},{q:8,r:8,warp:true}]};
  assert.equal(sampleMove(warp,250,point).x,0);assert.equal(sampleMove(warp,500,point).x,800);
});
test('labels avoid neighboring badges, damage labels and screen edges',()=>{
  const bounds={x:5,y:45,width:310,height:180},occupied=[];
  for(const anchor of [{x:160,y:120},{x:165,y:120},{x:160,y:120},{x:305,y:100}])assert.ok(placeLabel(anchor,56,22,occupied,bounds));
  for(let i=0;i<occupied.length;i++)for(let j=i+1;j<occupied.length;j++)assert.equal(overlaps(occupied[i],occupied[j]),false);
  for(const rect of occupied){assert.ok(rect.x>=bounds.x);assert.ok(rect.x+rect.width<=bounds.x+bounds.width);assert.ok(rect.y>=bounds.y);}
});
test('camera follows the visible acting enemy position, not the next active unit',()=>{
  const actor={id:2,q:2,r:2},next={id:3,q:10,r:10};
  const r=Object.assign(Object.create(Renderer.prototype),{battle:{units:[actor,next],active:next,visibleUnit:u=>u.id===2,visible:()=>true},pan:{x:0,y:0},scale:1,width:390,height:500,reduced:true,motion:()=>({x:200,y:150,cell:actor})});
  r.followActor(actor);r.trackCamera(0,32);assert.deepEqual(r.pan,{x:-5,y:75});
  r.followActor(next);assert.equal(r.followId,null);
});
test('a stalled frame preserves movement and later attack instead of skipping both',()=>{
  const r=Object.assign(Object.create(Renderer.prototype),{lastFrame:1000,playbackUntil:2500,effects:[{type:'move',batchStart:900,start:900,duration:800,presented:true},{type:'attack',batchStart:900,start:1700,duration:700}]});
  r.preserveFrames(2000);
  assert.deepEqual(r.effects.map(e=>e.start),[1800,2600]);assert.equal(r.playbackUntil,3400);
  assert.equal(r.isPlaying(3500),true); // Undelivered action is still pending until a frame presents it.
});
