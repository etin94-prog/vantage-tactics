import test from 'node:test';
import assert from 'node:assert/strict';
import { Battle } from '../src/engine.js';
import { generateStage } from '../src/maps.js';
import { SUMMONS, MASTERS, masterStats } from '../src/data.js';
import { SPELLS, v2SpellId } from '../src/spells.js';
import { V2_ACTIONS } from '../src/v2-reference.js';
import { timePeriod, actionMinutes, playerLevel } from '../src/rules.js';
import { campaignInventory, recordVictory } from '../src/campaign.js';
import { key } from '../src/hex.js';
function arena(){return {id:1,name:'Core test',gridWidth:11,gridHeight:7,playerMasterStart:{q:1,r:3},enemyMasterStart:{q:9,r:3,classId:'duke'},manaStones:[{q:2,r:3}],tiles:Array.from({length:77},(_,i)=>({q:i%11,r:Math.floor(i/11),terrain:'grass',elevation:0}))};}
function active(b,type,pos){const u=b.addUnit(type,0,pos);b.activeId=u.id;return u;}

test('all original magic users have their extracted spell, cost, range and casting delay',()=>{
  for(const n of SUMMONS){assert.equal(n.spells.length,n.spellIndex?1:0);if(!n.spellIndex)continue;const s=SPELLS[n.spells[0]],raw=V2_ACTIONS[n.spellIndex];assert.equal(s.cost,raw.cost);assert.equal(s.range,raw.range);assert.equal(s.oaExtra,raw.oaExtra);}
  assert.deepEqual([10,11,12,13,14,15].map(i=>SPELLS[v2SpellId(i)].cost),[32,32,26,12,8,34]);
  assert.deepEqual([2,3,4,5].map(i=>V2_ACTIONS[i].range),[6,7,4,5]);
  assert.equal(generateStage(0).enemyRoster.length,4);assert.equal(generateStage(29).enemyRoster.length,24);
});
test('original growth table applies to player level and each SAT rank, without HP inflation',()=>{
  const b=new Battle(arena(),'adol',{playerLevel:12}),stats=masterStats(MASTERS.find(m=>m.id==='adol'),12);
  assert.equal(b.units[0].maxMana,stats.maxMana);assert.equal(b.units[0].attack,stats.attack);
  const u=b.addUnit('fa-rancell',0,{q:3,r:1});b.gainSat(u,100);assert.equal(u.level,2);assert.equal(u.attack,11);
  b.gainSat(u,150);assert.equal(u.level,3);assert.equal(u.attack,14);assert.equal(u.hp,10);
  const restored=Battle.restore(JSON.parse(JSON.stringify(b.serialize())));assert.equal(restored.units[2].sat,250);
  assert.equal(new Battle(arena()).addUnit('fa-rancell',0,{q:3,r:1}).level,1);
});
test('healing uses real missing HP for SAT and rejects full-health targets',()=>{
  const b=new Battle(arena()),u=active(b,'d-alma',{q:3,r:3}),friend=b.addUnit('fa-rancell',0,{q:4,r:3});
  friend.hp=9;assert.ok(b.spellTargets(u,'v2-23').includes(friend));b.mana[0]=20;
  assert.equal(b.cast('v2-23',friend),true);assert.equal(friend.hp,10);assert.equal(u.sat,10);
  assert.ok(!b.spellTargets(u,'v2-23').includes(friend));
});
test('freeze and petrify are timed; Pelitt cleanse removes them',()=>{
  const b=new Battle(arena()),u=active(b,'zamilpen',{q:3,r:3}),target=b.addUnit('fa-rancell',1,{q:4,r:3});
  assert.equal(b.cast('v2-26',target),true);assert.ok(b.hasStatus(target,'freeze'));
  const healer=b.addUnit('pelitt',1,{q:4,r:2});b.activeId=healer.id;
  assert.ok(b.spellTargets(healer,'v2-29').includes(target));assert.equal(b.cast('v2-29',target),true);assert.equal(b.hasStatus(target,'freeze'),false);
  target.statuses.petrify={expiresAt:b.time+10};b.time+=10;b.expireWorld();assert.equal(b.hasStatus(target,'petrify'),false);
});
test('enemy frozen turn is skipped and unfreezes after game time expires',()=>{
  const b=new Battle(arena());const enemy=b.units[1];enemy.statuses.freeze={expiresAt:200};
  b.wait();assert.notEqual(b.activeId,enemy.id);assert.ok(b.hasStatus(enemy,'freeze'));
  b.time=200;b.expireWorld();assert.equal(b.hasStatus(enemy,'freeze'),false);
});
test('target area damages friend and caster; self-area excludes caster but hits both teams',()=>{
  const b=new Battle(arena()),u=active(b,'currier-bell',{q:3,r:3});
  const friend=b.addUnit('fa-rancell',0,{q:4,r:2}),enemy=b.addUnit('reque',1,{q:4,r:3});
  const area=b.affected(u,SPELLS['v2-20'],enemy);assert.ok(area.includes(u));assert.ok(area.includes(friend));assert.ok(area.includes(enemy));
  const before=[u.hp,friend.hp,enemy.hp];assert.equal(b.cast('v2-20',enemy),true);assert.ok(u.hp<before[0]&&friend.hp<before[1]&&enemy.hp<before[2]);
  const c=new Battle(arena()),tent=active(c,'tentarch',{q:3,r:3}),ally=c.addUnit('fa-rancell',0,{q:4,r:3});
  assert.ok(!c.affected(tent,SPELLS['v2-30'],tent).includes(tent));assert.ok(c.affected(tent,SPELLS['v2-30'],tent).includes(ally));
});
test('Bless restores all allied natials but not master, enemy, or full-health HP',()=>{
  const b=new Battle(arena(),'adol',{extraSpells:['v2-13']}),master=b.active;
  const a=b.addUnit('fa-rancell',0,{q:4,r:1}),z=b.addUnit('reque',0,{q:7,r:1}),enemy=b.units[1];
  master.hp=a.hp=z.hp=enemy.hp=5;
  assert.equal(b.cast('v2-13',master),true);assert.deepEqual([master.hp,a.hp,z.hp,enemy.hp],[5,6,6,5]);
});
test('tide floods low ground, strands non-swimmers, extends duration and restores exact tiles after reload',()=>{
  const s=arena();Object.assign(s.tiles.find(t=>key(t)==='3,3'),{terrain:'water',terrainCode:7,elevation:1,secondaryHeight:0});
  const b=new Battle(s),fire=b.addUnit('hepitus',0,{q:4,r:3}),before=b.stage.tiles.map(t=>[t.terrain,t.elevation]);
  b.changeTide(2);assert.equal(b.canLand(fire,b.tiles.get(key(fire))),false);b.hazards(fire);assert.equal(fire.hp,7);
  const expiry=b.tide.expiresAt;b.changeTide(2);assert.equal(b.tide.expiresAt,expiry+120);
  const saved=Battle.restore(JSON.parse(JSON.stringify(b.serialize())));saved.time=saved.tide.expiresAt;saved.expireWorld();
  assert.equal(saved.tide,null);assert.deepEqual(saved.stage.tiles.map(t=>[t.terrain,t.elevation]),before);
});
test('day and night boundaries change both battle stats and visual brightness',()=>{
  assert.deepEqual([239,240,479,480,959,960,1199,1200].map(timePeriod),['night','morning','morning','day','day','evening','evening','night']);
  const b=new Battle(arena()),day=b.addUnit('guene-foss',0,{q:3,r:2}),night=b.addUnit('marme',0,{q:4,r:2});
  b.time=720;assert.equal(b.stat(day,'magicAttack'),10);assert.equal(b.stat(night,'magicAttack'),11);assert.equal(b.brightness(),1);
  b.time=1200;assert.equal(b.stat(day,'magicAttack'),6);assert.equal(b.stat(night,'magicAttack'),15);assert.equal(b.brightness(),0);
});
test('ground units stop in enemy ZOC while flying units can pass',()=>{
  const s=arena();s.tiles.forEach(t=>{if(t.r!==3)t.terrain='wall';});
  const b=new Battle(s);b.units[1].q=5;
  assert.equal(b.reachable().dist.has('4,3'),true);assert.equal(b.reachable().dist.has('5,3'),false);
  const fly={...b.active,flying:true,movementType:4,move:8};b.units[1].q=4;b.units[1].r=2;b.tiles.get('4,2').terrain='grass';
  assert.equal(b.reachable().dist.has('5,3'),false);assert.equal(b.reachable(fly).dist.has('5,3'),true);
});
test('direction control and same-element suppression affect preview deterministically',()=>{
  const b=new Battle(arena()),a=b.active,t=b.units[1];t.q=2;t.facing=3;a.attack=12;t.defense=6;a.element='fire';t.element='water';
  const disadvantaged=b.damage(a,t).amount;t.element='wind';assert.ok(b.damage(a,t).amount>disadvantaged);
  t.element='neutral';const neutral=b.damage(a,t).amount;t.element='fire';assert.ok(b.damage(a,t).amount<neutral);
  assert.equal(b.setFacing(4),true);assert.equal(a.facing,4);assert.equal(b.setFacing(7),false);
});
test('published OA anchors and per-spell extras distinguish actions',()=>{
  assert.equal(actionMinutes(9,15),48);assert.equal(actionMinutes(10),30);assert.equal(actionMinutes(10,15),45);assert.equal(actionMinutes(10,15,true),60);
  assert.equal(actionMinutes(10,25),55);assert.equal(actionMinutes(10,50,true),95);
});
test('victory awards once, custom battles award nothing, inventory expands and level is capped',()=>{
  const p={exp:0,cleared:[],unlocked:1},stage=generateStage(0),once=recordVictory(p,stage);
  assert.equal(once.exp,100);assert.equal(playerLevel(once.exp),2);assert.deepEqual(recordVictory(once,stage),once);
  assert.deepEqual(recordVictory(p,{...stage,custom:true}),p);assert.equal(playerLevel(100000),40);
  assert.equal(campaignInventory([]).unlocked.length,4);assert.equal(campaignInventory([1,2,3,4]).extraSpells.includes('v2-13'),true);
  const end=campaignInventory(Array.from({length:30},(_,i)=>i+1));assert.equal(end.unlocked.length,24);assert.equal(end.extraSpells.length,6);
});


test('move undo restores position and facing without spending time or mana; movement can be retried',()=>{
  const b=new Battle(arena()),u=b.active;u.facing=4;
  const before={q:u.q,r:u.r,time:b.time,turn:b.turn,mana:[...b.mana],nextTime:u.nextTime};
  assert.equal(b.undoMove(),false);assert.equal(b.move({q:2,r:3}),true);
  assert.equal(b.stones[0].owner,null);assert.equal(b.canUndoMove(),true);
  assert.equal(b.move({q:3,r:3}),false);assert.equal(b.undoMove(),true);
  assert.deepEqual({q:u.q,r:u.r,time:b.time,turn:b.turn,mana:b.mana,nextTime:u.nextTime},before);
  assert.equal(u.facing,4);assert.equal(b.moved,false);assert.equal(b.moveCost,0);
  assert.equal(b.undoMove(),false);assert.equal(b.move({q:2,r:3}),true);
});
test('undo survives saving and reverses arrival traps, statuses and logs',()=>{
  const b=new Battle(arena());b.traps.push({q:2,r:3,team:1,duration:2});
  const log=structuredClone(b.log),traps=structuredClone(b.traps);
  assert.equal(b.move({q:2,r:3}),true);assert.equal(b.hasStatus(b.active,'root'),true);assert.equal(b.traps.length,0);
  const restored=Battle.restore(JSON.parse(JSON.stringify(b.serialize())));
  assert.equal(restored.undoMove(),true);assert.equal(restored.hasStatus(restored.active,'root'),false);
  assert.deepEqual(restored.traps,traps);assert.deepEqual(restored.log,log);
  assert.equal(restored.active.q,1);
});
test('committing wait, attack or summon prevents undo and captures stones only on commit',()=>{
  const b=new Battle(arena());b.move({q:2,r:3});b.wait();
  assert.equal(b.undoMove(),false);assert.equal(b.stones[0].owner,0);
  const attack=new Battle(arena());attack.units[1].q=3;assert.equal(attack.move({q:2,r:3}),true);
  assert.equal(attack.attack(attack.units[1].id),true);assert.equal(attack.undoMove(),false);
  const summon=new Battle(arena());summon.move({q:2,r:3});
  assert.equal(summon.summon('fa-rancell',{q:3,r:3},false),true);assert.equal(summon.undoMove(),false);
});
test('undo restores the origin before portal transport and rejects stale saved snapshots',()=>{
  const s=arena();s.portals=[[{q:2,r:3},{q:5,r:3}]];
  const b=new Battle(s);assert.equal(b.move({q:2,r:3}),true);assert.equal(b.active.q,5);
  const saved=JSON.parse(JSON.stringify(b.serialize()));saved.moveUndo.turn--;
  assert.throws(()=>Battle.restore(saved),/이동 취소/);
  assert.equal(b.undoMove(),true);assert.equal(b.active.q,1);
});
