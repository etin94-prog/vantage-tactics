import test from 'node:test';
import assert from 'node:assert/strict';
import {GameHaptics} from '../src/haptics.js';
import {combatPresentation,Renderer} from '../src/renderer.js';

test('vibration follows real impacts, skips zero damage and coalesces area hits',()=>{
  const calls=[],doc={hidden:false},nav={vibrate:p=>{calls.push(p);return true;},userActivation:{hasBeenActive:true}};
  const h=new GameHaptics({nav,doc});
  h.impact({type:'damage',amount:2,hpAfter:8},0);
  h.impact({type:'damage',amount:3,hpAfter:7},10);
  h.impact({type:'damage',amount:0,hpAfter:10},200);
  h.impact({type:'damage',kind:'반격',amount:1,hpAfter:9},650);
  h.impact({type:'damage',amount:9,hpAfter:0},2000);
  assert.deepEqual(calls,[20,30,[35,45,55]]);
  h.setEnabled(false);assert.equal(calls.at(-1),0);
  assert.equal(h.pulse(20,3000),false);
  h.setEnabled(true);doc.hidden=true;assert.equal(h.pulse(20,4000),false);
  doc.hidden=false;nav.userActivation.hasBeenActive=false;assert.equal(h.pulse(20,5000),false);
});

test('missing or rejected vibration API does not break gameplay',()=>{
  for(const nav of [{},{vibrate:()=>false},{vibrate:()=>{throw Error('blocked');}}]){
    const h=new GameHaptics({nav,doc:{hidden:false}});
    assert.equal(h.pulse(30,0),false);h.cancel();
  }
});

test('counter motion, damage and death are sequential while engine HP stays unchanged',()=>{
  const a={id:1,q:0,r:0,hp:0},d={id:2,q:1,r:0,hp:8,element:'earth'};
  const events=[{type:'attack',id:1},{type:'damage',id:2,amount:2,hpBefore:10,hpAfter:8,kind:'공격'},
    {type:'damage',id:1,sourceId:2,q:0,r:0,amount:1,hpBefore:1,hpAfter:0,kind:'반격'},
    {type:'down',unit:{...a},q:0,r:0}];
  const before=structuredClone(events),effects=combatPresentation(events,{units:[a,d]},1000);
  assert.deepEqual(events,before);
  assert.deepEqual(effects.map(e=>[e.type,e.start]),[['attack',1000],['damage',1360],['attack',2100],['damage',2460],['down',2460]]);
  const r=Object.assign(Object.create(Renderer.prototype),{effects,playbackUntil:2100});
  assert.equal(r.displayHp(a,1400),1);assert.equal(r.displayHp(a,2460),0);
  assert.equal(a.hp,0);assert.equal(d.hp,8);
  assert.equal(r.isPlaying(2000),true);r.effects.forEach(e=>e.presented=true);r.lastFrame=3300;assert.equal(r.isPlaying(3300),false);
});
