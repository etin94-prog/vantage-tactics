import test from 'node:test';
import assert from 'node:assert/strict';
import {Renderer} from '../src/renderer.js';

function renderer(effects=[],reduced=false){
  const r=Object.create(Renderer.prototype);
  Object.assign(r,{effects,reduced,battle:{units:[{id:1,q:0,r:0},{id:2,q:1,r:0}]},point:u=>({x:u.q*60,y:0})});
  return r;
}
const hit=(extra={})=>({type:'damage',id:2,sourceId:1,amount:3,hpAfter:4,start:100,...extra});

test('knockback pushes the target away from the attacker and fades out',()=>{
  const r=renderer(),p={x:60,y:0};
  const early=r.knockback(hit(),'hit',p,100),late=r.knockback(hit(),'hit',p,300);
  assert.ok(early.kx>4&&Math.abs(early.ky)<1e-9,'pushed along +x, away from the source at x=0');
  assert.ok(late.kx<early.kx&&late.kx>=0);
  assert.deepEqual(r.knockback(hit({amount:0}),'hit',p,100),{kx:0,ky:0},'0 damage has no push');
  assert.deepEqual(r.knockback(hit(),'idle',p,100),{kx:0,ky:0});
  assert.deepEqual(renderer([],true).knockback(hit(),'hit',p,100),{kx:0,ky:0},'reduced motion');
});
test('screen shake only for knockouts or heavy hits, decays, and respects reduced motion',()=>{
  const amp=(effects,now,reduced=false)=>{const s=renderer(effects,reduced);let m=0;for(let k=0;k<20;k++){const o=s.shake(now+k);m=Math.max(m,Math.hypot(o.x,o.y));}return m;};
  assert.equal(amp([hit()],110),0,'light hit: no shake');
  assert.ok(amp([hit({hpAfter:0})],110)>3,'knockout shakes');
  assert.ok(amp([hit({amount:6})],110)>1.5,'heavy hit shakes');
  assert.ok(amp([hit({hpAfter:0})],300)<amp([hit({hpAfter:0})],110),'decays');
  assert.equal(amp([hit({hpAfter:0})],400),0,'stops after 240ms');
  assert.equal(amp([hit({hpAfter:0})],110,true),0,'reduced motion');
  assert.equal(amp([hit({hpAfter:0,start:500})],110),0,'not before the hit lands');
});
