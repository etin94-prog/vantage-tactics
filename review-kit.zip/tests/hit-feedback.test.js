import test from 'node:test';
import assert from 'node:assert/strict';
import {Renderer} from '../src/renderer.js';

function renderer(effects=[],reduced=false){
  const r=Object.create(Renderer.prototype);
  Object.assign(r,{effects,reduced,battle:{units:[{id:1,q:0,r:0},{id:2,q:1,r:0}]},point:u=>({x:u.q*60,y:0})});
  return r;
}
const hit=(extra={})=>({type:'damage',id:2,sourceId:1,amount:3,hpAfter:4,start:100,...extra});

test('knockback pushes the target away from the attacker and fades out',()=>{
  const r=renderer(),p={x:60,y:0};
  const early=r.knockback(hit(),'hit',p,100),late=r.knockback(hit(),'hit',p,300);
  assert.ok(early.kx>4&&Math.abs(early.ky)<1e-9,'pushed along +x, away from the source at x=0');
  assert.ok(late.kx<early.kx&&late.kx>=0);
  assert.deepEqual(r.knockback(hit({amount:0}),'hit',p,100),{kx:0,ky:0},'0 damage has no push');
  assert.deepEqual(r.knockback(hit(),'idle',p,100),{kx:0,ky:0});
  assert.deepEqual(renderer([],true).knockback(hit(),'hit',p,100),{kx:0,ky:0},'reduced motion');
});
test('screen shake only for knockouts or heavy hits, decays, and respects reduced motion',()=>{
  const amp=(effects,now,reduced=false)=>{const s=renderer(effects,reduced);let m=0;for(let k=0;k<20;k++){const o=s.shake(now+k);m=Math.max(m,Math.hypot(o.x,o.y));}return m;};
  assert.equal(amp([hit()],110),0,'light hit: no shake');
  assert.ok(amp([hit({hpAfter:0})],110)>3,'knockout shakes');
  assert.ok(amp([hit({amount:6})],110)>1.5,'heavy hit shakes');
  assert.ok(amp([hit({hpAfter:0})],300)<amp([hit({hpAfter:0})],110),'decays');
  assert.equal(amp([hit({hpAfter:0})],400),0,'stops after 240ms');
  assert.equal(amp([hit({hpAfter:0})],110,true),0,'reduced motion');
  assert.equal(amp([hit({hpAfter:0,start:500})],110),0,'not before the hit lands');
});
test('attack lunge leans toward the target and returns; walking hops once per tile; reduced motion keeps sprites still',()=>{
  const r=renderer();const p={x:0,y:0};const u={id:1};
  const atk=t=>r.bodyOffset(u,{type:'attack',start:0,duration:400,to:{q:1,r:0}},'attack',p,t);
  assert.ok(atk(180).kx>8,'peak reach toward +x target');
  assert.ok(atk(0).kx<1&&atk(400).kx<1,'starts and ends at home');
  assert.ok(atk(100).kx<atk(180).kx&&atk(300).kx<atk(180).kx);
  const mv={type:'move',id:1,start:0,duration:600,path:[{q:0,r:0},{q:1,r:0},{q:2,r:0}]};r.effects=[mv];
  const hop=t=>r.bodyOffset(u,null,'move',{x:0,y:0,moving:true,to:{q:1,r:0}},t).ky;
  assert.ok(hop(150)<-3.5,'mid first tile is lifted');assert.ok(Math.abs(hop(300))<.01,'lands between tiles');assert.ok(hop(450)<-3.5,'second hop');
  assert.equal(r.bodyOffset(u,null,'move',{x:0,y:0,moving:true,to:{q:1,r:0,warp:true}},150).ky,0,'portal jump has no hop');
  const still=renderer([mv],true);assert.deepEqual(still.bodyOffset(u,{type:'attack',start:0,duration:400,to:{q:1,r:0}},'attack',p,180),{kx:0,ky:0});
});

test('attack lunge stays finite with the real tile geometry (target given as bare {q,r})',()=>{
  // Regression 2026-10-25: point({q,r}) had no elevation → NaN offset → the attacking natial vanished for the whole swing.
  const r=Object.create(Renderer.prototype),tiles=new Map([['0,0',{q:0,r:0,elevation:1}],['1,0',{q:1,r:0,elevation:3}]]);
  Object.assign(r,{effects:[],reduced:false,battle:{units:[],tiles}});
  const p=r.point(tiles.get('0,0'));
  for(const t of [0,90,180,300,399]){const o=r.bodyOffset({id:1},{type:'attack',start:0,duration:400,to:{q:1,r:0}},'attack',p,t);assert.ok(Number.isFinite(o.kx)&&Number.isFinite(o.ky),`finite at t=${t}`);}
  const mid=r.bodyOffset({id:1},{type:'attack',start:0,duration:400,to:{q:1,r:0}},'attack',p,180);assert.ok(mid.kx>3,'leans toward the target');
});
