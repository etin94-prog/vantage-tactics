import {audibleEvents} from '../src/event-visibility.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {parseMidi,chooseTrack,GameAudio,presentationSound,AUDIO_TRACKS,DEFAULT_TUNING,sanitizeTuning,scoreHeadroom,instrumentGroup,AUDIO_PRESETS,matchingPreset,migrateAudioPreferences} from '../src/audio.js';
import {REFERENCE_MEDIA} from '../src/reference-media.js';
import {MASTERS,SUMMONS} from '../src/data.js';
import {referenceFrame,referenceSprite} from '../src/renderer.js';

function midi(events){const header=Buffer.from('4d546864000000060000000100604d54726b','hex'),size=Buffer.alloc(4);size.writeUInt32BE(events.length);return Buffer.concat([header,size,Buffer.from(events)]);}
test('MIDI tempo, running status and sustain change audible duration',()=>{
  const song=parseMidi(midi([0,0xc0,40,0,0xb0,64,127,0,0x90,60,100,96,60,0,0,255,81,3,15,66,64,96,0xb0,64,0,0,255,47,0]));
  assert.equal(song.notes.length,1);assert.equal(song.notes[0][1],1.5);assert.equal(song.notes[0][5],40);assert.equal(song.duration,1.5);
});
test('MIDI rejects truncated files, unsupported timing and invalid running status',()=>{
  assert.throws(()=>parseMidi(midi([0,60,100])));assert.throws(()=>parseMidi(midi([0,255,81,9,1])));assert.throws(()=>parseMidi(new Uint8Array(3)));
  const bad=midi([0,255,47,0]);bad.writeUInt16BE(0xe728,12);assert.throws(()=>parseMidi(bad));
});
test('all 19 supplied scores decompress and yield finite, ordered notes',()=>{
  assert.equal(REFERENCE_MEDIA.tracks.length,19);
  for(const t of REFERENCE_MEDIA.tracks){const song=parseMidi(gunzipSync(Buffer.from(t.gzip,'base64')));assert.ok(song.notes.length>0,t.id);assert.ok(song.duration>0&&song.duration<3600,t.id);let previous=-1;for(const n of song.notes){assert.ok(n.slice(0,7).every(Number.isFinite),t.id);assert.ok(n[0]>=previous&&n[1]>0,t.id);previous=n[0];}}
  for(let stage=1;stage<=30;stage++)assert.ok(REFERENCE_MEDIA.tracks.some(t=>t.id===chooseTrack(stage)));
});
test('every character has two PNG atlases; custom uploads take priority',()=>{
  assert.equal(Object.keys(REFERENCE_MEDIA.sprites).length,51);
  for(const u of [...MASTERS,...SUMMONS])for(const team of [0,1]){const src=referenceSprite({...u,team}),png=Buffer.from(src.split(',')[1],'base64');assert.equal(png.toString('ascii',1,4),'PNG');assert.equal(png.readUInt32BE(16),576);assert.equal(png.readUInt32BE(20),864);assert.equal(referenceSprite({...u,team,sprite:'custom.png'}),null);}
  for(let facing=0;facing<6;facing++)for(const state of ['idle','move','attack','cast','hit','down'])for(let f=0;f<8;f++)assert.ok(referenceFrame({facing},state,f)>=0&&referenceFrame({facing},state,f)<54);
});
test('turning sound off while a track is loading cannot restart music',async()=>{
  const audio=new GameAudio();let resolve;audio.enabled=true;audio.ctx={currentTime:0,suspend:()=>Promise.resolve()};audio.track=()=>new Promise(r=>resolve=r);const pending=audio.select(chooseTrack(1));audio.disable();resolve({notes:[[0,1,60,1,0,0,0]],duration:1});await pending;assert.equal(audio.enabled,false);assert.equal(audio.timer,null);
});
test('a stale failed track request cannot disable the newer selection',async()=>{
  const audio=new GameAudio();let reject;audio.enabled=true;audio.ctx={currentTime:0,state:'suspended',suspend:()=>Promise.resolve()};audio.track=id=>id===chooseTrack(1)?new Promise((_,r)=>reject=r):Promise.resolve({notes:[],duration:1});const older=audio.select(chooseTrack(1));await audio.select(chooseTrack(2));reject(new Error('old failed'));await older;assert.equal(audio.enabled,true);assert.equal(audio.trackId,chooseTrack(2));audio.disable();
});

test('stored tuning rejects invalid fields and bounds unsafe values',()=>{
  const tuning=sanitizeTuning({brightness:Infinity,tempo:9,reverb:-1,warmth:99,gain:NaN,drums:'1',unknown:5});
  assert.equal(tuning.brightness,DEFAULT_TUNING.brightness);assert.equal(tuning.tempo,1.25);assert.equal(tuning.reverb,0);assert.equal(tuning.warmth,4);assert.equal(tuning.gain,1);assert.equal(tuning.drums,DEFAULT_TUNING.drums);assert.equal(tuning.unknown,undefined);
});
test('per-track settings survive reload, remain independent, and can apply to all scores',async()=>{
  const audio=new GameAudio(),first=AUDIO_TRACKS[0].id,second=AUDIO_TRACKS[1].id;
  await audio.select(first);audio.tune({...audio.getTuning(),brightness:2300});
  await audio.select(second);assert.equal(audio.getTuning().brightness,4200);
  const saved=audio.tune({...audio.getTuning(),brightness:5900});saved.unknown={tempo:100};
  const restored=new GameAudio();restored.loadTunings(saved);await restored.select(first);assert.equal(restored.tuning.brightness,2300);assert.equal(restored.tunings.unknown,undefined);
  restored.tune({...restored.getTuning(),tempo:.9},true);assert.equal(Object.keys(restored.tunings).length,19);
  await restored.select(second);assert.equal(restored.tuning.tempo,.9);assert.equal(restored.tuning.brightness,2300);
  restored.tune({...restored.getTuning(),brightness:3200});assert.equal(restored.getTuning(first).brightness,2300);
});
test('dense scores receive headroom without boosting quiet scores',()=>{
  const note=[0,1,60,1,0,0,0];assert.equal(scoreHeadroom({notes:[note]}),1);
  assert.ok(scoreHeadroom({notes:Array.from({length:8},()=>note)})<=.4);
  assert.equal(scoreHeadroom({notes:[note,[1,1,60,1,0,0,0]]}),1);
  for(const t of REFERENCE_MEDIA.tracks){const gain=scoreHeadroom(parseMidi(gunzipSync(Buffer.from(t.gzip,'base64'))));assert.ok(gain>=.4&&gain<=1,t.id);}
});
test('tempo changes preserve position and schedule subsequent notes at the new speed',()=>{
  const audio=new GameAudio();audio.ctx={currentTime:5,state:'running'};audio.song={notes:[[4.1,.2,60,1,0,0,0]],duration:10};audio.epoch=1;audio.cursor=0;audio.enabled=true;
  const played=[];audio.note=(n,at)=>played.push(at);audio.tune({...DEFAULT_TUNING,tempo:1.25});
  assert.ok(Math.abs((5-audio.epoch)*1.25-4)<1e-9);audio.schedule();assert.ok(Math.abs(played[0]-5.08)<1e-9);assert.equal(audio.cursor,1);
});
test('GM families and percussion route to the intended mix groups',()=>{
  assert.equal(instrumentGroup(24),'plucks');assert.equal(instrumentGroup(32),'bass');assert.equal(instrumentGroup(48),'strings');assert.equal(instrumentGroup(56),'brass');assert.equal(instrumentGroup(72),'winds');assert.equal(instrumentGroup(80),'synth');assert.equal(instrumentGroup(0,9),'drums');
});

test('RPN cents and null selection, held-note bend and zero-to-full expression survive parsing',()=>{
  const song=parseMidi(midi([0,0xb0,101,0,0,0xb0,100,0,0,0xb0,6,12,0,0xb0,38,50,0,0xb0,11,0,0,0x90,60,127,48,0xe0,0,96,0,0xb0,11,127,0,0xb0,101,127,0,0xb0,100,127,0,0xb0,6,2,48,0x80,60,0,0,255,47,0]));
  const n=song.notes[0];assert.equal(n[3],0);assert.equal(n[7].pitch.at(-1)[1],66.25);assert.equal(n[7].gain.at(-1)[1],(100/127)**2);
  assert.equal(n[7].pitch.at(-1)[0],.25);assert.ok(scoreHeadroom(song)>0);
});

function synthContext(){const nodes=[],param=()=>({value:0,calls:[],setValueAtTime(...a){this.calls.push(['set',...a]);},linearRampToValueAtTime(...a){this.calls.push(['linear',...a]);},exponentialRampToValueAtTime(...a){this.calls.push(['exp',...a]);},setTargetAtTime(...a){this.calls.push(['target',...a]);},cancelAndHoldAtTime(...a){this.calls.push(['hold',...a]);}});
  const node=type=>{const n={type,frequency:param(),gain:param(),pan:param(),Q:param(),connect(){return arguments[0];},disconnect(){},setPeriodicWave(){},start(){},stop(t){this.stopAt=t;}};nodes.push(n);return n;};
  return {nodes,state:'running',currentTime:1,createOscillator:()=>node('osc'),createBufferSource:()=>node('source'),createGain:()=>node('gain'),createBiquadFilter:()=>node('filter'),createStereoPanner:()=>node('pan'),createPeriodicWave:()=>({})};
}
test('a silent-onset swell schedules gain and bend automation on one oscillator and fades on stop',()=>{
  const audio=new GameAudio(),ctx=synthContext();audio.ctx=ctx;audio.bgmBus={};
  audio.note([0,1,60,0,0,48,0,{velocity:1,pitch:[[0,60],[.25,66]],gain:[[0,0],[.5,1]]}],2);
  const oscillators=ctx.nodes.filter(n=>n.type==='osc');assert.equal(oscillators.length,1);
  assert.ok(oscillators[0].frequency.calls.some(c=>c[0]==='linear'&&c[2]===2.25));
  assert.ok(ctx.nodes.some(n=>n.gain.calls.some(c=>c[0]==='target'&&c[1]===1&&c[2]===2.5)));
  audio.stopMusic();assert.equal(oscillators[0].stopAt,1.03);assert.equal(audio.voices.size,0);
});
test('SFX decode retries are bounded and separate from music status',async()=>{
  const status=[],errors=[],audio=new GameAudio(s=>status.push(s));audio.onEffectError=s=>errors.push(s);let count=0;audio.enabled=true;audio.ctx={state:'running',currentTime:0,decodeAudioData:()=>{count++;return Promise.reject(new Error('decode'));}};
  for(let i=0;i<8;i++){audio.ctx.currentTime=i;await audio.effect('heal');}assert.equal(count,3);assert.equal(status.length,0);assert.equal(errors.length,3);assert.equal(audio.buffers.has('heal'),false);
});
test('preset patch preserves speed, gain and unrelated instrument levels, then matches current tone',()=>{
  const audio=new GameAudio();audio.tune({...DEFAULT_TUNING,tempo:.9,gain:1.4,bass:.2});audio.tune(AUDIO_PRESETS.battle.values);
  assert.deepEqual([audio.tuning.tempo,audio.tuning.gain,audio.tuning.bass],[.9,1.4,.2]);assert.equal(matchingPreset(audio.tuning),'battle');
});
test('hidden actions make no sound, visible actions remain and turn cues are allied only',()=>{
  const b={visible:p=>p.q<2};assert.deepEqual(audibleEvents(b,[{type:'summon',q:8,r:0}]),[]);
  assert.deepEqual(audibleEvents(b,[{type:'turn',team:1},{type:'turn',team:0},{type:'attack',from:{q:8},to:{q:1}}]).map(e=>e.type),['turn','attack']);
});
test('mix migration preserves mute and saved sliders, is idempotent, and records previous mix',()=>{
  const before={bgmVolume:0,sfxVolume:.24,audioTunings:{example:{tempo:.9}}},after=migrateAudioPreferences(before);
  assert.equal(after.bgmVolume,0);assert.equal(after.sfxVolume,.24);assert.deepEqual(after.previousAudioMix,{bgmVolume:0,sfxVolume:.24});assert.deepEqual(migrateAudioPreferences(after),after);assert.equal(before.audioMixVersion,undefined);
});
test('interrupted audio preserves on intent and can resume on the next gesture',async()=>{
  const statuses=[],audio=new GameAudio(s=>statuses.push(s));let blocked=true;
  audio.enabled=true;audio.ctx={state:'interrupted',currentTime:0,resume:async()=>{if(blocked)throw new Error('blocked');audio.ctx.state='running';},suspend:async()=>{}};
  audio.track=async()=>({notes:[],duration:1});
  await assert.rejects(audio.visibility(false));assert.equal(audio.enabled,true);assert.match(statuses.at(-1),/터치/);
  blocked=false;await audio.resume();assert.equal(audio.ctx.state,'running');assert.ok(audio.timer);audio.disable();
});

test('stage changes keep sound on and a failed score does not stop the previous music',async()=>{
  const audio=new GameAudio();audio.enabled=true;audio.ctx={state:'running',currentTime:0,suspend:async()=>{}};
  audio.track=async()=>({notes:[],duration:1});await audio.select(chooseTrack(1));
  const firstTimer=audio.timer;await audio.select(chooseTrack(1));assert.equal(audio.timer,firstTimer);
  await audio.select(chooseTrack(2));assert.equal(audio.enabled,true);assert.equal(audio.songId,chooseTrack(2));
  const secondTimer=audio.timer;audio.track=async()=>{throw new Error('bad score');};
  await assert.rejects(audio.select(chooseTrack(3)));assert.equal(audio.enabled,true);assert.equal(audio.timer,secondTimer);assert.equal(audio.songId,chooseTrack(2));
  audio.disable();assert.equal(audio.enabled,false);assert.equal(audio.timer,null);
});

test('loading a stage before the first gesture preserves saved sound intent without creating audio',async()=>{
  const audio=new GameAudio();audio.enabled=true;let loaded=false;audio.track=async()=>{loaded=true;};
  await audio.select(chooseTrack(4));assert.equal(audio.enabled,true);assert.equal(audio.ctx,undefined);assert.equal(loaded,false);assert.equal(audio.trackId,chooseTrack(4));
});

test('track switches do not drop decoded hits, while explicit mute cancels pending hits',async()=>{
  const audio=new GameAudio(),ctx=synthContext();let resolve,starts=0;
  ctx.decodeAudioData=()=>new Promise(r=>resolve=r);ctx.suspend=async()=>{};
  const create=ctx.createBufferSource;ctx.createBufferSource=()=>{const n=create();n.start=()=>starts++;return n;};
  audio.ctx=ctx;audio.enabled=true;audio.fx={};audio.track=async()=>({notes:[],duration:1});
  const hit=audio.effect('attack');await audio.select(chooseTrack(2));resolve({});await hit;assert.equal(starts,1);
  const pending=audio.effect('down');audio.disable();resolve({});await pending;assert.equal(starts,1);
});

test('physical hit and counter sound at their damage cues, without duplicate wind-up or spell hits',async()=>{
  const {planPresentation}=await import('../src/presentation.js');
  const cues=planPresentation([{type:'attack'},{type:'damage',kind:'공격'}, {type:'damage',kind:'반격',sourceId:2,q:0,r:0}],{units:[{id:2,q:1,r:0}]},0);
  assert.deepEqual(cues.filter(e=>presentationSound(e)==='attack').map(e=>e.start),[300,1100]);
  assert.equal(presentationSound({type:'damage',kind:'공격',amount:0}),'attack');
  assert.equal(presentationSound({type:'spell'}),'spell');assert.equal(presentationSound({type:'damage',kind:'화염'}),null);
});

test('a gesture retries a resume that the browser has left pending',async()=>{
  const audio=new GameAudio();let release,calls=0;audio.enabled=true;
  audio.ctx={state:'suspended',currentTime:0,suspend:async()=>{},resume:()=>{calls++;if(calls===1)return new Promise(r=>release=r);audio.ctx.state='running';release();return Promise.resolve();}};
  audio.track=async()=>({notes:[],duration:1});const background=audio.resume();await audio.resume(true);await background;
  assert.equal(calls,2);assert.ok(audio.timer);assert.equal(audio.enabled,true);audio.disable();
});
