import test from 'node:test';
import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {parseMidi,chooseTrack,GameAudio,AUDIO_TRACKS,DEFAULT_TUNING,sanitizeTuning,scoreHeadroom,instrumentGroup} from '../src/audio.js';
import {REFERENCE_MEDIA} from '../src/reference-media.js';
import {MASTERS,SUMMONS} from '../src/data.js';
import {referenceFrame,referenceSprite} from '../src/renderer.js';

function midi(events){const header=Buffer.from('4d546864000000060000000100604d54726b','hex'),size=Buffer.alloc(4);size.writeUInt32BE(events.length);return Buffer.concat([header,size,Buffer.from(events)]);}
test('MIDI tempo, running status and sustain change audible duration',()=>{
  const song=parseMidi(midi([0,0xc0,40,0,0xb0,64,127,0,0x90,60,100,96,60,0,0,255,81,3,15,66,64,96,0xb0,64,0,0,255,47,0]));
  assert.equal(song.notes.length,1);assert.equal(song.notes[0][1],1.5);assert.equal(song.notes[0][5],40);assert.equal(song.duration,1.5);
});
test('MIDI rejects truncated files, unsupported timing and invalid running status',()=>{
  assert.throws(()=>parseMidi(midi([0,60,100])));assert.throws(()=>parseMidi(midi([0,255,81,9,1])));assert.throws(()=>parseMidi(new Uint8Array(3)));
  const bad=midi([0,255,47,0]);bad.writeUInt16BE(0xe728,12);assert.throws(()=>parseMidi(bad));
});
test('all 19 supplied scores decompress and yield finite, ordered notes',()=>{
  assert.equal(REFERENCE_MEDIA.tracks.length,19);
  for(const t of REFERENCE_MEDIA.tracks){const song=parseMidi(gunzipSync(Buffer.from(t.gzip,'base64')));assert.ok(song.notes.length>0,t.id);assert.ok(song.duration>0&&song.duration<3600,t.id);let previous=-1;for(const n of song.notes){assert.ok(n.every(Number.isFinite),t.id);assert.ok(n[0]>=previous&&n[1]>0,t.id);previous=n[0];}}
  for(let stage=1;stage<=30;stage++)assert.ok(REFERENCE_MEDIA.tracks.some(t=>t.id===chooseTrack(stage)));
});
test('every character has two PNG atlases; custom uploads take priority',()=>{
  assert.equal(Object.keys(REFERENCE_MEDIA.sprites).length,51);
  for(const u of [...MASTERS,...SUMMONS])for(const team of [0,1]){const src=referenceSprite({...u,team}),png=Buffer.from(src.split(',')[1],'base64');assert.equal(png.toString('ascii',1,4),'PNG');assert.equal(png.readUInt32BE(16),576);assert.equal(png.readUInt32BE(20),864);assert.equal(referenceSprite({...u,team,sprite:'custom.png'}),null);}
  for(let facing=0;facing<6;facing++)for(const state of ['idle','move','attack','cast','hit','down'])for(let f=0;f<8;f++)assert.ok(referenceFrame({facing},state,f)>=0&&referenceFrame({facing},state,f)<54);
});
test('turning sound off while a track is loading cannot restart music',async()=>{
  const audio=new GameAudio();let resolve;audio.enabled=true;audio.ctx={currentTime:0,suspend:()=>Promise.resolve()};audio.track=()=>new Promise(r=>resolve=r);const pending=audio.select(chooseTrack(1));audio.disable();resolve({notes:[[0,1,60,1,0,0,0]],duration:1});await pending;assert.equal(audio.enabled,false);assert.equal(audio.timer,null);
});
test('a stale failed track request cannot disable the newer selection',async()=>{
  const audio=new GameAudio();let reject;audio.enabled=true;audio.ctx={currentTime:0,state:'suspended',suspend:()=>Promise.resolve()};audio.track=id=>id===chooseTrack(1)?new Promise((_,r)=>reject=r):Promise.resolve({notes:[],duration:1});const older=audio.select(chooseTrack(1));await audio.select(chooseTrack(2));reject(new Error('old failed'));await older;assert.equal(audio.enabled,true);assert.equal(audio.trackId,chooseTrack(2));audio.disable();
});

test('stored tuning rejects invalid fields and bounds unsafe values',()=>{
  const tuning=sanitizeTuning({brightness:Infinity,tempo:9,reverb:-1,warmth:99,gain:NaN,drums:'1',unknown:5});
  assert.equal(tuning.brightness,DEFAULT_TUNING.brightness);assert.equal(tuning.tempo,1.25);assert.equal(tuning.reverb,0);assert.equal(tuning.warmth,4);assert.equal(tuning.gain,1);assert.equal(tuning.drums,DEFAULT_TUNING.drums);assert.equal(tuning.unknown,undefined);
});
test('per-track settings survive reload, remain independent, and can apply to all scores',async()=>{
  const audio=new GameAudio(),first=AUDIO_TRACKS[0].id,second=AUDIO_TRACKS[1].id;
  await audio.select(first);audio.tune({...audio.getTuning(),brightness:2300});
  await audio.select(second);assert.equal(audio.getTuning().brightness,4200);
  const saved=audio.tune({...audio.getTuning(),brightness:5900});saved.unknown={tempo:100};
  const restored=new GameAudio();restored.loadTunings(saved);await restored.select(first);assert.equal(restored.tuning.brightness,2300);assert.equal(restored.tunings.unknown,undefined);
  restored.tune({...restored.getTuning(),tempo:.9},true);assert.equal(Object.keys(restored.tunings).length,19);
  await restored.select(second);assert.equal(restored.tuning.tempo,.9);assert.equal(restored.tuning.brightness,2300);
  restored.tune({...restored.getTuning(),brightness:3200});assert.equal(restored.getTuning(first).brightness,2300);
});
test('dense scores receive headroom without boosting quiet scores',()=>{
  const note=[0,1,60,1,0,0,0];assert.equal(scoreHeadroom({notes:[note]}),1);
  assert.ok(scoreHeadroom({notes:Array.from({length:8},()=>note)})<=.4);
  assert.equal(scoreHeadroom({notes:[note,[1,1,60,1,0,0,0]]}),1);
  for(const t of REFERENCE_MEDIA.tracks){const gain=scoreHeadroom(parseMidi(gunzipSync(Buffer.from(t.gzip,'base64'))));assert.ok(gain>=.4&&gain<=1,t.id);}
});
test('tempo changes preserve position and schedule subsequent notes at the new speed',()=>{
  const audio=new GameAudio();audio.ctx={currentTime:5,state:'running'};audio.song={notes:[[4.1,.2,60,1,0,0,0]],duration:10};audio.epoch=1;audio.cursor=0;audio.enabled=true;
  const played=[];audio.note=(n,at)=>played.push(at);audio.tune({...DEFAULT_TUNING,tempo:1.25});
  assert.ok(Math.abs((5-audio.epoch)*1.25-4)<1e-9);audio.schedule();assert.ok(Math.abs(played[0]-5.08)<1e-9);assert.equal(audio.cursor,1);
});
test('GM families and percussion route to the intended mix groups',()=>{
  assert.equal(instrumentGroup(24),'plucks');assert.equal(instrumentGroup(32),'bass');assert.equal(instrumentGroup(48),'strings');assert.equal(instrumentGroup(56),'brass');assert.equal(instrumentGroup(72),'winds');assert.equal(instrumentGroup(80),'synth');assert.equal(instrumentGroup(0,9),'drums');
});
