import test from 'node:test';
import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {parseMidi,chooseTrack,GameAudio} from '../src/audio.js';
import {REFERENCE_MEDIA} from '../src/reference-media.js';
import {MASTERS,SUMMONS} from '../src/data.js';
import {referenceFrame,referenceSprite} from '../src/renderer.js';

function midi(events){const header=Buffer.from('4d546864000000060000000100604d54726b','hex'),size=Buffer.alloc(4);size.writeUInt32BE(events.length);return Buffer.concat([header,size,Buffer.from(events)]);}
test('MIDI tempo, running status and sustain change audible duration',()=>{
  const song=parseMidi(midi([0,0xc0,40,0,0xb0,64,127,0,0x90,60,100,96,60,0,0,255,81,3,15,66,64,96,0xb0,64,0,0,255,47,0]));
  assert.equal(song.notes.length,1);assert.equal(song.notes[0][1],1.5);assert.equal(song.notes[0][5],40);assert.equal(song.duration,1.5);
});
test('MIDI rejects truncated files, unsupported timing and invalid running status',()=>{
  assert.throws(()=>parseMidi(midi([0,60,100])));assert.throws(()=>parseMidi(midi([0,255,81,9,1])));assert.throws(()=>parseMidi(new Uint8Array(3)));
  const bad=midi([0,255,47,0]);bad.writeUInt16BE(0xe728,12);assert.throws(()=>parseMidi(bad));
});
test('all 19 supplied scores decompress and yield finite, ordered notes',()=>{
  assert.equal(REFERENCE_MEDIA.tracks.length,19);
  for(const t of REFERENCE_MEDIA.tracks){const song=parseMidi(gunzipSync(Buffer.from(t.gzip,'base64')));assert.ok(song.notes.length>0,t.id);assert.ok(song.duration>0&&song.duration<3600,t.id);let previous=-1;for(const n of song.notes){assert.ok(n.every(Number.isFinite),t.id);assert.ok(n[0]>=previous&&n[1]>0,t.id);previous=n[0];}}
  for(let stage=1;stage<=30;stage++)assert.ok(REFERENCE_MEDIA.tracks.some(t=>t.id===chooseTrack(stage)));
});
test('every character has two PNG atlases; custom uploads take priority',()=>{
  assert.equal(Object.keys(REFERENCE_MEDIA.sprites).length,51);
  for(const u of [...MASTERS,...SUMMONS])for(const team of [0,1]){const src=referenceSprite({...u,team}),png=Buffer.from(src.split(',')[1],'base64');assert.equal(png.toString('ascii',1,4),'PNG');assert.equal(png.readUInt32BE(16),576);assert.equal(png.readUInt32BE(20),864);assert.equal(referenceSprite({...u,team,sprite:'custom.png'}),null);}
  for(let facing=0;facing<6;facing++)for(const state of ['idle','move','attack','cast','hit','down'])for(let f=0;f<8;f++)assert.ok(referenceFrame({facing},state,f)>=0&&referenceFrame({facing},state,f)<54);
});
test('turning sound off while a track is loading cannot restart music',async()=>{
  const audio=new GameAudio();let resolve;audio.enabled=true;audio.ctx={currentTime:0,suspend:()=>Promise.resolve()};audio.track=()=>new Promise(r=>resolve=r);const pending=audio.select(chooseTrack(1));audio.disable();resolve({notes:[[0,1,60,1,0,0,0]],duration:1});await pending;assert.equal(audio.enabled,false);assert.equal(audio.timer,null);
});
test('a stale failed track request cannot disable the newer selection',async()=>{
  const audio=new GameAudio();let reject;audio.enabled=true;audio.ctx={currentTime:0,state:'suspended',suspend:()=>Promise.resolve()};audio.track=id=>id===chooseTrack(1)?new Promise((_,r)=>reject=r):Promise.resolve({notes:[],duration:1});const older=audio.select(chooseTrack(1));await audio.select(chooseTrack(2));reject(new Error('old failed'));await older;assert.equal(audio.enabled,true);assert.equal(audio.trackId,chooseTrack(2));audio.disable();
});
