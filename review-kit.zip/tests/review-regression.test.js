import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {Battle} from '../src/engine.js';
import {MASTERS,SUMMONS,LIMITS} from '../src/data.js';
import {generateStage} from '../src/maps.js';
import {key} from '../src/hex.js';
import {Renderer} from '../src/renderer.js';
import * as labCore from '../src/lab-core.js';
const {LabSession,createLabBattle,replayBundle,stateHash,checkInvariants}=labCore;

test('restore validates every spell-list consumer before accepting a replay',()=>{
  for(const list of [null,{},42,'blink',[null],[12],['not-a-spell'],['toString']]){
    for(const field of ['unit','extra','enemy']){
      const data=new LabSession(createLabBattle({scenario:'undo'})).bundle();
      if(field==='unit')data.initial.units[0].spells=list;
      if(field==='extra')data.initial.extraSpells=list;
      if(field==='enemy')data.initial.stage.enemySpells=list;
      data.finalHash=stateHash(data.initial);
      assert.throws(()=>replayBundle(data),/저장 데이터 오류/);
    }
  }
});

function placement(spell){const b=createLabBattle({scenario:'undo'});b.extraSpells=[spell];b.units[1].q=3;return b;}
for(const spell of ['blink','decoy','trap']){
  test(`${spell} rejects occupied, blocked, water, distant and unseen tiles without mutation`,()=>{
    const b=placement(spell);b.active.movementType=0;b.addUnit('fa-rancell',0,{q:2,r:2});
    for(const [p,terrain] of [[{q:1,r:2},'wall'],[{q:2,r:4},'void'],[{q:1,r:4},'deep_water']])b.tiles.get(key(p)).terrain=terrain;
    // Height blocks the line to this otherwise valid empty target.
    b.tiles.get('2,2').elevation=9;
    const before=stateHash(b);
    for(const pos of [{q:1,r:3},{q:3,r:3},{q:2,r:2},{q:1,r:2},{q:2,r:4},{q:1,r:4},{q:9,r:1},{q:3,r:1}]){
      assert.equal(b.spellTargets(b.active,spell).some(t=>key(t)===key(pos)),false,JSON.stringify(pos));
      assert.equal(b.cast(spell,pos),false);assert.equal(stateHash(b),before);
    }
  });
  test(`${spell} succeeds on empty ground and survives scheduling, save and replay`,()=>{
    const b=placement(spell),caster=b.active,mp=b.mana[0],count=b.units.length;
    const s=new LabSession(b,'review-fix');assert.equal(s.act({type:'cast',spell,q:2,r:3}),true);
    if(spell==='blink')assert.equal(key(caster),'2,3');
    if(spell==='decoy'){assert.equal(b.units.length,count+1);const clone=b.units.at(-1);assert.equal(clone.isDecoy,true);assert.ok(Number.isFinite(clone.nextTime));assert.equal(key(clone),'2,3');}
    if(spell==='trap')assert.equal(b.traps.length,1);
    assert.ok(b.mana[0]<mp);assert.deepEqual(checkInvariants(b),[]);
    assert.equal(stateHash(Battle.restore(structuredClone(b.serialize()))),stateHash(b));
    for(let i=0;i<8;i++)s.act({type:'wait'});
    assert.deepEqual(replayBundle(s.bundle(),'review-fix').reproducedErrors,[]);
  });
}
test('decoy respects summon cap and trap does not stack on an existing trap',()=>{
  const b=placement('decoy');for(let i=0;i<LIMITS.maxSummons;i++)b.addUnit('fa-rancell',0,{q:i,r:0});
  const before=stateHash(b);assert.equal(b.cast('decoy',{q:2,r:3}),false);assert.equal(stateHash(b),before);
  const t=placement('trap');t.traps=[{q:2,r:3,team:0,duration:2}];assert.equal(t.cast('trap',{q:2,r:3}),false);
});

function pointerHarness(){
  const listeners={},canvas={getBoundingClientRect:()=>({left:0,top:0}),setPointerCapture(){},addEventListener:(name,fn)=>listeners[name]=fn};
  const r=Object.create(Renderer.prototype);let clicks=0,zooms=0;
  Object.assign(r,{canvas,pointers:new Map(),pan:{x:0,y:0},pick:()=>({q:0,r:0}),zoom:()=>zooms++,callbacks:{click:()=>clicks++}});r.bind();
  return {r,send:(type,id,x,y)=>listeners['pointer'+type]({pointerId:id,clientX:x,clientY:y}),counts:()=>({clicks,zooms})};
}
test('pointer gesture boundary never pans and clicks in the same gesture',()=>{
  for(const pixels of [0,4,5,6,7,8,20]){
    const h=pointerHarness();h.send('down',1,20,20);h.send('move',1,20+pixels,20);h.send('up',1,20+pixels,20);
    assert.equal(h.counts().clicks,pixels<=5?1:0);assert.equal(h.r.pan.x,pixels>5?pixels:0);
  }
  const h=pointerHarness();h.send('down',1,20,20);for(const x of [22,24,26,20])h.send('move',1,x,20);h.send('up',1,20,20);assert.equal(h.counts().clicks,0);
});
test('pinch and cancel suppress commands, and a following normal tap still works',()=>{
  const h=pointerHarness();h.send('down',1,20,20);h.send('down',2,40,20);h.send('move',2,50,20);h.send('up',2,50,20);h.send('up',1,20,20);assert.equal(h.counts().clicks,0);assert.equal(h.counts().zooms,1);
  h.send('down',1,20,20);h.send('cancel',1,20,20);assert.equal(h.counts().clicks,0);
  h.send('down',1,20,20);h.send('up',1,20,20);assert.equal(h.counts().clicks,1);
});

// Run the actual UI module with only browser surfaces stubbed. This exercises
// the import handler and rollback, rather than a duplicated adoption algorithm.
async function labUI(){
  const elements=new Map();
  function element(){return {_value:'',children:[],textContent:'',disabled:false,classList:{toggle(){}},get value(){return this._value;},set value(v){this._value=String(v);},get options(){return this.children;},replaceChildren(...items){if(this.failNext){this.failNext=false;throw new Error('simulated render failure');}this.children=items;this._value=String(items[0]?.value??'');}};}
  const get=id=>{if(!elements.has(id))elements.set(id,element());return elements.get(id);};
  class RendererStub{constructor(){this.pan={x:0,y:0};this.scale=1;this.effects=[];}setBattle(b){this.battle=b;this.pan={x:0,y:0};this.scale=1;this.effects=[];}consume(){}}
  const context=vm.createContext({...labCore,Battle,MASTERS,SUMMONS,generateStage,key,Renderer:RendererStub,LAB_BUILD:'review-test',structuredClone,document:{querySelector:get,querySelectorAll:()=>[],createElement:element}});
  const source=(await readFile(new URL('../src/lab.js',import.meta.url),'utf8')).replace(/^import .+;\r?\n/gm,'');vm.runInContext(source,context);
  const run=code=>vm.runInContext(code,context);
  run("step({type:'facing',facing:4})");
  return {get,run,async load(data){const raw=JSON.stringify(data);await get('#import').onchange({target:{files:[{size:raw.length,text:async()=>raw}],value:'file'}});}};
}
test('failed JSON imports preserve the existing session, trace, renderer and review form',async()=>{
  const ui=await labUI(),prior=ui.run('session'),renderer=ui.run('labRenderer');ui.get('#actual').value='existing notes';
  const hash=stateHash(prior.battle);
  for(const bad of [{},12,['bad-id']]){
    const data=new LabSession(createLabBattle({scenario:'undo'}),'review-test','malformed').bundle();data.initial.units[0].spells=bad;data.finalHash=stateHash(data.initial);await ui.load(data);
    assert.equal(ui.run('session'),prior);assert.equal(renderer.battle,prior.battle);assert.equal(stateHash(prior.battle),hash);assert.equal(prior.steps.length,1);assert.equal(ui.get('#actual').value,'existing notes');assert.match(ui.get('#status').textContent,/불러오기 실패/);
  }
});
test('render failure during adoption rolls back, then a valid different-build import succeeds',async()=>{
  const ui=await labUI(),prior=ui.run('session'),renderer=ui.run('labRenderer');renderer.pan={x:123,y:456};renderer.scale=1.7;
  const summary=ui.get('#summary').textContent,data=new LabSession(createLabBattle({scenario:'undo'}),'other-build','new experiment').bundle();
  ui.get('#trace').failNext=true;await ui.load(data);
  assert.equal(ui.run('session'),prior);assert.equal(renderer.battle,prior.battle);assert.deepEqual(renderer.pan,{x:123,y:456});assert.equal(renderer.scale,1.7);assert.equal(ui.get('#summary').textContent,summary);assert.match(ui.get('#status').textContent,/simulated render failure/);
  await ui.load(data);assert.notEqual(ui.run('session'),prior);assert.equal(ui.run('session.label'),'new experiment');assert.equal(renderer.battle,ui.run('session.battle'));assert.match(ui.get('#status').textContent,/빌드가 다릅니다/);
});
