import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

test('pending battle result waits for settings to close and ignores an older battle',async()=>{
  const source=await readFile(new URL('../src/main.js',import.meta.url),'utf8');
  const begin=source.indexOf('let pendingResult='),end=source.indexOf('function modalHead',begin);
  assert.ok(begin>=0&&end>begin);
  let shown=0,onClose;
  const battle={},dialog={open:true,addEventListener(event,fn){if(event==='close')onClose=fn;}};
  const mobileUI={isOpen:false};
  const ctx=vm.createContext({battle,dialog,mobileUI,showResult(){shown++;},scheduleAI(){}});
  vm.runInContext(source.slice(begin,end),ctx);
  vm.runInContext('pendingResult=battle;flushResult()',ctx);assert.equal(shown,0);
  dialog.open=false;mobileUI.isOpen=true;onClose();assert.equal(shown,0);mobileUI.isOpen=false;onClose();assert.equal(shown,1);onClose();assert.equal(shown,1);
  vm.runInContext('pendingResult=battle;battle={};flushResult()',ctx);assert.equal(shown,1);
});
