import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('../sw.js',import.meta.url),'utf8');
function worker({online=true}={}){
  const listeners={},stores=new Map([['vt-offline-v0',new Map()]]),fetched=[];
  const store=name=>{if(!stores.has(name))stores.set(name,new Map());const m=stores.get(name);return {put:async(req,res)=>{m.set(new URL(req.url??req,'https://x.test/vt/').href.split('?')[0],res);},addAll:async urls=>{for(const u of urls)m.set(new URL(u.url??u,'https://x.test/vt/').href,{body:'core '+(u.url??u)});}};};
  const caches={open:async name=>store(name),keys:async()=>[...stores.keys()],delete:async name=>stores.delete(name),match:async(req)=>{const href=new URL(req.url??req,'https://x.test/vt/').href.split('?')[0];for(const m of stores.values())if(m.has(href))return m.get(href);return undefined;}};
  const self={location:{origin:'https://x.test'},addEventListener:(n,f)=>listeners[n]=f,skipWaiting:()=>{},clients:{claim:()=>{}}};
  const fetch=async req=>{fetched.push(req.url);if(!online)throw new TypeError('offline');return {ok:true,type:'basic',body:'net '+req.url,clone(){return {...this,body:'copy '+req.url};}};};
  vm.runInNewContext(source,{self,caches,fetch,URL,Request:class{constructor(url){this.url=url;}},Promise,console});
  return {listeners,stores,fetched,setOnline:v=>online=v};
}
async function dispatch(w,request){let out;w.listeners.fetch({request,respondWith:p=>out=p});return out;}
const get=(url,mode='no-cors')=>({url,method:'GET',mode});

test('service worker serves the network first and caches a copy for offline use',async()=>{
  const w=worker();
  const res=await dispatch(w,get('https://x.test/vt/assets/reference-media.js?v=2'));
  assert.equal(res.body,'net https://x.test/vt/assets/reference-media.js?v=2');
  await new Promise(r=>setImmediate(r));
  w.setOnline(false);
  const off=await dispatch(w,get('https://x.test/vt/assets/reference-media.js'));
  assert.match(off.body,/^copy /);
});
test('offline navigation falls back to the cached game page; zip/json and cross-origin are not cached',async()=>{
  const w=worker();
  let waited;w.listeners.install({waitUntil:p=>waited=p});await waited;
  await dispatch(w,get('https://x.test/vt/review-kit.zip'));await new Promise(r=>setImmediate(r));
  assert.equal([...w.stores.get('vt-offline-v1').keys()].some(k=>k.endsWith('.zip')),false);
  assert.equal(await dispatch(w,get('https://other.test/a.js')),undefined);
  w.setOnline(false);
  const page=await dispatch(w,get('https://x.test/vt/?stage=3','navigate'));
  assert.match(page.body,/^core \.\/(index\.html)?$/);
  await assert.rejects(dispatch(w,get('https://x.test/vt/missing.png')));
});
test('activation removes only older offline caches',async()=>{
  const w=worker();w.stores.set('other-app',new Map());
  let waited;w.listeners.activate({waitUntil:p=>waited=p});await waited;
  assert.deepEqual([...w.stores.keys()].sort(),['other-app']);
});
