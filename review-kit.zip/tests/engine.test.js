import test from 'node:test';
import assert from 'node:assert/strict';
import { MinHeap, distance, key, findPath, reachable, hexToPixel, pixelToHex } from '../src/hex.js';
import { Battle } from '../src/engine.js';
import { generateStage, validateStage, normalizeStage } from '../src/maps.js';
import { MASTERS, BOSSES, SUMMONS } from '../src/data.js';

function arena(){return {id:1,name:'검증 전장',gridWidth:7,gridHeight:5,playerMasterStart:{q:0,r:2},enemyMasterStart:{q:6,r:2},manaStones:[{q:1,r:2},{q:5,r:2}],tiles:Array.from({length:35},(_,i)=>({q:i%7,r:Math.floor(i/7),terrain:'grass',elevation:0}))};}
test('hex distance and projection are consistent for negative axial coordinates',()=>{assert.equal(distance({q:-2,r:3},{q:2,r:-1}),4);for(let q=-8;q<=8;q++)for(let r=-8;r<=8;r++){const p=hexToPixel({q,r});assert.deepEqual(pixelToHex(p.x,p.y),{q,r});}});
test('min heap maintains priority and stable ID tie breaks after interleaved updates',()=>{const h=new MinHeap();for(const [id,time] of [[9,20],[4,10],[2,10],[5,1],[6,30]])h.push({id,time});assert.equal(h.pop().id,5);h.push({id:1,time:9});assert.deepEqual(Array.from({length:5},()=>h.pop().id),[1,2,4,9,6]);assert.equal(h.pop(),undefined);});
test('weighted routes avoid expensive terrain and occupied tiles',()=>{const map=new Map(arena().tiles.map(t=>[key(t),t]));map.get('2,2').terrain='forest';const cost=t=>t.terrain==='forest'?8:1;const path=findPath({q:0,r:2},{q:4,r:2},map,cost,new Set(['1,2']));assert.equal(key(path[0]),'0,2');assert.equal(key(path.at(-1)),'4,2');assert.ok(!path.some(p=>key(p)==='1,2'||key(p)==='2,2'));const r=reachable({q:0,r:2},2,map,cost,new Set(['1,2']));assert.ok(!r.dist.has('1,2'));assert.ok(!r.dist.has('4,2'));});
