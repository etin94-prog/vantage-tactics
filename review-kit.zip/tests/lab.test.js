import test from 'node:test';
import assert from 'node:assert/strict';
import {LabSession,createLabBattle,replayBundle,stateHash,labAction,checkInvariants} from '../src/lab-core.js';
test('lab export is detached and reproduces accepted and rejected actions',()=>{
  const s=new LabSession(createLabBattle({scenario:'undo'}),'test-build');
  s.act({type:'move',q:2,r:3});s.act({type:'move',q:3,r:3});s.act({type:'undo'});s.act({type:'wait'});
  const data=s.bundle({reviewer:'Claude'}),r=replayBundle(JSON.parse(JSON.stringify(data)),'test-build');
  assert.equal(stateHash(r.session.battle),stateHash(s.battle));assert.equal(r.buildMatch,true);assert.equal(data.steps[1].accepted,false);
  data.initial.units[0].hp=1;assert.equal(s.initial.units[0].hp,10);
});
test('lab identifies version differences and detects tampering at the precise step',()=>{
  const s=new LabSession(createLabBattle({scenario:'undo'}),'old');s.act({type:'move',q:2,r:3});
  assert.equal(replayBundle(s.bundle(),'new').buildMatch,false);
  const data=s.bundle();data.steps[0].postHash='incorrect';assert.throws(()=>replayBundle(data),/1행동 재현/);
  assert.throws(()=>replayBundle({...s.bundle(),schema:'other'}),/지원하지/);
  assert.throws(()=>labAction(s.battle,{type:'eval',code:'alert(1)'}),/허용하지/);
  assert.throws(()=>labAction(s.battle,{type:'move',q:NaN,r:3}),/좌표/);
});
test('lab snapshot and fixtures do not modify independent campaign battles',()=>{
  const a=createLabBattle(),b=createLabBattle(),hash=stateHash(b);a.units[0].hp=2;
  assert.equal(stateHash(b),hash);
  for(const scenario of ['undo','healing','freeze','area','tide','zoc'])assert.deepEqual(checkInvariants(createLabBattle({scenario})),[]);
});

test('exception-producing actions remain in exported trace and replay as matching failures',()=>{
  const s=new LabSession(createLabBattle({scenario:'undo'}),'test');
  assert.throws(()=>s.act({type:'unknown-action'}),/허용하지/);
  assert.equal(s.steps.length,1);assert.ok(s.steps[0].error);
  const r=replayBundle(s.bundle(),'test');assert.equal(r.reproducedErrors.length,1);assert.equal(r.reproducedErrors[0].step,1);
});
test('a caster killed by its own area spell advances the scheduler and remains replayable',()=>{
  const b=createLabBattle({scenario:'area'}),caster=b.active;caster.hp=1;
  const s=new LabSession(b,'test');assert.equal(s.act({type:'cast',spell:'v2-20',q:4,r:3}),true);
  assert.equal(caster.hp,0);assert.ok(b.active);assert.notEqual(b.activeId,caster.id);
  assert.deepEqual(replayBundle(s.bundle(),'test').reproducedErrors,[]);
});
test('petrified defenders cannot counterattack',()=>{
  const b=createLabBattle({scenario:'undo'}),u=b.active,t=b.units[1];t.q=2;t.r=3;t.facing=3;t.statuses.petrify={expiresAt:b.time+120};u.attack=0;t.defense=20;
  assert.equal(b.attack(t.id),true);assert.equal(u.hp,10);
});

test('invalid status records are rejected before a replay can enter the engine',()=>{
  const s=new LabSession(createLabBattle({scenario:'undo'}),'test'),data=s.bundle();
  for(const status of [null,[],{expiresAt:'later'},{remaining:-1}]){
    data.initial.units[0].statuses.freeze=status;data.finalHash=stateHash(data.initial);
    assert.throws(()=>replayBundle(data,'test'),/유닛 저장 데이터 오류/);
  }
});
