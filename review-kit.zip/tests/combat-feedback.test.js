import test from 'node:test';
import assert from 'node:assert/strict';
import {Battle} from '../src/engine.js';
import {Renderer} from '../src/renderer.js';

function encounter(){
  const stage={id:1,name:'Damage feedback',gridWidth:8,gridHeight:5,playerMasterStart:{q:0,r:0},enemyMasterStart:{q:7,r:4,classId:'duke'},manaStones:[],tiles:Array.from({length:40},(_,i)=>({q:i%8,r:Math.floor(i/8),terrain:'grass',elevation:0}))};
  const b=new Battle(stage,'fighter');
  const a=b.addUnit('fa-rancell',0,{q:3,r:2}),d=b.addUnit('fa-rancell',1,{q:4,r:2});
  d.facing=3;b.activeId=a.id;b.events=[];return {b,a,d};
}
test('natial exchange records separate attack/counter HP snapshots without changing damage',()=>{
  const {b,a,d}=encounter();const before=[a.hp,d.hp];
  assert.equal(b.attack(d.id),true);
  const hits=b.events.filter(e=>e.type==='damage');assert.equal(hits.length,2);
  assert.equal(hits[0].kind,'공격');assert.equal(hits[0].id,d.id);assert.equal(hits[0].sourceId,a.id);
  assert.equal(hits[1].kind,'반격');assert.equal(hits[1].id,a.id);assert.equal(hits[1].sourceId,d.id);
  for(const [i,hp] of [[0,before[1]],[1,before[0]]]){assert.equal(hits[i].hpBefore,hp);assert.equal(hits[i].hpAfter,hp-hits[i].amount);assert.equal(hits[i].maxHp,10);}
  assert.equal(hits[0].hpAfter,d.hp);assert.equal(hits[1].hpAfter,a.hp);
});
test('zero and lethal damage report actual HP loss and preserve per-hit snapshots',()=>{
  const {b,a,d}=encounter();d.hp=3;
  b.inflict(a,d,0,{kind:'공격'});b.inflict(a,d,99,{kind:'반격'});
  const hits=b.events.filter(e=>e.type==='damage');
  assert.deepEqual(hits.map(e=>[e.amount,e.hpBefore,e.hpAfter]),[[0,3,3],[3,3,0]]);
  assert.equal(b.events.filter(e=>e.type==='down').length,1);
});
test('opening the combat panel preserves the viewed battle location instead of following the next actor',()=>{
  const previous=globalThis.devicePixelRatio;globalThis.devicePixelRatio=1;
  try{
    const renderer={width:390,height:532,scale:.95,pan:{x:100,y:250},canvas:{getBoundingClientRect:()=>({width:390,height:400})},fit(){throw new Error('Must not reset camera for a panel height change');}};
    Renderer.prototype.resize.call(renderer);
    assert.deepEqual(renderer.pan,{x:100,y:184});assert.equal(renderer.scale,.95);
  }finally{if(previous===undefined)delete globalThis.devicePixelRatio;else globalThis.devicePixelRatio=previous;}
});
