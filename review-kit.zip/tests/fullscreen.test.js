import test from 'node:test';
import assert from 'node:assert/strict';
import {initFullscreen} from '../src/fullscreen.js';

function fullscreenFixture({supported=true,rejected=false,installed=false}={}){
  const attrs={},listeners={};
  const button={setAttribute(k,v){attrs[k]=v;}};
  const help={open:false,showModal(){this.open=true;},close(){this.open=false;}};
  const closer={};
  const nodes={'#fullscreen-btn':button,'#fullscreen-help':help,'#fullscreen-help-close':closer};
  const calls=[];
  const doc={documentElement:{},querySelector:s=>nodes[s],addEventListener:(name,fn)=>{listeners[name]=fn;},fullscreenEnabled:supported,
    async exitFullscreen(){doc.fullscreenElement=null;listeners.fullscreenchange();}};
  if(supported)doc.documentElement.requestFullscreen=async options=>{
    calls.push(options);
    if(rejected)throw new Error('Fullscreen denied');
    doc.fullscreenElement=doc.documentElement;listeners.fullscreenchange();
  };
  const media={matches:installed,addEventListener(){}};
  initFullscreen(doc,{matchMedia:()=>media,navigator:{}});
  return {doc,button,attrs,help,closer,calls,listeners};
}

test('fullscreen enters from button, requests hidden navigation and restores state on exit',async()=>{
  const f=fullscreenFixture();
  await f.button.onclick();
  assert.deepEqual(f.calls,[{navigationUI:'hide'}]);
  assert.equal(f.attrs['aria-pressed'],'true');
  assert.equal(f.help.open,false);
  await f.button.onclick();
  assert.equal(f.attrs['aria-pressed'],'false');
  assert.equal(f.button.disabled,false);
  // External exits (Escape/system back) also update the button.
  await f.button.onclick();f.doc.fullscreenElement=null;f.listeners.fullscreenchange();
  assert.equal(f.attrs['aria-label'],'전체화면으로 플레이');
});

test('unsupported or rejected fullscreen shows dismissible home-screen instructions',async()=>{
  for(const options of [{supported:false},{rejected:true}]){
    const f=fullscreenFixture(options);await f.button.onclick();
    assert.equal(f.help.open,true);
    assert.equal(f.attrs['aria-pressed'],'false');
    assert.equal(f.button.disabled,false);
    f.closer.onclick();assert.equal(f.help.open,false);
  }
});

test('installed standalone app needs no fullscreen entry button',()=>{
  assert.equal(fullscreenFixture({installed:true}).button.hidden,true);
});
