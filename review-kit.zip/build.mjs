import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=new URL('./',import.meta.url);
const files=['v2-reference','rules','spells','data','campaign','hex','maps','engine','target-area','event-visibility','renderer','audio','mobile-ui','main'];
const modules=await Promise.all(files.map(name=>readFile(new URL(`src/${name}.js`,root),'utf8')));
const code=modules.map(source=>source.replace(/^import .+;\r?\n/gm,'').replace(/^export /gm,'')).join('\n');
const script=`(()=>{'use strict';\n${code}\n})();`;
// Parse the entire portable build before writing a deliverable.
new Function(script);
await writeFile(new URL('assets/reference-media.js',root),(await readFile(new URL('src/reference-media.js',root),'utf8')).replace('export const REFERENCE_MEDIA','const REFERENCE_MEDIA'));
const [html,css]=await Promise.all([readFile(new URL('index.html',root),'utf8'),readFile(new URL('src/style.css',root),'utf8')]);
const portable=html.replace('<link rel="stylesheet" href="/src/style.css">',()=>`<style>${css}</style>`).replace('<script type="module" src="/src/main.js"></script>',()=>`<script src="assets/reference-media.js"></script><script>${script.replace(/<\/script/gi,'<\\/script')}</script>`);
await writeFile(new URL('play.html',root),portable,'utf8');
console.log(`Portable game built: ${fileURLToPath(new URL('play.html',root))}`);

const {buildLab}=await import('./scripts/build-lab.mjs');
console.log('Lab built: '+await buildLab());
