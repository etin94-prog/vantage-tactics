"""Read-only PE/x86 inspection. Never loads or executes the game binary.

Install capstone and pefile under .reference/analysis-tools to use this researcher tool.
Addresses are virtual addresses, not raw file offsets.
"""
from pathlib import Path
import argparse, hashlib, json, struct, sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / '.reference/analysis-tools'))
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_32
from capstone.x86 import X86_OP_IMM, X86_OP_MEM

PATH = ROOT / '.reference/VMO_WIN/vmv2.exe'
RAW = PATH.read_bytes()
SHA = hashlib.sha256(RAW).hexdigest()
assert SHA == 'daa647ff03cc1437fe5ade458f6a43a7138e8bfb820a86fb1b661ca75895819f'
PE = pefile.PE(data=RAW)
BASE = PE.OPTIONAL_HEADER.ImageBase
MD = Cs(CS_ARCH_X86, CS_MODE_32)
MD.detail = True
MD.skipdata = True

def executable():
    for sec in PE.sections:
        if sec.Characteristics & 0x20000000:
            yield from MD.disasm(sec.get_data(), BASE + sec.VirtualAddress)

def line(ins):
    return f'{ins.address:08x}  {ins.bytes.hex():20s} {ins.mnemonic:8s} {ins.op_str}'

def data(va, size):
    return PE.get_data(va - BASE, size)

def run():
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['meta','dis','refs','data','index'])
    p.add_argument('address', nargs='?', type=lambda s:int(s,0), default=0)
    p.add_argument('size', nargs='?', type=lambda s:int(s,0), default=256)
    a=p.parse_args()
    if a.mode=='meta':
        print(json.dumps({'sha256':SHA,'base':hex(BASE),'entry':hex(BASE+PE.OPTIONAL_HEADER.AddressOfEntryPoint),'sections':[{'name':s.Name.decode().strip(chr(0)),'va':hex(BASE+s.VirtualAddress),'raw':hex(s.PointerToRawData),'size':hex(s.SizeOfRawData)} for s in PE.sections]},indent=2))
    elif a.mode=='dis':
        for ins in MD.disasm(data(a.address,a.size),a.address): print(line(ins))
    elif a.mode=='data':
        b=data(a.address,a.size)
        for i in range(0,len(b),16): print(f'{a.address+i:08x}  {b[i:i+16].hex(" ")}')
    elif a.mode=='refs':
        for ins in executable():
            if not ins.id: continue
            if any(o.type==X86_OP_IMM and a.address<=o.imm<a.address+a.size or o.type==X86_OP_MEM and a.address<=o.mem.disp<a.address+a.size for o in ins.operands):print(line(ins))
    elif a.mode=='index':
        dest=ROOT/'.reference/analysis';dest.mkdir(exist_ok=True)
        (dest/'vmv2-disassembly.txt').write_text('\n'.join(line(i) for i in executable()),encoding='utf-8')
        print(dest/'vmv2-disassembly.txt')

if __name__=='__main__':run()
