// Headless render cost probe: runs Renderer.loop on a real stage with a counting fake 2D context.
// Usage: node scripts/render-bench.mjs [stageIndex=1] [width=390] [height=586]
import {Battle} from '../src/engine.js';
import {generateStage} from '../src/maps.js';
const [stageIndex=1,width=390,height=586]=process.argv.slice(2).map(Number);
globalThis.Image??=class{constructor(){this.complete=true;this.naturalWidth=64;this.naturalHeight=64;this.width=64;this.height=64;}};globalThis.window??={dispatchEvent(){}};globalThis.Event??=class{};
globalThis.requestAnimationFrame??=()=>0;globalThis.devicePixelRatio??=2;
globalThis.matchMedia??=()=>({matches:true,addEventListener(){}});
globalThis.document??={hidden:false,createElement:()=>({getContext:()=>ctx,width:0,height:0})};
let calls=0;
const ctx=new Proxy({},{get(target,prop){if(prop in target)return target[prop];return (...a)=>{calls++;if(prop==='measureText')return {width:a[0]?.length*6||0};if(prop==='getImageData')return {data:[]};if(prop==='createLinearGradient'||prop==='createRadialGradient')return {addColorStop(){}};};},set(target,prop,value){target[prop]=value;return true;}});
const {Renderer}=await import('../src/renderer.js');
const r=Object.create(Renderer.prototype);
Object.assign(r,{canvas:{width:width*2,height:height*2,getBoundingClientRect:()=>({width,height,left:0,top:0})},ctx,callbacks:{},width,height,dpr:2,scale:1,pan:{x:0,y:0},effects:[],playbackUntil:0,speed:1,followId:null,hover:null,focus:null,mode:'move',highlight:new Set(),targets:new Set(),pointers:new Map(),reduced:false,lastFrame:0});
r.loop=Renderer.prototype.loop.bind(r);
r.battle=new Battle(generateStage(stageIndex),'adol');r.fit?.();r.scale=Math.max(r.scale,.85);r.focusUnit?.(r.battle.active,true);
const frames=60;let t=1000;r.loop(t);
calls=0;const start=process.hrtime.bigint();for(let i=0;i<frames;i++){t+=40;r.loop(t);}
const ms=Number(process.hrtime.bigint()-start)/1e6;
console.log(JSON.stringify({stage:stageIndex,tiles:r.battle.stage.tiles.length,viewport:`${width}x${height}`,scale:+r.scale.toFixed(2),callsPerFrame:Math.round(calls/frames),jsMsPerFrame:+(ms/frames).toFixed(2)}));
