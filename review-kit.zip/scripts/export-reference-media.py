"""Convert the user's supplied VMO files. Requires Pillow; never downloads media.

CH tiles: 24x12 indexed pixels, CP: eighteen 4x8 column-major tile maps,
bottom row first. Slots are explicit, not inferred from translated names.
"""
from pathlib import Path
import base64
import gzip
import hashlib
import importlib.util
import io
import json
import struct
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.reference/VMO_WIN'
spec = importlib.util.spec_from_file_location('vm_reader', ROOT / 'scripts/read-vm-reference.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)


def slots(name):
    data = (SOURCE / (name + '.DAT')).read_bytes()
    assert data[:6] == b'LB DAT'
    count = struct.unpack_from('<I', data, 8)[0]
    offsets = struct.unpack_from('<' + str(count + 1) + 'I', data, 16)
    return [data[offsets[i]:offsets[i + 1]] for i in range(count)]


def url(data, mime):
    return 'data:' + mime + ';base64,' + base64.b64encode(data).decode('ascii')


def frame_images(raw, mapping, palette):
    assert len(raw) % 288 == 0 and len(mapping) == 1152
    cp = struct.unpack('<576H', mapping)
    tiles = []
    for pos in range(0, len(raw), 288):
        tile = Image.new('RGBA', (24, 12))
        tile.putdata([(*palette[v], 0 if v == 16 else 255) for v in raw[pos:pos + 288]])
        tiles.append(tile)
    frames = []
    for f in range(18):
        im = Image.new('RGBA', (96, 96))
        for j, k in enumerate(cp[f * 32:(f + 1) * 32]):
            if k == 2047:
                continue
            assert k < len(tiles), (k, len(tiles))
            im.paste(tiles[k], (j // 8 * 24, (7 - j % 8) * 12))
        frames.append(im)
    return frames


def main():
    data0 = {name: reader.unpack(data) for _, name, data in reader.entries(SOURCE / 'DATA00')}
    palette = [(i, i, i) for i in range(256)]
    for start, name in [(16, 'SYSPAL._PL'), (60, 'CHRPAL._PL')]:
        colors = data0[name]
        for j in range(len(colors) // 4):
            palette[start + j] = tuple(colors[j * 4:j * 4 + 3])
    # Runtime glow ramps are not in CHRPAL. These web ramps are explicitly
    # provisional; the original indexed pixels and base palette are preserved.
    for start, lo, hi in [(100,(40,70,110),(180,225,255)),(104,(90,20,30),(255,160,140)),
        (108,(80,35,130),(235,195,255)),(112,(20,90,100),(210,255,255)),
        (116,(25,65,140),(170,215,255)),(120,(130,65,15),(255,235,150)),
        (124,(100,130,150),(250,255,255))]:
        for j in range(4):
            palette[start+j] = tuple(round(a+(b-a)*j/3) for a,b in zip(lo,hi))
    archives = {name: slots(name) for name in ['DATA01','DATA02','DATA03','DATA13']}
    masters = 'fighter duke swordsman knight paladin shadow ranger savage thief bard sister sorcerer witch monk spirit beast nightmare fraulein dora ares mail gau julio-chris clare adol leah-feena chewchew'.split()
    natials = 'fa-rancell da-colm ae-ferrion gia-bro d-alma ba-mado reque neptjunoue tarbss zamilpen marme tentarch hepitus oonevievle blexe dullmdaler zenosblead greon pelitt currier-bell amoltamiss guene-foss fifenall regna-croxe'.split()
    records = [(identity, [i*2,i*2+1] if i<18 else [36+i-18,183+i-18]) for i,identity in enumerate(masters)]
    records += [(identity,[45+i*2,46+i*2]) for i,identity in enumerate(natials)]
    pack = {'version':1,'sprites':{},'tracks':[],'sfx':{}}
    contact = Image.new('RGB',(960,((len(records)+7)//8)*120),'#233b3d')
    labels = ImageDraw.Draw(contact)
    for number,(identity,indices) in enumerate(records):
        pack['sprites'][identity] = []
        for team,slot in enumerate(indices):
            frames = frame_images(reader.unpack(archives['DATA01'][slot]),data0['P_000._CP'],palette)
            action_slot = slot*2 if slot<93 else 186+(slot-183)*2
            idle = list(frames)
            attack = frame_images(reader.unpack(archives['DATA02'][action_slot]),reader.unpack(archives['DATA02'][action_slot+1]),palette)
            # Some projectile frames contain only the projectile; retain the actor.
            for f,im in enumerate(attack):
                bounds=im.getbbox()
                if not bounds or bounds[3]-bounds[1]<16:
                    base=idle[f//3*3].copy();base.alpha_composite(im);attack[f]=base
            frames += attack
            # DATA03 natial slots are not parallel to DATA01. Do not display a
            # different natial as a casting animation; keep its own stance.
            frames += frame_images(reader.unpack(archives['DATA03'][action_slot]),reader.unpack(archives['DATA03'][action_slot+1]),palette) if identity in masters else idle
            sheet = Image.new('RGBA',(576,864))
            for f,im in enumerate(frames):
                sheet.paste(im,(f%6*96,f//6*96))
            out = io.BytesIO();sheet.convert('P',palette=Image.Palette.ADAPTIVE,colors=128).save(out,format='PNG',optimize=True)
            pack['sprites'][identity].append(url(out.getvalue(),'image/png'))
            if team == 0:
                x,y=number%8*120,number//8*120
                im=frames[15].resize((120,120),Image.Resampling.NEAREST)
                contact.paste(im,(x,y),im);labels.text((x+2,y+4),identity,fill='white')
    for path in sorted((SOURCE/'MIDI').glob('*.MID')):
        identity=path.stem
        pack['tracks'].append({'id':identity,'label':identity,'gzip':base64.b64encode(gzip.compress(path.read_bytes(),mtime=0)).decode('ascii')})
    for event,index in {'turn':0,'capture':1,'attack':2,'summon':3,'heal':4,'spell':5,'down':6}.items():
        wav=archives['DATA13'][index]
        assert wav[:4]==b'RIFF' and wav[8:12]==b'WAVE'
        pack['sfx'][event]=url(wav[:8+struct.unpack_from('<I',wav,4)[0]],'audio/wav')
    output='// Generated from user-supplied VMO files. See docs/REFERENCE_MEDIA.md.\nexport const REFERENCE_MEDIA='+json.dumps(pack,separators=(',',':'))+';\n'
    (ROOT/'src/reference-media.js').write_text(output,encoding='utf-8')
    evidence=ROOT/'docs/audit-evidence';evidence.mkdir(exist_ok=True)
    contact.save(evidence/'reference-character-roster.png')
    manifest={'source':'User-supplied VMO_WIN','sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE.glob('*.DAT') if p.stem in ['DATA00','DATA01','DATA02','DATA03','DATA13']},'characters':len(records),'teams':2,'framesPerTeam':54,'midiTracks':len(pack['tracks']),'effects':7,'bytes':len(output.encode()),'slotMapping':dict(records),'limitations':['Runtime glow palette reconstructed','Natial cast uses own idle stance until DATA03 mapping is verified','Projectile-only attack frames composite idle actor','Direction/action timing provisional','Web event-to-SFX mapping provisional','Web stage-to-MIDI mapping provisional','MIDI instrument timbres synthesized by Web Audio; continuous pitch/controller changes approximated']}
    (ROOT/'docs/reference-media-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in manifest.items() if k not in ['sha256','slotMapping']},ensure_ascii=False))


if __name__=='__main__':
    main()
