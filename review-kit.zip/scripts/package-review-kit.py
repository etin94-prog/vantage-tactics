"""Create a source/test review kit using an explicit allowlist, never .reference."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
build = subprocess.check_output(['node', '--input-type=module', '-e', "import {labFingerprint} from './scripts/build-lab.mjs';console.log(await labFingerprint())"], cwd=ROOT, text=True).strip()
if json.dumps(build) not in (ROOT / 'src/lab-build.js').read_text(encoding='utf-8'):
    raise SystemExit('Run npm run build before packaging: lab source differs from build.')
files = ['package.json', 'server.mjs', 'build.mjs', 'index.html', 'play.html', 'lab-shell.html', 'lab.html', 'README.md', 'LAB_REVIEW_GUIDE.md', 'docs/LAB_REVIEW_GUIDE.md', 'docs/V2_RESTORATION_STATUS.md', 'docs/reviews/README.md', 'scripts/build-lab.mjs', 'scripts/lab-cli.mjs', 'scripts/package-review-kit.py', 'scripts/export-maps.mjs']
files += [str(p.relative_to(ROOT)).replace('\\', '/') for p in (ROOT / 'src').glob('*.js') if p.name != 'catalog.js']
files += ['src/style.css', 'src/lab.css']
files += [str(p.relative_to(ROOT)).replace('\\', '/') for p in (ROOT / 'tests').glob('*.test.js')]
files += [str(p.relative_to(ROOT)).replace('\\', '/') for p in (ROOT / 'data/lab').glob('*.json')]
manifest = {'build': build, 'files': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(set(files))}, 'note': 'Source/test snapshot; no original executables, artwork, audio, credentials, or review submissions.'}
(ROOT / 'review-kit-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
with zipfile.ZipFile(ROOT / 'review-kit.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name in sorted(manifest['files']):
        z.write(ROOT / name, name)
    z.write(ROOT / 'review-kit-manifest.json', 'review-kit-manifest.json')
print(f'Review kit: {len(files)} files, {(ROOT / "review-kit.zip").stat().st_size} bytes, build {build}')
