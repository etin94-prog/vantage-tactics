import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const root=new URL('../',import.meta.url);
export const labModules=['v2-reference','rules','spells','data','campaign','hex','maps','engine','target-area','event-visibility','renderer','lab-core','strategy-lab','strategy-ui','lab'];
export async function labFingerprint(){const h=createHash('sha256');for(const name of [...labModules,'reference-media']){h.update(name+'\0');h.update(await readFile(new URL(`src/${name}.js`,root)));}for(const file of ['lab-shell.html','src/lab.css']){h.update(file+'\0');h.update(await readFile(new URL(file,root)));}return h.digest('hex');}
export async function buildLab(){
  const build=await labFingerprint(),constant=`export const LAB_BUILD=${JSON.stringify(build)};\n`;
  await writeFile(new URL('assets/reference-media.js',root),(await readFile(new URL('src/reference-media.js',root),'utf8')).replace('export const REFERENCE_MEDIA','const REFERENCE_MEDIA'));
  await writeFile(new URL('src/lab-build.js',root),constant);
  const modules=await Promise.all(labModules.map(n=>readFile(new URL(`src/${n}.js`,root),'utf8')));
  const code=[constant,...modules].map(s=>s.replace(/^import .+;\r?\n/gm,'').replace(/^export /gm,'')).join('\n');
  const script=`(()=>{'use strict';\n${code}\n})();`;new Function(script);
  const html=await readFile(new URL('lab-shell.html',root),'utf8'),css=await readFile(new URL('src/lab.css',root),'utf8');
  await writeFile(new URL('lab.html',root),html.replace('<link rel="stylesheet" href="src/lab.css">',()=>`<style>${css}</style>`).replace('<script type="module" src="src/lab.js"></script>',()=>`<script src="assets/reference-media.js"></script><script>${script.replace(/<\/script/gi,'<\\/script')}</script>`));
  await writeFile(new URL('LAB_REVIEW_GUIDE.md',root),await readFile(new URL('docs/LAB_REVIEW_GUIDE.md',root)));
  return build;
}
if(process.argv[1]&&pathToFileURL(process.argv[1]).href===import.meta.url)console.log('Lab built: '+await buildLab());
