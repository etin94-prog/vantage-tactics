"""Read-only LB DAT research parser; game assets stay in ignored .reference/.

Compression format reference: uyjulian (MIT),
https://gist.github.com/uyjulian/bb0400c3768ea33be395a22df61a0c70
Supports byte-command and bit-command blocks used by these scenario records.
"""
from pathlib import Path
import struct


def bit_block(data):
    pos, flags, bits = 2, data[1], 8
    out = bytearray()
    def byte():
        nonlocal pos
        value = data[pos]
        pos += 1
        return value
    def bit():
        nonlocal flags, bits
        if not bits:
            flags = byte() | byte() << 8
            bits = 16
        value = flags & 1
        flags >>= 1
        bits -= 1
        return value
    def number(count):
        value = 0
        for _ in range(count): value = value * 2 + bit()
        return value
    while True:
        if not bit():
            out.append(byte())
            continue
        if bit():
            distance = number(5) * 256 + byte()
            if not distance: break
            if distance <= 2:
                long = bit()
                count = number(4)
                if long: count = count * 256 + byte()
                out.extend([byte()] * (count + 14))
                continue
        else:
            distance = byte()
        count = 2
        while count < 6 and not bit(): count += 1
        if count == 6: count = number(3) + 6 if bit() else byte() + 14
        if not 0 < distance <= len(out): raise ValueError('Invalid bit back reference')
        for _ in range(count): out.append(out[-distance])
        if len(out) > 2_000_000: raise ValueError('Output limit')
    return bytes(out), pos


def unpack(data):
    result = bytearray()
    pos = 0
    while pos < len(data):
        size = struct.unpack_from('<H', data, pos)[0]
        end = pos + size
        pos += 2
        if not size:
            break
        if data[pos] == 0:
            decoded, used = bit_block(data[pos:end])
            result.extend(decoded)
            pos += used
            continuation = data[pos]
            pos += 1
            if not continuation: break
            continue
        block = bytearray()
        while pos < end:
            token = data[pos]
            pos += 1
            if token < 64:
                count = token & 31
                if token & 32:
                    count = count * 256 + data[pos]
                    pos += 1
                block.extend(data[pos:pos+count])
                pos += count
            elif token < 128:
                count = token & 15
                if token & 16:
                    count = count * 256 + data[pos]
                    pos += 1
                block.extend([data[pos]] * (count+4))
                pos += 1
            else:
                distance = (token & 31)*256 + data[pos]
                pos += 1
                count = ((token >> 5) & 3)+4
                while pos < end and data[pos] & 224 == 96:
                    count += data[pos] & 31
                    pos += 1
                if not 0 < distance <= len(block):
                    raise ValueError('Invalid back reference')
                for _ in range(count):
                    block.append(block[-distance])
            if len(block) > 2_000_000 or pos > end:
                raise ValueError('Invalid block size')
        result.extend(block)
        continuation = data[pos]
        pos += 1
        if not continuation:
            break
    return bytes(result)


def entries(stem):
    directory = stem.with_suffix('.DIR').read_bytes()
    archive = stem.with_suffix('.DAT').read_bytes()
    assert directory[:6] == b'LB DIR'
    for index in range(struct.unpack_from('<I', directory, 8)[0]):
        record = directory[16+index*36:52+index*36]
        name = record[:12].decode('ascii').replace(' ', '')
        _, size, _, _, _, offset = struct.unpack_from('<6I', record, 12)
        if offset and size:
            yield index, name, archive[offset:offset+size]


if __name__ == '__main__':
    output = Path('.reference/decoded')
    output.mkdir(parents=True, exist_ok=True)
    for index, name, data in entries(Path('.reference/VMO_WIN/DATA10')):
        if name.endswith(('._SC', '._MD', '._VM')):
            try:
                decoded = unpack(data)
                (output / name).write_bytes(decoded)
                print(index, name, len(decoded), repr(decoded[:40]))
            except ValueError as error:
                print('UNSUPPORTED', index, name, str(error))
