import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {generateStage,validateStage,normalizeStage} from '../src/maps.js';
const root=new URL('../data/',import.meta.url);
await mkdir(new URL('maps/',root),{recursive:true});
const manifest=[];
for(let i=0;i<30;i++){
  const stage=validateStage(generateStage(i)),name=`stage-${String(i+1).padStart(2,'0')}.json`;
  await writeFile(new URL(`maps/${name}`,root),JSON.stringify(stage,null,2));
  if(i===0)await writeFile(new URL(name,root),JSON.stringify(stage,null,2));
  manifest.push({id:stage.id,name:stage.name,file:`maps/${name}`,width:stage.gridWidth,height:stage.gridHeight,stones:stage.manaStones.length,sourceIndex:stage.sourceIndex,generatedLayout:stage.generatedLayout});
}
const guide=await readFile(new URL('../docs/VANTAGE_MASTER_DEV_GUIDE.md',import.meta.url),'utf8');
const raw=JSON.parse(guide.match(/```json\s*([\s\S]*?)```/)[1]);
normalizeStage(raw);
await writeFile(new URL('reference-stage-01.json',root),JSON.stringify(raw,null,2));
await writeFile(new URL('manifest.json',root),JSON.stringify(manifest,null,2));
console.log('30 stage JSON files, manifest and original sparse template exported.');
