import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {runLabSuite,replayBundle} from '../src/lab-core.js';
import {labFingerprint} from './build-lab.mjs';
const [command='suite',...args]=process.argv.slice(2),build=await labFingerprint();
const runId=Date.now()+'-'+process.pid;
try{
  let result,output;
  if(command==='suite'){if(args.length)throw new Error('사용법: npm run lab:test');result=runLabSuite(build);output=resolve(`test-results/lab-suite-${runId}.json`);}
  else if(command==='replay'){
    if(args.length!==1)throw new Error('사용법: npm run lab:replay -- <실험.json>');
    const raw=await readFile(resolve(args[0]),'utf8');if(raw.length>8_000_000)throw new Error('8MB 이하 JSON만 지원합니다.');
    const input=JSON.parse(raw),r=replayBundle(input,build);result={kind:'replay',status:r.reproducedErrors.length?'reproduced-failure':'pass',reproducedErrors:r.reproducedErrors,build,sourceBuild:input.build,buildMatch:r.buildMatch,actions:r.session.steps.length,finalHash:r.session.bundle().finalHash,review:r.review};output=resolve(`test-results/lab-replay-${runId}.json`);
  }else throw new Error('명령은 suite 또는 replay입니다.');
  await mkdir(dirname(output),{recursive:true});await writeFile(output,JSON.stringify(result,null,2));
  console.log(JSON.stringify({kind:result.kind,status:result.status,reproducedErrors:result.reproducedErrors,build,passed:result.passed,failed:result.failed,buildMatch:result.buildMatch,actions:result.actions,report:output},null,2));
  if(result.failed||result.status==='reproduced-failure')process.exitCode=1;
}catch(e){console.error('Lab failed: '+e.message);process.exitCode=1;}
