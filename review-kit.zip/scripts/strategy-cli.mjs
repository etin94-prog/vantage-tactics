import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {runStrategyBenchmark} from '../src/strategy-lab.js';
import {labFingerprint} from './build-lab.mjs';

try{
  const args=process.argv.slice(2);if(args.length!==1)throw new Error('사용법: npm run lab:strategy -- data/lab/strategy-default.json');
  const config=JSON.parse(await readFile(resolve(args[0]),'utf8')),build=await labFingerprint();
  const directory=resolve(`test-results/strategy-${Date.now()}-${process.pid}`);await mkdir(directory,{recursive:true});
  let stop=false;process.on('SIGINT',()=>{stop=true;});
  const report=await runStrategyBenchmark(config,build,{cancelled:()=>stop,yield:()=>new Promise(r=>setImmediate(r)),onMatch:(r,p)=>console.log(`${p.results.length}/${p.planned} stage=${r.stage} ${r.strategy}/${r.opponent} seed=${r.seed}: ${r.status} (${r.actions})${r.error?' '+r.error:''}`)});
  for(const row of report.results){const name=`${row.stage}-${row.strategy}-${row.opponent}-${row.seed}.json`;await writeFile(resolve(directory,name),JSON.stringify(row.bundle));row.reproduction=name;row.finalHash=row.bundle.finalHash;delete row.bundle;}
  await writeFile(resolve(directory,'summary.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify({directory,summary:report.summary,groups:report.groups},null,2));
  if(report.summary.errors)process.exitCode=1;
}catch(e){console.error(e);process.exitCode=1;}
