# Codex 인계 · 오디오/이펙트 후속 수정 (Claude 검수 c5a9e2)

아래 `프롬프트` 블록 전체를 Codex에 붙여넣으세요.

## 프롬프트

```text
Vantage Tactics 오디오 후속 수정 작업입니다. 근거 보고서는 docs/reviews/claude-20261023-c5a9e2-audio-effects.md 입니다.
재현 자료는 test-results/claude-audio-20261023-c5a9e2/ 아래에 있습니다. 보고서를 먼저 읽고, 각 발견 ID를 직접 재현한 뒤 수정하세요.
이 인계는 배포 권한을 새로 부여하지 않습니다. push, GitHub Pages 배포, review-kit 재게시는 사용자가 별도로 지시할 때만 하세요.

0. 기준 버전 확인
- src/audio.js SHA-256 b2e8caab6737358056b3f049bdc0e6e7ec8070033addf4602bba1b10e1824fca
- src/main.js SHA-256 a8642bf012b754646f1c61592538ff3e6ce499b52fdab99eef37b2e7ea075206
- 해시가 다르면 보고서의 행 번호를 그대로 믿지 말고 같은 코드를 찾아 재현부터 다시 할 것.
- 기준 상태: npm test 68/68 통과, node --test test-results/claude-audio-20261023-c5a9e2/repro.test.mjs 6/6 실패(결함 재현용).

1. 우선순위와 범위(순서대로)
P2-a AE-01 피치벤드: parseMidi에서 채널별 RPN(CC101/100 → CC6/38) 벤드 범위를 적용한다. 음 도중 벤드는 음별 타임라인으로 저장해 note()에서 frequency 자동화로 예약한다. 이벤트가 많은 곡(CR010/016/017)은 일정 간격으로 줄여 처리하고, 노드 수를 늘리지 말 것.
P2-b AE-02 + AE-15 다이내믹: CC7/CC11 음 도중 변화를 음별 gain 구간으로 반영하고, CC7/CC11은 제곱, 벨로시티는 지수 1.5~2 곡선을 쓴다. CR015/016/017/019에서 스웰이 살아나는지 오프라인 렌더로 확인.
P2-c AE-03 음량 균형: BGM 출력을 키우고(기본 설정에서 BGM RMS ≥ -26 dBFS 목표), 효과음 샘플별 트림 테이블(turn·summon은 크게 감쇠)을 둔다. 마스터는 리미터 성격(threshold 약 -3 dB, ratio 20)으로 바꾼다. 기존 사용자 저장값(bgmVolume/sfxVolume)의 의미가 바뀌므로 이전 저장값 처리 방침을 결정하고 보고할 것.
P3 AE-07 효과음 decode 실패: 캐시 삭제 후 제한 횟수만큼 재시도하고, 음악 상태 문구를 덮어쓰지 말 것.
P3 AE-06 프리셋: 음색 키만 합치고(tempo/gain은 보존), 현재 값과 같은 프리셋을 표시한다.
P3 AE-04 밝기: 음별 필터 cutoff/배음에도 연결하거나 범위를 축소한다. AE-05 하이햇·심벌 경로, 저역 과다를 함께 조정한다.
P3 AE-08 시야 밖 효과음: renderer.consume과 같은 가시성 규칙으로 soundEvent를 거른다(main.js update). 숨겨진 행동에 다른 소리를 낼지는 결정하지 말고 TODO로 남길 것.
P3 AE-09 정지 페이드(약 30 ms), AE-10 시작 리드인 단축(반복 정책은 사용자 결정 필요 → 옵션 또는 보고만), AE-11 모바일 sticky 헤더·44px 닫기, AE-12 turn 효과음 빈도, AE-14 결과창이 설정창을 덮는 문제.
AE-13 reduced-motion은 문서(docs/REFERENCE_MEDIA.md 또는 IMPLEMENTATION_STATUS.md)에 지원 범위만 명시하면 됨.

2. 미검증 항목: 수정 전에 먼저 재현할 것
- 75% 속도에서 64음 상한: midi-analysis.mjs를 tempo 0.75 기준으로 확장해 확인.
- iOS Safari interrupted 이후 resume 실패 시 상태 문구: 실기기가 없으면 "미검증"으로 남기고 코드 방어(상태 갱신·재시도 안내)만 추가.
- AE-09 클릭은 실제 청취로 확인하지 않은 의심 항목. stop-click.html로 수정 전후를 비교할 것.
- 이번 검수는 실제 청취를 하지 않았다. 음색·균형 변경(AE-02/03/04/05/15)은 같은 체감 음량에서 A/B 청취 기록을 남기거나, 못 들었다면 "청취 미검증"이라고 명시할 것.

3. 검증 절차
- tests/audio.test.js에 회귀 테스트를 추가한다. 기준은 repro.test.mjs의 A1, A2, A3, B3, C1, C2와 AE-08(vision 맵에서 숨겨진 summon만 있을 때 effect 0회).
- repro.test.mjs는 수정하지 말고 그대로 실행해 6/6 통과를 확인(테스트 자체가 기대 동작을 단언함). A2는 구현 방식에 따라 판정식을 바꿔야 하면 tests/ 쪽 새 테스트로 대체하고 그 이유를 보고.
- npm test, npm run check, npm run build 통과. play.html이 새 audio.js를 번들했는지 확인.
- PORT=4180 npm start 후 test-results/claude-audio-20261023-c5a9e2/render-audit.html을 다시 실행하고, 수정 전 값(render-audit-result.json)과 19곡 RMS/peak/스펙트럼, 효과음 peak, 덕킹을 비교한 결과를 새 파일로 저장(기존 파일 덮어쓰기 금지).
- play.html에서 live-instrument.js를 첫 ♫ 클릭 전에 eval해 재검사: 19곡 시작, 연타 토글, 곡별 설정·새로고침 보존, 효과음 7종(heal 포함) 실관측.
- 사용자 저장(4173 origin)과 localStorage 전체를 지우지 말 것. 별도 포트를 사용할 것.

4. 산출물
- 변경 요약, 발견 ID별 처리 결과(수정/보류/재현 불가), 테스트 결과, 측정 비교 파일 경로, 남은 한계.
- docs/REFERENCE_MEDIA.md의 "BGM 튜닝"·"검증" 절을 실제 변경과 측정에 맞게 갱신(과장 금지, 청취 여부 명시).
```
