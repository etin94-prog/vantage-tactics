# Claude 독립 검수 · 이펙트·효과음·BGM·음악 설정 (2026-10-23, c5a9e2)

- 요청서: `docs/reviews/claude-20261023-audio-effects-handoff.md`
- 증거 폴더: `test-results/claude-audio-20261023-c5a9e2/`
- Codex 인계: `docs/reviews/claude-20261023-c5a9e2-audio-effects.codex-handoff.md`
- 검수 원칙: 게임 소스·기존 문서·배포물 무수정, push/배포 없음. 새 파일만 작성.

## 0. 결론 요약

1. **“BGM이 거칠다”는 고음이 날카로워서 생기는 문제가 아니다.** 19곡을 오프라인 렌더링하면 4 kHz 이상 에너지가 거의 0%이고(전 곡 0~0.2%) 2~4 kHz도 0.4~5.7%다. 측정상 지금 합성기는 오히려 **먹먹한 쪽**이다. 기존 “인접 샘플 차이” 지표의 개선은 이 고역 감소와 음량 감소를 반영할 뿐이다.
2. 측정으로 확인한 “거침”의 유력한 원인은 **음정과 다이내믹이 틀리게 연주되는 것**이다.
   - **AE-01**: 19곡 중 18곡이 RPN으로 피치벤드 범위를 ±12반음으로 지정하는데, 합성기는 ±2로 고정한다. 그래서 일부 곡의 음표 1.5~3.5%가 1~10반음 틀린 음정으로 시작한다. 연주 도중의 벤드(슬라이드)도 무시된다.
   - **AE-02**: CC11(Expression)·CC7 변화를 음 시작 순간 값으로 고정한다. CR015는 지속음의 48%, CR017은 46%가 크레셴도로 시작하는 음인데, 이 크레셴도가 사라진다.
   - **AE-15**: 볼륨·익스프레션·벨로시티를 선형으로 매핑해 GM 곡선보다 배경 파트가 6 dB가량 크게 나온다.
   - 다만 이 연결은 **코드·데이터 분석에 근거한 추정**이다. 실제 청취로 확인하지 않았다.
3. **AE-03 음량 불균형**: 기본값 기준 BGM RMS는 약 -42 dBFS이고 효과음 단기 RMS는 약 -11 dBFS다. 차이가 **약 30 dB**다. BGM을 들으려고 기기 볼륨을 올리면 효과음이 매우 크게 튄다. 효과음이 BGM을 눌러버리는 덕킹은 약 1 dB로 문제없다.
4. 기능 측면은 대부분 통과했다. 19곡 재생 시작, 곡별 설정과 저장, 전체 적용과 한 곡 복원, 새로고침 후 보존, 빠른 곡 전환과 켜기/끄기 반복, 탭 숨김/복귀, BGM 0과 효과음 0의 상호 독립, 64음 상한(최대 49음으로 미도달)을 확인했다. 효과음 7종 중 6종은 실제 전투에서 재생을 관측했다.
5. **실제 청취와 실제 모바일 기기 검증은 하지 않았다.** 아래 판정은 모두 “코드·파형 분석만 수행, 실제 청취 미검증”이다.

## 1. 대상과 버전

| 항목 | 값 | 판정 |
|---|---|---|
| 작업 루트 | `C:\VantageTactics` (Windows 11, Node v24.19.0) | – |
| `src/audio.js` SHA-256 | `b2e8caab…1824fca` | 요청서·로컬 manifest·**공개 manifest** 모두 일치 |
| `src/main.js` SHA-256 | `a8642bf0…a075206` | 위와 같음 |
| `src/renderer.js` / `src/style.css` / `play.html` | `732c1257…` / `6989cac2…` / `ebe0d74c…` | 로컬 manifest·공개 manifest와 일치 |
| 공개 manifest build | `18f503cd…eb772fc` | 요청서와 일치. 오디오 일치 여부는 위 파일 해시로 별도 확인 |
| `play.html` | `bgmCompressor`·`SYNTH_PROFILES`·`budget=256` 포함. 현재 audio.js 번들로 확인 | 일치 |

해시 기록: `test-results/claude-audio-20261023-c5a9e2/npm-test-summary.txt`. 공개 manifest는 Browser pane에서 `fetch`로 받아 대조했다.

## 2. 실행 결과

| 명령 | 결과 |
|---|---|
| `npm test` | 68 tests, pass 68, fail 0 |
| `npm run check` | exit 0 |
| `node --test test-results/claude-audio-20261023-c5a9e2/repro.test.mjs` | 6 tests, **fail 6** (모두 결함 재현용. 기대 동작을 단언하므로 실패가 곧 증거) → `repro.test.output.txt` |
| `node test-results/claude-audio-20261023-c5a9e2/midi-analysis.mjs` | 19곡 실시간 스케줄러 시뮬레이션 → `midi-analysis.json` |
| `node …/controller-analysis.mjs`, `node …/pitch-and-gaps.mjs`, `node …/markers.mjs` | RPN·CC11·음정 오차·무음 구간 → 각 `.json` |
| `node …/sfx-analysis.mjs` | 효과음 7종 WAV 헤더·레벨 → `sfx-analysis.json` |
| `node …/fog-sound-leak.mjs` | 시야 제한 전장의 소리 노출 → `fog-sound-leak.json` |
| `PORT=4180 node server.mjs` → `…/render-audit.html` | OfflineAudioContext 19곡·설정 스윕·덕킹 → `render-audit-result.json` |
| `…/stop-click.html` | 곡 전환/끄기 시 끊김 → `stop-click-result.json` |
| `play.html` + `live-instrument.js` | 실시간 기능 검사 → `live-results.json` |

환경은 Claude 데스크톱 Browser pane(Chrome 152.0.7977.149, Windows 11)이다. 사용자 저장과 섞이지 않도록 4180 포트(별도 origin)를 썼고 localStorage는 지우지 않았다. 4180 origin에는 이전부터 있던 `vt-battle-v4` 저장 하나가 있었고, 검사 중 그 전투가 패배로 끝났다. 사용자 원본(4173)의 저장에는 접근하지 않았다.

## 3. 검수 표

### 3.1 BGM·설정

| 항목 | 판정 | 근거 |
|---|---|---|
| 19곡 재생 시작 (CR009 없음) | 통과 | 19/19 “원본 음악 NN 재생 중”, 스케줄러 1개. 캐시된 상태에서 첫 음까지 1.0~2.9초(악보 자체의 리드인) |
| 프리셋 3종 반영 | 통과(약함) / 결함 AE-06 | 값은 반영된다. 다만 CR011 RMS 차이는 ±0.4 dB 수준이고, 프리셋을 고르면 사용자 속도·음량이 초기화된다 |
| 밝기 1200/4200/8500 | 부분 실패 AE-04 | 1200↔4200 차이는 있다(2–4 kHz 0→0.8%). 4200↔8500은 사실상 변화가 없다(0.8→0.7%, RMS 0.1 dB) |
| 저음 -4/+4 dB | 통과 | CR011 <250 Hz 비중 13.8% → 38.6% |
| 잔향 0/40% | 통과(미세) | RMS -42.1 → -43.1 dB. 스펙트럼 변화가 작다 |
| 속도 75~125% | 통과 | 6초 동안 120 ms마다 변경해도 순서 역전 0, 스케줄러 1. 예약된 180 ms 유지는 설계대로 |
| 곡 음량 0/150% | 통과 | 0%: -99.8 dBFS RMS / 150%: +3.5 dB |
| 악기 8그룹 | 통과(드럼은 약함, AE-05) | strings 0 → -3.7 dB, brass 0 → -1.1 dB, drums 0~1.5 → ±0.4 dB |
| A곡 조절 → B 기본 → A 복귀 → 새로고침 | 통과 | 2300 Hz 유지, 새로고침 뒤에도 2300 Hz·90% |
| 전체 적용 → 다른 곡 확인 → 한 곡 복원 | 통과 | 19곡 저장, CR012 복원 후 CR013 유지 |
| 자동/수동 곡, 저장 전투 복원 | 통과 | 자동 선택 시 1장 → CR010, `bgmTrack:null`. 복원 시 setSound가 `chooseTrack(stage)`로 재계산 |
| 빠른 곡 변경(100 ms 안에 10회) | 통과 | 마지막 곡만 재생, 표시 일치 |
| 켜기/끄기 5·6·9회 연타 | 통과 | 최종 상태·aria-pressed·스케줄러 일치. 끈 뒤 1.2초 동안 새 음 0 |
| 로딩 중 끄기 | 통과(기존 단위 테스트 + 코드) | 실브라우저에서는 이미 캐시되어 별도 재현 불가 |
| 탭 숨김/복귀 | 통과(모의) | `document.hidden` 재정의 + 이벤트. suspended 상태에서 음 0, 복귀 후 running·스케줄러 1 |
| 64음 상한·멜로디 누락 | 통과(100% 속도) | 예약 시점 동시 음 최대 49(CR011), 상한 도달 0회. 75% 속도는 별도 시뮬레이션 안 함 |
| 노드·타이머 누적 | 부분 통과 | 수백 회 조작 후에도 스케줄러 1, onended로 voices 정리. **30분 이상 장시간 재생은 미검증** |

### 3.2 효과음·시각 이펙트

| 항목 | 판정 | 근거 |
|---|---|---|
| 7종 이벤트 연결 | 6종 실관측, heal은 코드 경로만 확인 | ×3 속도 38초: turn 28, summon 5, capture 4, spell 4, attack 3, down 1 |
| BGM 0 → 효과음 재생 | 통과 | capture peak -3.1 dBFS |
| 효과음 0 → BGM 유지 | 통과 | BGM RMS -43.3 dBFS. 소스는 생성되지만 fx gain이 0 |
| 전체 끄기 → 둘 다 중지 | 통과 | disable이 effects를 stop하고 ctx를 suspend |
| BGM EQ·잔향이 효과음에 적용되는가 | 통과(미적용) | `fx → master` 직결 (`src/audio.js:64`) |
| 효과음이 BGM을 누르는가 | 통과 | 공용 마스터 컴프레서 덕킹 -0.7~-1.0 dB. 대신 음량 격차가 큼(AE-03) |
| 같은 유형 중복 억제·최대 8개 | 통과(설계 확인) | update당 유형별 1회 + 80 ms. 85 ms 간격 12회는 12회 모두 재생되어 같은 샘플이 겹칠 수 있음(P3 관찰) |
| decode 실패·재시도 | 실패 AE-07 | Node 재현 C1·C2 |
| 이펙트 잔존(재시작·전장 변경·이동 취소) | 통과(코드) | `setBattle`과 undo가 `effects=[]`로 비움. 화면 녹화로는 확인하지 않음 |
| 소환 링·투사체·숫자·모션 위치·방향 | **미검증** | 이번에는 오디오에 집중했고 시각 대조를 하지 않음 |
| 시야 밖 소리 노출 | 확정(커스텀 시야 맵 한정) AE-08 | Node 재현 |
| 이펙트가 전투 결과를 바꾸는가 | 통과(코드) | 오디오·렌더러는 engine 상태를 읽기만 함 |

### 3.3 모바일·접근성·청취

| 항목 | 판정 | 근거 |
|---|---|---|
| 390×844 세로 | 통과(경미한 문제 AE-11) | 가로 넘침 없음, 대화상자 스크롤 2072/749 px, 슬라이더 높이 32 px. 닫기 30×30, 헤더가 고정되지 않음 |
| 844×390 가로 | 통과 | 스크롤 가능, 가로 넘침 없음 |
| 키보드 포커스·레이블 | 통과 | 15개 range 모두 `label for`, `#audio-status role=status`, 버튼에 focus-visible, input은 브라우저 기본 링 |
| 실제 iOS/Android | **미검증** | “390px 모의 화면 검증, 실제 기기 미검증” |
| reduced-motion | 범위 기록 AE-13 | 흔들림(bob)·이동 보간·CSS 전환만 끔. 이펙트 애니메이션은 유지. 값을 한 번만 읽음 |
| 실제 청취 | **미검증** | 들은 곡·구간 없음. 모든 음질 판단은 파형·스펙트럼·악보 데이터 기반 |

## 4. 발견 사항

표기: 심각도 P0~P3, 유형 확정/의심/제안. 행 번호는 현재 해시 기준이다.

### AE-01 · P2 · 확정 — RPN 피치벤드 범위 무시, 연주 중 벤드 미반영

- 위치: `src/audio.js:31` (`c.bend=…/8192*2`), `src/audio.js:35` (`e.x+c.bend`를 음 시작 순간에만 반영)
- 곡: 18/19곡이 RPN 0/0 → CC6=12를 사용한다(일부 채널은 1·2·3). 시작 음정이 0.5반음 이상 틀린 음표:

  | 곡 | 수 | 비율 | 오차(반음) | 프로그램 |
  |---|---|---|---|---|
  | CR006GM | 156/4504 | 3.5% | 10반음 128개 | 122 Seashore, 35·37 |
  | CR001GM | 168/8696 | 1.9% | 2~4반음 | 63·65 |
  | CR010GM | 432/22408 | 1.9% | 2~6반음 | 17·65 등 |
  | CR016GM | 385/23664 | 1.6% | 1반음 | 33 베이스 |
  | CR017GM | 370/25383 | 1.5% | 1반음 | 34·35 베이스 |

  CR000·CR005·CR012·CR019에서도 소수 발생한다. 벤드 이벤트는 CR016 7760개, CR010 6655개, CR017 4401개로 많고, 연주 중 슬라이드는 전부 사라진다.
- 환경: Node 정적 분석.
- 재현: `node --test test-results/claude-audio-20261023-c5a9e2/repro.test.mjs` → A1 실패(기대 66, 실제 61). `node …/pitch-and-gaps.mjs`.
- 기대/실제: 범위 ±12에서 +½ 벤드면 +6반음이어야 하는데 실제는 +1반음이다.
- 증거: `controller-analysis.json`, `pitch-and-gaps.json`
- 청취 영향(의심): 베이스가 반음 어긋나 화성이 충돌하고, 리드는 슬라이드 끝 음 대신 틀린 음을 고정으로 낸다. “거칠다”의 유력 후보다.
- 수정 제안: 채널별 RPN 상태(CC101/100, CC6/38)를 추적해 `bendRange`를 적용한다. 음 객체에 벤드 타임라인(상대 시각, 반음)을 붙이고 `note()`에서 `frequency.setValueAtTime/linearRamp`로 반영한다. 벤드 이벤트가 많은 곡은 5 ms 단위 등으로 줄여 처리한다.
- 회귀 테스트: A1. 추가로 “음 도중 벤드가 frequency 자동화로 예약되는지”, “RPN Null(127/127) 이후 CC6을 무시하는지”.

### AE-02 · P2 · 확정(동작) / 의심(청취 영향) — 음 도중 CC11·CC7 변화 무시

- 위치: `src/audio.js:32`, `:35`. 음량을 음 시작 순간 값 하나로 고정한다.
- 곡: 0.5초 이상 지속음 가운데, 소리가 나는 동안 Expression이 24 이상 오르는 음의 비율:
  - CR015GM 1217/2537
  - CR017GM 1070/2315
  - CR016GM 905/3350
  - CR019GM 480/1575
  - CR005GM 215/1138
  - CR010GM 120/4288

  CC11 이벤트 수는 CR015 49,356개, CR016 24,486개다. CC1(모듈레이션, 비브라토 용도) 이벤트도 CR015 2753개, CR019 1665개, CR005 1302개인데 모두 무시된다.
- 재현: repro A2 실패(음량이 시작 값 0.049로 고정).
- 기대/실제: 현악·금관이 점점 커져야 하는데 시작 순간의 작은 음량 그대로 평평하게 유지된다. 반대로 페이드아웃은 끝까지 크게 남는다.
- 증거: `controller-analysis.json`
- 수정 제안: 채널별 CC7/CC11 타임라인을 저장하고, 각 음에 `[상대시각, 배율]` 구간을 붙인다. `note()`에서 엔벨로프 gain 뒤에 둔 별도 gain에 `setTargetAtTime`(time constant 약 20 ms)로 예약한다. 비용이 걱정되면 50 ms 간격으로 줄인다. CC1은 선택 사항으로 LFO(5~6 Hz, ±10~20 cent)를 적용한다.
- 회귀 테스트: A2. “CC11 0→127 스웰 음의 gain 자동화 지점 수 > 1”.

### AE-03 · P2 · 확정 — BGM과 효과음의 기본 음량 격차 약 30 dB

- 위치: `src/audio.js:61` 기본값(bgm .35, sfx .55), `:63` 마스터 컴프레서(threshold -8, ratio 8, Chrome 자동 makeup), `:96` 음별 레벨 0.05~0.12, `:49` autoGain 0.41~0.71. `src/main.js:24`.
- 측정(OfflineAudioContext, 가장 밀집한 6초):

  | 신호 | peak | RMS |
  |---|---|---|
  | BGM 35%(기본) | -24.0 ~ -28.3 dBFS | -39.0 ~ -44.7 dBFS |
  | BGM 100% | -14.9 ~ -19.2 dBFS | -29.9 ~ -35.6 dBFS |
  | 효과음 55%(마스터 통과) | -2.2 ~ -3.7 dBFS (down만 -10.8) | 실시간 capture 단기 RMS -10.9 dBFS |

  실시간 측정에서도 BGM RMS는 -42~-43 dBFS였다. 효과음 원본 7개는 모두 0 dBFS로 정규화된 16-bit 22.05 kHz 모노다(spell -1.9, down -8.2).
- 기대/실제: 일반적으로 BGM과 효과음 차이는 6~12 dB 정도가 적당하다. 실제로는 약 30 dB다.
- 청취 영향(의심): 사용자가 BGM을 듣기 위해 볼륨을 올리면 턴·소환 효과음이 매우 크고 피곤하게 들린다. 스피커가 작은 기기에서는 BGM이 저음만 남아 뭉개진다.
- 증거: `render-audit-result.json`(tracks, sfxAlone), `live-results.json`(volumes), `sfx-analysis.json`
- 수정 제안:
  - BGM 출력 목표를 정한다. 예: 기본 음량에서 RMS -24~-20 dBFS. `music` 앞에 makeup gain(+12~15 dB)을 두거나 `SYNTH_PROFILES.level`을 일괄 상향한다.
  - 효과음은 샘플별 트림 테이블을 둔다. turn·summon은 -12 dB 안팎, 나머지는 -6~-9 dB로 줄여 peak -12 dBFS를 목표로 한다.
  - 마스터 컴프레서는 리미터 역할만 하도록 threshold -3, ratio 20, knee 0~2로 바꾼다.
  - 같은 체감 음량에서 A/B 청취해 확인한다.
- 회귀 테스트: 오프라인 렌더(Playwright 등)로 “기본 설정 BGM RMS ≥ -26 dBFS, 효과음 peak ≤ -6 dBFS, 마스터 clipping 0”.

### AE-04 · P3 · 확정 — 밝기 슬라이더 4200~8500 Hz 구간이 사실상 무효

- 위치: `src/audio.js:51-58` 음색별 cutoff 1300~5200, `:94` 음별 lowpass, `:65` `bgmTone`
- 측정: 19곡 모두 4 kHz 이상 에너지가 0~0.2%다. CR011은 4200 → 8500에서 2–4 kHz가 0.8% → 0.7%, RMS 변화 0.1 dB이고, CR016은 5.7% → 4.8%다.
- 기대/실제: 슬라이더를 올리면 밝아져야 하지만 변화가 거의 없어 사용자는 설정이 고장 났다고 느낄 수 있다.
- 수정 제안: 밝기를 음별 필터 cutoff 배율(`profile.cutoff × brightness/4200`)과 배음 기울기에도 연결하거나, 범위를 1200~5000으로 줄인다.
- 회귀 테스트: 오프라인 렌더에서 8500 vs 4200의 2 kHz 이상 에너지 비율 ≥ 1.5배.

### AE-05 · P3 · 확정(스펙트럼) / 의심(청취) — 하이햇·심벌 소실, 저역 과다, 드럼 슬라이더 효과 미약

- 위치: `src/audio.js:91`(hat highpass 6500, cymbal 4800 → 그 뒤 `bgmTone` lowpass 4200에서 대부분 제거), `:96`(kick .12 sine 130 → 42 Hz)
- 측정: 8 kHz 이상 0~0.01%. <250 Hz 비중이 CR008 61%, CR019 60%, CR006 57%, CR010 55%다. drums 0 → 150% 조절 시 RMS 변화 ±0.4 dB.
- 청취 영향(의심): “먹먹함”, 박자감이 약하고 둔탁한 드럼.
- 수정 제안: hat·cymbal 음을 `bgmTone`을 우회하는 별도 버스로 보내거나 필터 대역을 1.5~3 kHz bandpass로 내린다. 킥·베이스 레벨을 -2~-3 dB 줄이고 80~120 Hz 이하에 완만한 highpass를 적용한다. 이 역시 A/B 청취로 검증한다.

### AE-06 · P3 · 확정 — 프리셋 선택이 속도·곡 음량·악기 비중을 조용히 초기화

- 위치: `src/main.js:36` (`saveTune(preset.values)`), `src/audio.js:46`
- 재현: 곡 음량 140%·속도 90% 설정 → 추천 음색 “선명한 전투” 선택 → 100%·100%로 바뀜. repro B3 실패(`[1,1]`).
- 함께 관찰된 점:
  - 설정창을 다시 열면 프리셋 표시가 항상 “직접 조절”이다.
  - “편안한 전술”은 `DEFAULT_TUNING`과 같다.
  - 프리셋 간 RMS 차이는 ±0.4 dB다.
- 수정 제안: 프리셋은 음색 관련 키(brightness, warmth, reverb, brass, drums, synth)만 덮어쓴다. `{...current, ...pick(preset)}`로 합치고, 렌더링할 때 현재 값과 일치하는 프리셋을 표시한다.
- 회귀 테스트: B3.

### AE-07 · P3 · 확정 — 효과음 decode 실패가 영구 캐시되고 상태 문구를 덮어씀

- 위치: `src/audio.js:101`. 거부된 Promise가 `this.buffers`에 남고, catch에서 `onStatus('효과음을 재생하지 못했습니다.')`를 호출한다.
- 재현: repro C1(두 번째 요청에서 decode 호출 수 1), C2(마지막 상태가 “효과음을 재생하지 못했습니다.”)
- 기대/실제: 다시 시도해야 하고, 음악 상태 문구는 유지되어야 한다. 실제로는 영구 실패하고, “원본 음악 NN 재생 중” 문구가 사라진다.
- 수정 제안: catch에서 `this.buffers.delete(event)` 후 재시도 횟수를 제한한다. 상태 표시는 음악 상태와 분리하거나 toast로 보낸다.
- 회귀 테스트: C1, C2

### AE-08 · P3 · 확정(커스텀 시야 맵 한정) — 시야 밖 적 행동이 소리로 노출

- 위치: `src/main.js:71`(모든 이벤트 유형에 대해 soundEvent 호출) vs `src/renderer.js:61`(시야 밖 이벤트는 그리지 않음)
- 재현: `node test-results/claude-audio-20261023-c5a9e2/fog-sound-leak.mjs`
  - vision 2: 시각 효과가 전부 숨겨진 상태에서 summon 6, capture 3, attack 1, down 1회 소리 재생
  - vision 3: summon 5, capture 2, attack 1, down 1회
- 범위: 원정 30개 전장에는 `vision`이 없다. 맵 JSON을 불러온 경우에만 해당한다. ‘쉐도우 하이드’ hidden 상태는 그 유닛의 다음 턴 시작에 해제되므로 원정에서의 영향은 작다.
- 관찰과 제안 구분: 관찰된 사실은 “시각 정보는 숨기면서 소리는 숨기지 않는다”는 정책 불일치다. 제안은 renderer와 같은 가시성 규칙으로 효과음을 거르는 것이다. 숨겨진 행동에 일반적인 “먼 곳” 소리를 낼지는 게임 디자인 결정이다.
- 회귀 테스트: vision 맵에서 보이지 않는 summon 이벤트만 있을 때 `effect` 호출 0회.

### AE-09 · P3 · 의심 — 곡 전환·끄기 시 즉시 정지로 인한 클릭 가능성

- 위치: `src/audio.js:78` (`source.stop()` 즉시, 페이드 없음)
- 측정: 화음 지속 중 정지하면 샘플 계단이 정상 구간 최대치의 1.7배다. 30 ms 램프를 적용하면 0.6배로 줄어든다. 음별 lowpass가 일부 완화해 주므로 강한 클릭은 아니다. 듣지 않았다.
- 증거: `stop-click-result.json`, `stop-click.html`
- 수정 제안: `stopMusic(fade=.03)`에서 `bgmBus.gain`을 램프로 내린 뒤 `stop(t+fade)`, 다음 곡 시작 시 gain을 복원한다(generation 경쟁을 함께 고려).

### AE-10 · P3 · 확정 — 곡 시작과 반복 경계의 긴 무음

- 근거: 첫 음까지 0.4~2.9초(CR003 2.82, CR017 2.46, CR004 2.41), 끝 무음 최대 3.84초(CR008)다. 반복할 때마다 CR003은 약 5.7초, CR008은 약 4.5초 동안 소리가 없다.
- 증거: `pitch-and-gaps.json`, `live-results.json`(allTracksStart)
- 참고: CR001·CR006·CR010·CR012·CR019의 “Ending” 마커는 곡 내부 섹션 표기이며 결함이 아니다(`markers.json`).
- 수정 제안: 처음 재생할 때 `epoch`를 첫 음 기준으로 당긴다. 반복 시 `duration`을 `lastNoteEnd + 짧은 여유`로 줄이는 옵션을 둔다(원곡 길이 보존 정책과 함께 결정).

### AE-11 · P3 · 확정(모의) / 의심(실기기) — 모바일 설정창 닫기·스크롤

- 위치: `src/main.js:54` 헤더 닫기 버튼, `src/style.css:22,24`
- 관찰(390×844): 내용이 2072 px, 보이는 영역이 749 px다. 헤더가 static이라 아래로 스크롤하면 닫기 버튼(30×30, 권장 44 px 미만)이 화면 밖으로 나간다. 전체 폭 슬라이더 15개가 약 90 px 간격으로 쌓여 있어, 터치로 스크롤하다 슬라이더 값이 바뀔 위험이 있다(실기기 미검증).
- 증거: `mobile-390x844-settings-bottom.jpg`
- 수정 제안: `.modal-header{position:sticky;top:0}`, 닫기 버튼 44×44, 슬라이더 좌우에 스크롤용 여백 두기. 하단에 “닫기” 버튼을 추가하는 것도 방법이다.

### AE-12 · P3 · 제안 — turn 효과음 빈도와 음량

- 근거: ×3 속도 38초 동안 28회 재생됐다. 원본 파일 RMS -6.8 dBFS로 7종 중 가장 크다.
- 제안: 아군 턴 시작에만 재생하거나 -6~-9 dB 트림. AE-03 트림 테이블과 함께 처리.

### AE-13 · P3 · 기록 — reduced-motion 지원 범위

- `src/renderer.js:44`에서 `matchMedia`를 한 번만 읽고, `:76-77`의 흔들림과 이동 보간만 끈다. CSS는 transition만 제거한다. 소환 링·투사체·숫자 애니메이션은 그대로이고, 설정을 바꿔도 새로고침 전에는 반영되지 않는다. 결함으로 단정하지 않으며 지원 범위를 문서화하라는 권고다.

### AE-14 · P3 · 확정 — 복원된 종료 전투의 결과창이 열려 있던 설정창을 덮어씀

- 위치: `src/main.js:72` (`setTimeout(showResult,700)`)
- 재현: 승패가 난 저장을 가진 상태로 새로고침 → 0.7초 안에 ☷ 클릭 → 0.7초 뒤 결과창이 설정창 내용을 교체한다(검사 스크립트의 `#bgm-track`이 null이 됨).
- 제안: 다른 모달이 열려 있으면 결과창 표시를 미루거나 큐에 넣는다.

### AE-15 · P3 · 확정(코드) / 의심(청취) — 볼륨·익스프레션·벨로시티 선형 매핑

- 위치: `src/audio.js:35` (`e.y/127*c.volume/127*c.expression/127`), `:96` (`velocity**1.15`)
- 재현: repro A3 실패. CC7=64일 때 0.504(-5.9 dB)로, GM 권장 곡선(제곱)의 0.254(-11.9 dB)보다 크다.
- 영향(의심): 반주·패드가 상대적으로 커져 밀도가 높아지고 탁하게 들린다.
- 제안: CC7·CC11은 제곱 곡선, 벨로시티는 지수 1.5~2를 쓴다. 전체 음량이 내려가므로 AE-03 게인 조정과 함께 바꾸고 A/B 청취로 확인한다.

## 5. 의심만 있는 항목·미확정

- 마스터 컴프레서의 3 ms attack이 저역을 왜곡하는가: BGM 단독으로는 임계값에 도달하지 않아(peak ≤ -15 dBFS) 해당하지 않는다. 효과음이 겹칠 때만 작동하고, 측정된 덕킹은 1 dB 이하라 문제로 보지 않는다.
- 75% 속도에서 64음 상한: 시뮬레이션하지 않았다. 해제 시간이 고정이므로 100%의 최대 49음과 비슷할 것으로 예상하지만 확인하지 않았다.
- iOS Safari의 `interrupted` 상태 이후 `resume()` 실패: `schedule()`은 조용히 멈추지만 상태 문구는 “재생 중”으로 남을 수 있다(`src/audio.js:82,102`). 실기기가 없어 확인하지 않았다.
- 85 ms 간격 같은 효과음 12회 겹침: 위상 겹침 가능성은 관찰했지만 청취로 확인하지 않았다.

## 6. 남은 한계

- 실제 청취: 하지 않았다. 헤드폰/스피커, 곡·구간·음량별 청취 기록이 없다. “거친 고음·피로감·클릭·드럼 균형·멜로디 선명도·먹먹함”은 위 스펙트럼·데이터로만 평가했다.
- 실제 기기: iOS/Android 최초 터치 재생과 백그라운드 복귀는 확인하지 않았다.
- 장시간 재생(30분 이상) 노드·메모리 추이: 측정하지 않았다.
- 시각 이펙트(소환 링·투사체·숫자·원본 모션)의 위치·방향·시점: 확인하지 않았다.
- 오프라인 렌더는 곡마다 6초 구간이며 64음 상한을 우회했다(실시간 최대 49음을 별도로 측정).
- 이전 합성기 비교: 로컬 `test-results/audio-before.js`·`audio-render.html`이 있지만 이번에는 재실행하지 않았다. 기존 `docs/audit-evidence/audio-render-20261023.json`의 “after” peak가 약 -27 dBFS로 이번 측정과 일치하는 것만 확인했다.
- 원작 상황별 효과음·곡 배정: 자료가 부족해 판단하지 않았다.

## 7. 증거 파일

`test-results/claude-audio-20261023-c5a9e2/`

| 파일 | 내용 |
|---|---|
| `midi-analysis.mjs/.json` | 19곡 음표·그룹·드럼 키·CC 사용량·실시간 64음 시뮬레이션 |
| `controller-analysis.mjs/.json` | RPN 벤드 범위, 음 도중 CC11 변화 |
| `pitch-and-gaps.mjs/.json` | 0.5반음 이상 틀린 음, 리드인/끝 무음 |
| `markers.mjs/.json` | 곡 섹션 마커 |
| `sfx-analysis.mjs/.json` | WAV 포맷·peak/RMS |
| `render-audit.html`, `render-audit-result.json` | 19곡 레벨·스펙트럼, 설정 스윕, 덕킹, 효과음 단독 |
| `stop-click.html`, `stop-click-result.json` | 정지 끊김 비교 |
| `live-instrument.js`, `live-results.json` | play.html 실시간 기능 검사 |
| `fog-sound-leak.mjs/.json` | 시야 밖 소리 노출 |
| `repro.test.mjs`, `repro.test.output.txt` | 결함 재현 6건(현재 모두 실패) |
| `npm-test-summary.txt` | npm test/check 결과와 해시 |
| `mobile-390x844-settings-bottom.jpg` | 390 px 설정창 하단 |
