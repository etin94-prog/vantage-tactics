import { Battle } from './engine.js';
import { SUMMONS, MASTERS, ELEMENTS } from './data.js';
import { generateStage } from './maps.js';
import { campaignInventory } from './campaign.js';
import { playerLevel } from './rules.js';
import { key, distance } from './hex.js';
import { LabSession, replayBundle } from './lab-core.js';

export const STRATEGIES=[['economy','마석·병력 확보'],['rush','소환사 집중 공격'],['ranged','원거리·생존']];
export const OPPONENTS=[['medium','미디엄 · 기존 AI'],['hard','하드 · 위험 평가 AI (실험용)']];
const weights={economy:{stone:34,master:10,ranged:1,risk:2},rush:{stone:12,master:30,ranged:1,risk:.6},ranged:{stone:20,master:15,ranged:2,risk:4},hard:{stone:25,master:22,ranged:1.5,risk:5}};
export function strategyRandom(seed){let n=seed>>>0;return ()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};}

// Rules-based agents. Candidate actions use the same legality checks as manual play.
// Randomness only breaks near ties; the actual action and rationale are recorded.
export function chooseStrategyAction(b,policy='economy',random=()=>.5){
  const w=weights[policy];if(!w)throw new Error('알 수 없는 전략');
  const u=b.active;if(!u||b.winner!==null)throw new Error('행동 가능한 전투가 아닙니다.');
  if(u.isDecoy)return {action:{type:'wait'},reason:'분신 대기'};
  const enemies=b.living.filter(t=>t.team!==u.team&&b.visibleUnit(t,u.team));
  const stones=b.stones.filter(s=>s.owner!==u.team);
  const threat=p=>enemies.reduce((n,t)=>n+b.threatDamage(t,{...u,q:p.q,r:p.r}),0);
  const value=t=>(t.master?w.master:0);
  const offense=proxy=>Math.max(0,...enemies.filter(t=>b.canAttack(proxy,t)).map(t=>b.damage(proxy,t,proxy.magicAttackBasic).amount+value(t)));
  const rangeValue=proxy=>Math.max(0,...b.availableSpells(proxy).filter(s=>s.kind==='damage'&&b.mana[u.team]>=s.cost).map(s=>{
    return b.spellTargets(proxy,s.id).some(p=>enemies.some(t=>distance(t,p)<=(s.radius||0)))?8*w.ranged:0;
  }));
  const goals=[...stones.map(s=>({p:s,bonus:w.stone})),...enemies.map(t=>({p:t,bonus:value(t)+12}))];
  const position=p=>{
    const proxy={...u,q:p.q,r:p.r};
    const approach=Math.max(-40,...goals.map(g=>g.bonus-distance(p,g.p)*2.5));
    const stone=stones.some(s=>key(s)===key(p))?w.stone:0;
    return approach+stone+offense(proxy)+rangeValue(proxy)-threat(p)*w.risk*(u.master?1.8:1);
  };
  const choices=[{action:{type:'wait'},score:0,reason:'유효 행동 대기'}];
  for(const t of enemies.filter(t=>b.canAttack(u,t))){
    const d=b.damage(u,t,u.magicAttackBasic).amount;
    choices.push({action:{type:'attack',target:t.id},score:18+Math.min(t.hp,d)*2+value(t)+(d>=t.hp?(t.master?1000:25):0),reason:`${t.name} 공격 · 예상 피해 ${d}`});
  }
  if(!b.hasStatus(u,'silence'))for(const s of b.availableSpells(u)){
    if(b.mana[u.team]<s.cost)continue;
    for(const p of b.spellTargets(u,s.id)){
      if(!b.visible(p,u.team))continue;
      let score=-s.cost*.3;
      for(const t of b.affected(u,s,p)){
        if(!b.visibleUnit(t,u.team))continue;
        if(s.kind==='damage'){
          const d=b.damage(u,t,!s.physical,s,p).amount;
          score+=(t.team===u.team?-4:1)*(Math.min(t.hp,d)*2+value(t)+(d>=t.hp?(t.master?1000:25):0));
        }
        if(s.kind==='heal'&&t.team===u.team)score+=Math.min(b.healing(u,s),t.maxHp-t.hp)*(t.master?12:5);
        if(s.kind==='cleanse'&&t.team===u.team)score+=Object.keys(t.statuses).length*12;
        if(s.kind==='status'&&t.team!==u.team&&!b.hasStatus(t,s.status))score+=18+(t.master?15:0);
      }
      if(score>0)choices.push({action:{type:'cast',spell:s.id,q:p.q,r:p.r},score:score+12*w.ranged,reason:`${s.name} · 피해/회복/상태 평가 ${score.toFixed(1)}`});
    }
  }
  if(u.master)for(const type of SUMMONS){
    if(!b.canSummon(type.id,u)||type.upkeep+b.upkeep(u.team)>b.income(u.team))continue;
    const ranged=type.range>1||type.spells.length>0;
    const counter=enemies.some(t=>ELEMENTS[type.element]?.beats===t.element)?8:0;
    for(const p of b.summonTiles(u,type.id)){
      const proximity=enemies.length?Math.min(...enemies.map(t=>distance(t,p))):0;
      choices.push({action:{type:'summon',unit:type.id,q:p.q,r:p.r},score:24+counter+(ranged?6*w.ranged:0)+(policy==='economy'?8:0)-type.cost*.1-proximity*.3-threat(p),reason:`${type.name} 소환 · 상성/사거리/유지비 고려`});
    }
  }
  if(!b.moved&&!b.hasStatus(u,'root')){
    const current=position(u);
    // Bound evaluation work while allowing every reachable tile into the shortlist.
    const candidates=[...b.reachable(u).dist.keys()].filter(k=>k!==key(u)).map(k=>b.tiles.get(k)).sort((a,c)=>{
      const coarse=p=>Math.max(-40,...goals.map(g=>g.bonus-distance(p,g.p)*2.5))+(stones.some(s=>key(s)===key(p))?w.stone:0);
      return coarse(c)-coarse(a);
    }).slice(0,policy==='hard'?16:10);
    for(const p of candidates){const gain=position(p)-current;
      if(gain>0)choices.push({action:{type:'move',q:p.q,r:p.r},score:gain+8,reason:`${policy} 이동 · 위치 평가 +${gain.toFixed(1)}`});
    }
  }
  // A moved unit can capture only by committing its turn; avoid walking off stones.
  if(stones.some(s=>key(s)===key(u)))choices[0].score=w.stone+10;
  return choices.map(c=>({...c,score:c.score+random()*.75})).sort((a,c)=>c.score-a.score)[0];
}

export function validateBenchmark(input={}){
  const c={stages:Array.from({length:30},(_,i)=>i),strategies:STRATEGIES.map(s=>s[0]),opponents:['medium','hard'],seeds:[1],master:'adol',loadout:'progression',level:1,maxActions:200,...input};
  const unique=(a,valid)=>Array.isArray(a)&&a.length>0&&new Set(a).size===a.length&&a.every(valid);
  if(!unique(c.stages,n=>Number.isInteger(n)&&n>=0&&n<30)||!unique(c.strategies,n=>STRATEGIES.some(s=>s[0]===n))||!unique(c.opponents,n=>OPPONENTS.some(s=>s[0]===n))||!unique(c.seeds,n=>Number.isInteger(n)&&n>=0&&n<=0xffffffff)||c.seeds.length>10||!MASTERS.some(m=>m.id===c.master)||!['progression','starter','all'].includes(c.loadout)||!Number.isInteger(c.level)||c.level<1||c.level>40||!Number.isInteger(c.maxActions)||c.maxActions<1||c.maxActions>500)throw new Error('자동 대전 설정 범위를 확인하세요 (행동 1~500, 시드 최대 10개).');
  return c;
}
export function createStrategyBattle(config,stage){
  const cleared=config.loadout==='progression'?Array.from({length:stage},(_,i)=>i+1):[];
  const inventory=config.loadout==='all'?{unlocked:SUMMONS.map(s=>s.id),extraSpells:['v2-10','v2-11','v2-12','v2-13','v2-14','v2-15']}:campaignInventory(cleared);
  return new Battle(generateStage(stage),config.master,{...inventory,playerLevel:config.loadout==='progression'?playerLevel(stage*100):config.level,difficulty:'normal'});
}
export function summarizeMatches(rows,planned=rows.length){
  const count=status=>rows.filter(r=>r.status===status).length;
  const wins=count('win'),losses=count('loss'),limits=count('limit'),errors=count('error'),cancelled=count('cancelled');
  const evaluated=wins+losses+limits;
  return {planned,recorded:rows.length,unrun:planned-rows.length,wins,losses,limits,errors,cancelled,evaluated,winRate:evaluated?wins/evaluated:null,decidedWinRate:wins+losses?wins/(wins+losses):null};
}
export async function runStrategyMatch(config,stage,strategy,opponent,seed,build,hooks={}){
  const session=new LabSession(createStrategyBattle(config,stage),build,`strategy-${stage+1}-${strategy}-${opponent}-${seed}`),b=session.battle;
  const rng=[strategyRandom(seed),strategyRandom(seed^0x9e3779b9)],decisions=[];
  let status='limit',error;
  try{
    for(let i=0;i<config.maxActions&&b.winner===null;i++){
      if(hooks.cancelled?.()){status='cancelled';break;}
      const team=b.active.team,decision=team===1&&opponent==='medium'?{action:{type:'ai'},reason:'기존 AI: 마석·공격·마법·소환 평가'}:chooseStrategyAction(b,team===0?strategy:'hard',rng[team]);
      decisions.push({step:i+1,team,unit:b.active.id,reason:decision.reason});
      if(!session.act(decision.action))throw new Error('AI가 거절되는 행동을 선택했습니다.');
      if(i%8===0)await hooks.yield?.();
    }
    if(b.winner!==null)status=b.winner===0?'win':'loss';
  }catch(e){status='error';error=e.message;}
  const bundle=session.bundle({reviewer:'strategy-agent',expected:'아군 소환사 생존 및 적 소환사 격파',actual:status,evidence:`${strategy} vs ${opponent}, seed ${seed}`});
  let replayVerified=false;
  try{replayBundle(bundle,build);replayVerified=true;}catch(e){status='error';error='재현 검증 실패: '+e.message;}
  return {stage:stage+1,name:b.stage.name,strategy,opponent,seed,status,error,actions:session.steps.length,minutes:b.time,master:config.master,level:b.units.find(u=>u.team===0&&u.master).level,unlocked:[...b.unlocked],extraSpells:[...b.extraSpells],mana:[...b.mana],stones:[b.owned(0),b.owned(1)],replayVerified,decisions,bundle};
}
export async function runStrategyBenchmark(input,build='development',hooks={}){
  const config=validateBenchmark(input),planned=config.stages.length*config.strategies.length*config.opponents.length*config.seeds.length;
  const report={schema:'vantage-strategy-v1',build,config,planned,results:[],scope:'규칙 기반 AI 전략 간 비교. 사람의 클리어 확률·원작 난이도·연속 캠페인 완주율이 아님. progression은 이전 전장 클리어를 가정한 독립 전투. 시드는 근접한 행동 평가의 선택만 변경.'};
  outer:for(const stage of config.stages)for(const strategy of config.strategies)for(const opponent of config.opponents)for(const seed of config.seeds){
    if(hooks.cancelled?.())break outer;
    const row=await runStrategyMatch(config,stage,strategy,opponent,seed,build,hooks);
    report.results.push(row);hooks.onMatch?.(row,report);await hooks.yield?.();
  }
  report.summary=summarizeMatches(report.results,planned);
  report.groups=config.strategies.flatMap(strategy=>config.opponents.map(opponent=>({strategy,opponent,...summarizeMatches(report.results.filter(r=>r.strategy===strategy&&r.opponent===opponent),config.stages.length*config.seeds.length)})));
  return report;
}
