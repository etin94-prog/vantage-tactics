
export const DIRECTIONS = [{q:1,r:0},{q:0,r:1},{q:-1,r:1},{q:-1,r:0},{q:0,r:-1},{q:1,r:-1}];
export const key = ({q,r}) => `${q},${r}`;
export const distance = (a,b) => (Math.abs(a.q-b.q)+Math.abs(a.r-b.r)+Math.abs(a.q+a.r-b.q-b.r))/2;
export const neighbors = h => DIRECTIONS.map(d=>({q:h.q+d.q,r:h.r+d.r}));
export function direction(a,b) { let best=0, score=Infinity; DIRECTIONS.forEach((d,i)=>{const n=distance({q:a.q+d.q,r:a.r+d.r},b);if(n<score){best=i;score=n;}});return best; }
export function hexToPixel(h,size=38) { return { x:size*Math.sqrt(3)*(h.q+h.r/2), y:size*1.5*h.r }; }
export function pixelToHex(x,y,size=38) {const q=(Math.sqrt(3)/3*x-y/3)/size,r=2*y/3/size;let a=Math.round(q),b=Math.round(r),c=Math.round(-q-r);const da=Math.abs(a-q),db=Math.abs(b-r),dc=Math.abs(c+q+r);if(da>db&&da>dc)a=-b-c;else if(db>dc)b=-a-c;return {q:a,r:b};}
export class MinHeap {
  constructor(compare=(a,b)=>a.time-b.time||a.id-b.id){this.items=[];this.compare=compare;}
  push(value){const a=this.items;a.push(value);let i=a.length-1;while(i>0){const p=(i-1)>>1;if(this.compare(a[p],a[i])<=0)break;[a[p],a[i]]=[a[i],a[p]];i=p;}}
  pop(){const a=this.items;if(!a.length)return undefined;const result=a[0],end=a.pop();if(a.length){a[0]=end;let i=0;while(true){let l=i*2+1,r=l+1,n=i;if(l<a.length&&this.compare(a[l],a[n])<0)n=l;if(r<a.length&&this.compare(a[r],a[n])<0)n=r;if(n===i)break;[a[i],a[n]]=[a[n],a[i]];i=n;}}return result;}
  get size(){return this.items.length;}
}
/** Dijkstra reachability with weighted terrain; parents provide shortest paths. */
export function reachable(start,budget,tileMap,cost,blocked=new Set(),stopAt=()=>false) {
  const heap=new MinHeap((a,b)=>a.cost-b.cost),dist=new Map([[key(start),0]]),parents=new Map();heap.push({...start,cost:0});
  while(heap.size){const p=heap.pop();if(p.cost!==dist.get(key(p))||key(p)!==key(start)&&stopAt(p))continue;for(const n of neighbors(p)){const t=tileMap.get(key(n));if(!t||blocked.has(key(n)))continue;const next=p.cost+cost(t,tileMap.get(key(p)));if(next>budget||next>=(dist.get(key(n))??Infinity))continue;dist.set(key(n),next);parents.set(key(n),key(p));heap.push({...n,cost:next});}}
  return {dist,parents};
}
/** A* used for long-range AI routes. */
export function findPath(start,end,tileMap,cost,blocked=new Set()) {
  const heap=new MinHeap((a,b)=>a.f-b.f),g=new Map([[key(start),0]]),parents=new Map();heap.push({...start,f:distance(start,end),g:0});
  while(heap.size){const p=heap.pop();if(p.g!==g.get(key(p)))continue;if(key(p)===key(end)){const path=[p];let k=key(p);while(parents.has(k)){k=parents.get(k);const [q,r]=k.split(',').map(Number);path.push({q,r});}return path.reverse().map(({q,r})=>({q,r}));}for(const n of neighbors(p)){const tile=tileMap.get(key(n));if(!tile||blocked.has(key(n)))continue;const ng=p.g+cost(tile,tileMap.get(key(p)));if(!Number.isFinite(ng)||ng>=(g.get(key(n))??Infinity))continue;g.set(key(n),ng);parents.set(key(n),key(p));heap.push({...n,g:ng,f:ng+distance(n,end)});}}
  return [];
}
