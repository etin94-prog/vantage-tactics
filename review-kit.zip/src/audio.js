import { REFERENCE_MEDIA } from './reference-media.js';

// Standard MIDI formats 0/1, PPQN time, merged tempo map and per-channel state.
// This deliberately uses a small Web Audio synth, not an original GM sound bank.
export function parseMidi(bytes){
  const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes),v=new DataView(a.buffer,a.byteOffset,a.byteLength);
  let p=0;const need=n=>{if(p+n>a.length)throw new Error('잘린 MIDI 데이터');};
  const u8=()=>{need(1);return a[p++];},u16=()=>{need(2);const n=v.getUint16(p);p+=2;return n;},u32=()=>{need(4);const n=v.getUint32(p);p+=4;return n;};
  const tag=()=>String.fromCharCode(u8(),u8(),u8(),u8());
  const vlq=()=>{let n=0;for(let i=0;i<4;i++){const b=u8();n=n*128+(b&127);if(!(b&128))return n;}throw new Error('MIDI delta overflow');};
  if(tag()!=='MThd')throw new Error('MIDI 헤더 오류');const size=u32(),format=u16(),tracks=u16(),division=u16();
  if(size<6||format>1||!division||(division&32768))throw new Error('지원하지 않는 MIDI 시간 형식');need(size-6);p+=size-6;
  const events=[];let sequence=0;
  for(let t=0;t<tracks;t++){
    if(tag()!=='MTrk')throw new Error('MIDI 트랙 오류');const length=u32();need(length);const end=p+length;let tick=0,running=0;
    while(p<end){tick+=vlq();let status=u8();if(status<128){if(!running)throw new Error('MIDI running status 오류');p--;status=running;}else if(status<240)running=status;
      if(status===255){const type=u8(),len=vlq();need(len);if(p+len>end)throw new Error('MIDI meta 길이 오류');if(type===81&&len===3)events.push({tick,order:sequence++,tempo:a[p]*65536+a[p+1]*256+a[p+2]});p+=len;if(type===47){events.push({tick,order:sequence++,end:true});p=end;}continue;}
      if(status===240||status===247){const len=vlq();need(len);p+=len;running=0;continue;}
      if(status>=240)throw new Error('지원하지 않는 MIDI 이벤트');
      const kind=status>>4,ch=status&15,x=u8(),y=kind===12||kind===13?0:u8();
      if(x>127||y>127||p>end)throw new Error('MIDI 이벤트 길이 오류');events.push({tick,order:sequence++,kind,ch,x,y});
    }
    if(p!==end)throw new Error('MIDI 트랙 길이 오류');
  }
  events.sort((a,b)=>a.tick-b.tick||a.order-b.order);
  const channels=Array.from({length:16},()=>({program:0,volume:100,expression:127,pan:64,sustain:false,bend:0,active:new Map(),held:[]})),notes=[];
  let tick=0,time=0,tempo=500000;
  const finish=(n,at)=>{n[1]=Math.max(.01,at-n[0]);notes.push(n);};
  for(const e of events){time+=(e.tick-tick)*tempo/division/1e6;tick=e.tick;if(e.tempo){tempo=e.tempo;continue;}if(e.end)continue;const c=channels[e.ch];
    if(e.kind===12)c.program=e.x;
    else if(e.kind===14)c.bend=((e.y*128+e.x)-8192)/8192*2;
    else if(e.kind===11){if(e.x===7)c.volume=e.y;if(e.x===11)c.expression=e.y;if(e.x===10)c.pan=e.y;
      if(e.x===64){c.sustain=e.y>=64;if(!c.sustain){for(const n of c.held)finish(n,time);c.held=[];}}
      if(e.x===120||e.x===123){for(const ns of c.active.values())for(const n of ns)finish(n,time);for(const n of c.held)finish(n,time);c.active.clear();c.held=[];}
    }else if(e.kind===9&&e.y){const n=[time,0,e.x+c.bend,e.y/127*c.volume/127*c.expression/127,e.ch,c.program,(c.pan-64)/64];if(!c.active.has(e.x))c.active.set(e.x,[]);c.active.get(e.x).push(n);
    }else if(e.kind===8||(e.kind===9&&!e.y)){const ns=c.active.get(e.x),n=ns?.shift();if(n){if(c.sustain)c.held.push(n);else finish(n,time);}if(!ns?.length)c.active.delete(e.x);}
  }
  for(const c of channels){for(const ns of c.active.values())for(const n of ns)finish(n,time);for(const n of c.held)finish(n,time);}
  notes.sort((a,b)=>a[0]-b[0]);return {notes,duration:Math.max(.1,time,...notes.map(n=>n[0]+n[1]))};
}

export const AUDIO_TRACKS=REFERENCE_MEDIA.tracks.map(({id},i)=>({id,label:`원본 음악 ${String(i+1).padStart(2,'0')}`}));
export function chooseTrack(stageId){const battleTracks=AUDIO_TRACKS.filter(t=>Number(t.id.slice(2,5))>=10);return battleTracks[Math.max(0,(stageId||1)-1)%battleTracks.length]?.id||AUDIO_TRACKS[0].id;}
export class GameAudio {
  constructor(onStatus=()=>{}){this.onStatus=onStatus;this.enabled=false;this.busy=false;this.generation=0;this.trackId=chooseTrack(1);this.bgmVolume=.35;this.sfxVolume=.55;this.cache=new Map();this.buffers=new Map();this.voices=new Set();this.effects=new Set();this.lastEffects=new Map();}
  async track(id){if(this.cache.has(id))return this.cache.get(id);const data=REFERENCE_MEDIA.tracks.find(t=>t.id===id);if(!data)throw new Error('음악을 찾을 수 없습니다.');const bytes=Uint8Array.from(atob(data.gzip),c=>c.charCodeAt(0));const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));const result=parseMidi(await new Response(stream).arrayBuffer());this.cache.set(id,result);return result;}
  context(){if(!this.ctx){const Audio=globalThis.AudioContext||globalThis.webkitAudioContext;if(!Audio)throw new Error('이 브라우저는 오디오를 지원하지 않습니다.');this.ctx=new Audio();this.master=this.ctx.createDynamicsCompressor();this.master.connect(this.ctx.destination);this.music=this.ctx.createGain();this.music.gain.value=this.bgmVolume;this.music.connect(this.master);this.fx=this.ctx.createGain();this.fx.gain.value=this.sfxVolume;this.fx.connect(this.master);const b=this.ctx.createBuffer(1,this.ctx.sampleRate,this.ctx.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;this.noise=b;}return this.ctx;}
  volumes(bgm,sfx){this.bgmVolume=Math.max(0,Math.min(1,Number(bgm)||0));this.sfxVolume=Math.max(0,Math.min(1,Number(sfx)||0));if(this.ctx){this.music.gain.setTargetAtTime(this.bgmVolume,this.ctx.currentTime,.02);this.fx.gain.setTargetAtTime(this.sfxVolume,this.ctx.currentTime,.02);}}
  stopMusic(){clearInterval(this.timer);this.timer=null;for(const source of this.voices){try{source.stop();}catch{}}this.voices.clear();}
  async enable(){if(this.enabled)return;this.enabled=true;this.onStatus('음악 불러오는 중');try{await this.context().resume();if(!this.enabled)return;await this.select(this.trackId);if(this.enabled&&globalThis.document?.hidden)await this.ctx.suspend();}catch(error){this.disable();this.onStatus(error.message);throw error;}}
  disable(){this.enabled=false;this.generation++;this.stopMusic();for(const source of this.effects){try{source.stop();}catch{}}this.effects.clear();this.ctx?.suspend().catch(()=>{});this.onStatus('소리 꺼짐');}
  async select(id){if(!AUDIO_TRACKS.some(t=>t.id===id))return;this.trackId=id;const generation=++this.generation;this.stopMusic();if(!this.enabled)return;try{const song=await this.track(id);if(!this.enabled||generation!==this.generation)return;this.song=song;this.cursor=0;this.epoch=this.ctx.currentTime+.12;this.timer=setInterval(()=>this.schedule(),50);this.schedule();this.onStatus(`${AUDIO_TRACKS.find(t=>t.id===id).label} 재생 중`);}catch(error){if(generation!==this.generation)return;this.disable();this.onStatus(error.message);throw error;}}
  schedule(){if(!this.enabled||this.ctx.state!=='running'||!this.song)return;const until=this.ctx.currentTime+.18;let budget=256;while(budget-->0){if(this.cursor>=this.song.notes.length){if(this.epoch+this.song.duration>until)break;this.epoch+=this.song.duration;this.cursor=0;if(!this.song.notes.length)break;}const note=this.song.notes[this.cursor];if(!note||this.epoch+note[0]>until)break;const at=this.epoch+note[0];if(at>=this.ctx.currentTime-.05)this.note(note,Math.max(at,this.ctx.currentTime));this.cursor++;}}
  note(n,at){if(this.voices.size>=64)return;const [_,duration,pitch,velocity,ch,program,pan]=n,c=this.ctx,g=c.createGain(),p=c.createStereoPanner(),source=ch===9&&Math.round(pitch)!==35&&Math.round(pitch)!==36?c.createBufferSource():c.createOscillator();
    const drum=ch===9,group=Math.floor(program/8),length=Math.max(.04,Math.min(drum?.18:12,duration));
    if('buffer' in source){source.buffer=this.noise;source.loop=true;}else{source.type=drum?'sine':[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15].map(i=>['triangle','sine','sine','triangle','triangle','sawtooth','sine','sawtooth','square','triangle','sine','triangle','sine','triangle','sine','sine'][i])[group];source.frequency.setValueAtTime(drum?100:440*2**((pitch-69)/12),at);if(drum)source.frequency.exponentialRampToValueAtTime(35,at+length);}
    const level=Math.max(.0001,velocity*(drum?.026:.045));g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(level,at+.008);g.gain.exponentialRampToValueAtTime(Math.max(.0001,level*(drum?.05:.6)),at+length);g.gain.exponentialRampToValueAtTime(.0001,at+length+.12);p.pan.value=pan;
    source.connect(g).connect(p).connect(this.music);source.onended=()=>{this.voices.delete(source);source.disconnect();g.disconnect();p.disconnect();};this.voices.add(source);source.start(at);source.stop(at+length+.13);
  }
  async effect(event){if(!this.enabled||!REFERENCE_MEDIA.sfx[event]||this.ctx?.state!=='running')return;const generation=this.generation,now=this.ctx.currentTime;if(now-(this.lastEffects.get(event)??-1)<.08)return;this.lastEffects.set(event,now);
    try{if(!this.buffers.has(event)){const bytes=Uint8Array.from(atob(REFERENCE_MEDIA.sfx[event].split(',')[1]),c=>c.charCodeAt(0));this.buffers.set(event,this.ctx.decodeAudioData(bytes.buffer));}const buffer=await this.buffers.get(event);if(!this.enabled||generation!==this.generation||this.ctx.state!=='running'||this.effects.size>=8)return;const source=this.ctx.createBufferSource();source.buffer=buffer;source.connect(this.fx);this.effects.add(source);source.onended=()=>{this.effects.delete(source);source.disconnect();};source.start();}catch{this.onStatus('효과음을 재생하지 못했습니다.');}}
  async visibility(hidden){if(!this.enabled||!this.ctx)return;if(hidden)await this.ctx.suspend();else await this.ctx.resume();}
}
