import { REFERENCE_MEDIA } from './reference-media.js';

// Standard MIDI formats 0/1, PPQN time, merged tempo map and per-channel state.
// This deliberately uses a small Web Audio synth, not an original GM sound bank.
export function parseMidi(bytes){
  const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes),v=new DataView(a.buffer,a.byteOffset,a.byteLength);
  let p=0;const need=n=>{if(p+n>a.length)throw new Error('잘린 MIDI 데이터');};
  const u8=()=>{need(1);return a[p++];},u16=()=>{need(2);const n=v.getUint16(p);p+=2;return n;},u32=()=>{need(4);const n=v.getUint32(p);p+=4;return n;};
  const tag=()=>String.fromCharCode(u8(),u8(),u8(),u8());
  const vlq=()=>{let n=0;for(let i=0;i<4;i++){const b=u8();n=n*128+(b&127);if(!(b&128))return n;}throw new Error('MIDI delta overflow');};
  if(tag()!=='MThd')throw new Error('MIDI 헤더 오류');const size=u32(),format=u16(),tracks=u16(),division=u16();
  if(size<6||format>1||!division||(division&32768))throw new Error('지원하지 않는 MIDI 시간 형식');need(size-6);p+=size-6;
  const events=[];let sequence=0;
  for(let t=0;t<tracks;t++){
    if(tag()!=='MTrk')throw new Error('MIDI 트랙 오류');const length=u32();need(length);const end=p+length;let tick=0,running=0;
    while(p<end){tick+=vlq();let status=u8();if(status<128){if(!running)throw new Error('MIDI running status 오류');p--;status=running;}else if(status<240)running=status;
      if(status===255){const type=u8(),len=vlq();need(len);if(p+len>end)throw new Error('MIDI meta 길이 오류');if(type===81&&len===3)events.push({tick,order:sequence++,tempo:a[p]*65536+a[p+1]*256+a[p+2]});p+=len;if(type===47){events.push({tick,order:sequence++,end:true});p=end;}continue;}
      if(status===240||status===247){const len=vlq();need(len);p+=len;running=0;continue;}
      if(status>=240)throw new Error('지원하지 않는 MIDI 이벤트');
      const kind=status>>4,ch=status&15,x=u8(),y=kind===12||kind===13?0:u8();
      if(x>127||y>127||p>end)throw new Error('MIDI 이벤트 길이 오류');events.push({tick,order:sequence++,kind,ch,x,y});
    }
    if(p!==end)throw new Error('MIDI 트랙 길이 오류');
  }
  events.sort((a,b)=>a.tick-b.tick||a.order-b.order);
  const channels=Array.from({length:16},()=>({program:0,volume:100,expression:127,pan:64,sustain:false,bend:0,bendRange:2,bendCents:0,rpnMSB:127,rpnLSB:127,active:new Map(),held:[]})),notes=[];
  let tick=0,time=0,tempo=500000;
  const controller=c=>(c.volume/127)**2*(c.expression/127)**2;
  const bend=c=>c.bend*(c.bendRange+c.bendCents/100);
  // Keep the initial point and the final value in each time bucket. No extra oscillators.
  const thin=(points,step)=>{const out=[points[0]];for(let i=1;i<points.length;i++){const point=points[i],last=out.at(-1);if(out.length>1&&Math.floor(last[0]/step)===Math.floor(point[0]/step))out[out.length-1]=point;else out.push(point);}return out;};
  const finish=(n,at)=>{n[1]=Math.max(.01,at-n[0]);n[7].pitch=thin(n[7].pitch,.005);n[7].gain=thin(n[7].gain,.02);notes.push(n);};
  const update=(c,kind)=>{for(const n of [...c.active.values()].flat().concat(c.held)){const value=kind==='pitch'?n[7].key+bend(c):controller(c);const points=n[7][kind];if(points.at(-1)[1]!==value)points.push([Math.max(0,time-n[0]),value]);}};
  for(const e of events){time+=(e.tick-tick)*tempo/division/1e6;tick=e.tick;if(e.tempo){tempo=e.tempo;continue;}if(e.end)continue;const c=channels[e.ch];
    if(e.kind===12)c.program=e.x;
    else if(e.kind===14){c.bend=((e.y*128+e.x)-8192)/8192;update(c,'pitch');}
    else if(e.kind===11){
      if(e.x===7)c.volume=e.y;if(e.x===11)c.expression=e.y;if(e.x===10)c.pan=e.y;
      if(e.x===101)c.rpnMSB=e.y;if(e.x===100)c.rpnLSB=e.y;
      if(e.x===99||e.x===98)c.rpnMSB=c.rpnLSB=127;
      if(c.rpnMSB===0&&c.rpnLSB===0){if(e.x===6)c.bendRange=e.y;if(e.x===38)c.bendCents=Math.min(99,e.y);if(e.x===6||e.x===38)update(c,'pitch');}
      if(e.x===7||e.x===11)update(c,'gain');
      if(e.x===64){c.sustain=e.y>=64;if(!c.sustain){for(const n of c.held)finish(n,time);c.held=[];}}
      if(e.x===120||e.x===123){for(const ns of c.active.values())for(const n of ns)finish(n,time);for(const n of c.held)finish(n,time);c.active.clear();c.held=[];}
    }else if(e.kind===9&&e.y){const velocity=(e.y/127)**1.7,pitch=e.x+bend(c),gain=controller(c);
      const n=[time,0,pitch,velocity*gain,e.ch,c.program,(c.pan-64)/64,{key:e.x,velocity,pitch:[[0,pitch]],gain:[[0,gain]]}];if(!c.active.has(e.x))c.active.set(e.x,[]);c.active.get(e.x).push(n);
    }else if(e.kind===8||(e.kind===9&&!e.y)){const ns=c.active.get(e.x),n=ns?.shift();if(n){if(c.sustain)c.held.push(n);else finish(n,time);}if(!ns?.length)c.active.delete(e.x);}
  }
  for(const c of channels){for(const ns of c.active.values())for(const n of ns)finish(n,time);for(const n of c.held)finish(n,time);}

  notes.sort((a,b)=>a[0]-b[0]);return {notes,duration:Math.max(.1,time,...notes.map(n=>n[0]+n[1]))};
}

export const AUDIO_TRACKS=REFERENCE_MEDIA.tracks.map(({id},i)=>({id,label:`원본 음악 ${String(i+1).padStart(2,'0')}`}));
export function chooseTrack(stageId){const battleTracks=AUDIO_TRACKS.filter(t=>Number(t.id.slice(2,5))>=10);return battleTracks[Math.max(0,(stageId||1)-1)%battleTracks.length]?.id||AUDIO_TRACKS[0].id;}
export const MIX_GROUPS={keys:'건반·벨',plucks:'기타·하프',bass:'베이스',strings:'현악·패드',brass:'금관',winds:'목관',synth:'신시사이저',drums:'드럼'};
export const DEFAULT_TUNING={brightness:4200,warmth:1,reverb:.16,tempo:1,gain:1,keys:1,plucks:.85,bass:.85,strings:.85,brass:.65,winds:.85,synth:.6,drums:.55};
export const TONE_KEYS=['brightness','warmth','reverb','brass','drums','synth'];
const toneValues=value=>Object.fromEntries(TONE_KEYS.map(k=>[k,value[k]]));
export const AUDIO_PRESETS={tactics:{label:'편안한 전술',values:toneValues(DEFAULT_TUNING)},battle:{label:'선명한 전투',values:toneValues({...DEFAULT_TUNING,brightness:5800,warmth:0,reverb:.1,brass:.8,drums:.7})},night:{label:'부드러운 밤',values:toneValues({...DEFAULT_TUNING,brightness:2800,warmth:2,reverb:.25,brass:.45,drums:.35,synth:.45})}};
export function matchingPreset(value){return Object.entries(AUDIO_PRESETS).find(([,p])=>TONE_KEYS.every(k=>Math.abs(value[k]-p.values[k])<1e-6))?.[0]||'';}
export const SFX_TRIM_DB={turn:-16,summon:-14,capture:-10,attack:-6,spell:-8,heal:-10,down:-4};
// Physical hits (including counters and blocked hits) sound at contact, not wind-up.
export function presentationSound(event){
  if(event.type==='attack')return null;
  if(event.type==='damage')return ['공격','반격'].includes(event.kind)?'attack':null;
  return event.type;
}
export const BGM_MAKEUP=14;
export const AUDIO_MIX_VERSION=2;
export function migrateAudioPreferences(value){if(value.audioMixVersion===AUDIO_MIX_VERSION)return {...value};const next={...value,audioMixVersion:AUDIO_MIX_VERSION};
  // Keep slider positions (including explicit mute); retain the old mix for user comparison.
  next.previousAudioMix={bgmVolume:value.bgmVolume??.35,sfxVolume:value.sfxVolume??.55};return next;}

export function sanitizeTuning(input){const out={...DEFAULT_TUNING};if(!input||typeof input!=='object')return out;for(const k of Object.keys(out)){const bounds=k==='brightness'?[1200,8500]:k==='warmth'?[-4,4]:k==='reverb'?[0,.4]:k==='tempo'?[.75,1.25]:[0,1.5];if(typeof input[k]==='number'&&Number.isFinite(input[k]))out[k]=Math.max(bounds[0],Math.min(bounds[1],input[k]));}return out;}
export function instrumentGroup(program,ch=0){if(ch===9)return 'drums';return ['keys','keys','keys','plucks','bass','strings','strings','brass','winds','winds','synth','strings','synth','plucks','drums','synth'][Math.max(0,Math.min(15,Math.floor(program/8)))];}
export function notePeak(n){return n[7]?n[7].velocity*Math.max(...n[7].gain.map(p=>p[1])):n[3];}
export function scoreHeadroom(song){const changes=[];for(const n of song.notes){const weight=n[4]===9?.25:1;changes.push([n[0],notePeak(n)**2*weight],[n[0]+Math.min(n[1],12),-(notePeak(n)**2)*weight]);}changes.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);let energy=0,peak=0;for(const [_,delta] of changes){energy+=delta;peak=Math.max(peak,energy);}return Math.max(.4,Math.min(1,1.1/Math.sqrt(Math.max(1,peak))));}
const SYNTH_PROFILES={
  keys:{harmonics:[1,.32,.11,.035],attack:.008,decay:.28,sustain:.22,release:.16,level:.075,cutoff:5200},
  plucks:{harmonics:[1,.38,.15,.055,.025],attack:.009,decay:.16,sustain:.12,release:.14,level:.07,cutoff:4200},
  bass:{harmonics:[1,.2,.045],attack:.014,decay:.16,sustain:.65,release:.12,level:.09,cutoff:1300},
  strings:{harmonics:[1,.3,.13,.055,.025,.01],attack:.09,decay:.2,sustain:.7,release:.35,level:.05,cutoff:3700},
  brass:{harmonics:[1,.3,.12,.04],attack:.04,decay:.16,sustain:.55,release:.2,level:.055,cutoff:3000},
  winds:{harmonics:[1,.13,.09,.015],attack:.035,decay:.18,sustain:.65,release:.2,level:.065,cutoff:4200},
  synth:{harmonics:[1,.24,.11,.035,.018],attack:.035,decay:.2,sustain:.45,release:.25,level:.055,cutoff:3400},
  drums:{harmonics:[1,.2,.03],attack:.005,decay:.1,sustain:.08,release:.08,level:.06,cutoff:3000}
};
export class GameAudio {
  constructor(onStatus=()=>{}){this.onStatus=onStatus;this.onEffectError=()=>{};this.decodeFailures=new Map();this.voiceGains=new Map();this.enabled=false;this.generation=0;this.effectGeneration=0;this.trackId=chooseTrack(1);this.bgmVolume=.35;this.sfxVolume=.55;this.cache=new Map();this.buffers=new Map();this.voices=new Set();this.effects=new Set();this.lastEffects=new Map();this.tunings={};this.tuning=sanitizeTuning();this.autoGain=1;this.waves=new Map();}
  async track(id){if(this.cache.has(id))return this.cache.get(id);const data=REFERENCE_MEDIA.tracks.find(t=>t.id===id);if(!data)throw new Error('음악을 찾을 수 없습니다.');const bytes=Uint8Array.from(atob(data.gzip),c=>c.charCodeAt(0));const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));const result=parseMidi(await new Response(stream).arrayBuffer());this.cache.set(id,result);return result;}
  context(supplied){if(!this.ctx){const Audio=globalThis.AudioContext||globalThis.webkitAudioContext;if(!supplied&&!Audio)throw new Error('이 브라우저는 오디오를 지원하지 않습니다.');const c=this.ctx=supplied||new Audio();this.master=c.createDynamicsCompressor();this.master.threshold.value=-3;this.master.knee.value=0;this.master.ratio.value=20;this.master.attack.value=.003;this.master.release.value=.18;this.output=c.createGain();this.output.gain.value=.8;this.master.connect(this.output).connect(c.destination);
    this.music=c.createGain();this.music.gain.value=this.bgmVolume*BGM_MAKEUP;this.music.connect(this.master);this.fx=c.createGain();this.fx.gain.value=this.sfxVolume;this.fx.connect(this.master);
    this.bgmBus=c.createGain();this.bgmTone=c.createBiquadFilter();this.bgmTone.type='lowpass';this.bgmTone.Q.value=.55;this.bgmWarmth=c.createBiquadFilter();this.bgmWarmth.type='lowshelf';this.bgmWarmth.frequency.value=220;this.bgmCompressor=c.createDynamicsCompressor();this.bgmCompressor.threshold.value=-18;this.bgmCompressor.knee.value=12;this.bgmCompressor.ratio.value=2.5;this.bgmCompressor.attack.value=.025;this.bgmCompressor.release.value=.22;
    this.bgmLowCut=c.createBiquadFilter();this.bgmLowCut.type='highpass';this.bgmLowCut.frequency.value=85;this.bgmLowCut.Q.value=.55;this.bgmBus.connect(this.bgmLowCut).connect(this.bgmWarmth).connect(this.bgmTone).connect(this.bgmCompressor);this.dry=c.createGain();this.wet=c.createGain();this.bgmCompressor.connect(this.dry).connect(this.music);this.reverb=c.createConvolver();this.bgmCompressor.connect(this.wet).connect(this.reverb).connect(this.music);
    let seed=173;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296*2-1;};this.noise=c.createBuffer(1,c.sampleRate,c.sampleRate);const noise=this.noise.getChannelData(0);for(let i=0;i<noise.length;i++)noise[i]=random();
    const impulse=c.createBuffer(2,Math.floor(c.sampleRate*.9),c.sampleRate);for(let ch=0;ch<2;ch++){const data=impulse.getChannelData(ch);let smooth=0;for(let i=0;i<data.length;i++){smooth=.65*smooth+.35*random();data[i]=i<c.sampleRate*.015?0:smooth*(1-i/data.length)**3;}}this.reverb.buffer=impulse;c.onstatechange=()=>{if(this.enabled&&c.state==='interrupted')this.onStatus('소리 켜짐 · 오디오 일시 중단, 화면을 터치하면 재개합니다.');};this.applyMix();}return this.ctx;}
  loadTunings(value){this.tunings={};if(value&&typeof value==='object')for(const {id} of AUDIO_TRACKS)if(value[id])this.tunings[id]=sanitizeTuning(value[id]);this.tuning=this.getTuning();this.applyMix();}
  getTuning(id=this.trackId){return sanitizeTuning(this.tunings[id]);}
  tune(value,all=false){const next=sanitizeTuning({...this.getTuning(),...value}),oldTempo=this.tuning.tempo;if(all)for(const {id} of AUDIO_TRACKS)this.tunings[id]={...next};else this.tunings[this.trackId]={...next};this.tuning=next;
    // Keep the musical playhead; already scheduled 180ms retains the old speed.
    if(this.ctx&&this.song&&oldTempo!==next.tempo){const position=(this.ctx.currentTime-this.epoch)*oldTempo;this.epoch=this.ctx.currentTime-position/next.tempo;}
    this.applyMix();return structuredClone(this.tunings);}
  applyMix(){if(!this.bgmBus)return;const at=this.ctx.currentTime,t=this.tuning;this.bgmBus.gain.setTargetAtTime(this.autoGain*t.gain,at,.06);this.bgmTone.frequency.setTargetAtTime(t.brightness,at,.06);this.bgmWarmth.gain.setTargetAtTime(t.warmth,at,.06);this.dry.gain.setTargetAtTime(1-t.reverb*.3,at,.06);this.wet.gain.setTargetAtTime(t.reverb,at,.06);for(const [group,bus] of this.groupBuses||[])bus.gain.setTargetAtTime(t[group],at,.06);}
  groupBus(group){this.groupBuses??=new Map();if(!this.groupBuses.has(group)){const bus=this.ctx.createGain();bus.gain.value=this.tuning[group];bus.connect(this.bgmBus);this.groupBuses.set(group,bus);}return this.groupBuses.get(group);}
  volumes(bgm,sfx){this.bgmVolume=Math.max(0,Math.min(1,Number(bgm)||0));this.sfxVolume=Math.max(0,Math.min(1,Number(sfx)||0));if(this.ctx){this.music.gain.setTargetAtTime(this.bgmVolume*BGM_MAKEUP,this.ctx.currentTime,.02);this.fx.gain.setTargetAtTime(this.sfxVolume,this.ctx.currentTime,.02);}}
  stopMusic(fade=.03){clearInterval(this.timer);this.timer=null;const now=this.ctx?.currentTime||0;for(const source of this.voices){try{const gain=this.voiceGains.get(source);if(gain){gain.cancelAndHoldAtTime(now);gain.linearRampToValueAtTime(0,now+fade);}source.stop(now+fade);}catch{}}this.voices.clear();}

  async enable(){clearTimeout(this.suspendTimer);this.enabled=true;this.decodeFailures.clear();return this.resume(true);}
  async resume(fromGesture=false){
    if(!this.enabled||globalThis.document?.hidden)return;
    // Some mobile browsers keep a non-gesture resume pending until a fresh gesture.
    if(this.resumePending){if(fromGesture)await this.context().resume();return this.resumePending;}
    const task=(async()=>{try{
      await this.context().resume();
      if(!this.enabled)return;
      if(globalThis.document?.hidden){await this.ctx.suspend();return;}
      if(this.ctx.state!=='running')throw new Error('오디오 재개 대기');
      if(!this.timer||this.songId!==this.trackId)await this.select(this.trackId);
      else this.onStatus(`${AUDIO_TRACKS.find(t=>t.id===this.songId)?.label||'음악'} 재생 중`);
    }catch(error){if(this.enabled)this.onStatus('소리 켜짐 · 재생 대기 중, 화면을 터치하면 다시 시도합니다.');throw error;}})();
    this.resumePending=task;
    try{return await task;}finally{if(this.resumePending===task)this.resumePending=null;}
  }
  disable(){this.enabled=false;this.generation++;this.effectGeneration++;this.stopMusic();for(const source of this.effects){try{source.stop();}catch{}}this.effects.clear();const token=this.generation;this.suspendTimer=setTimeout(()=>{if(!this.enabled&&token===this.generation)this.ctx?.suspend().catch(()=>{});},40);this.onStatus('소리 꺼짐');}
  async select(id){if(!AUDIO_TRACKS.some(t=>t.id===id))return;this.trackId=id;const generation=++this.generation;
    if(!this.enabled||!this.ctx){this.tuning=this.getTuning(id);this.applyMix();return;}
    if(this.songId===id&&this.timer)return;
    try{const song=await this.track(id);if(!this.enabled||generation!==this.generation)return;
      this.stopMusic();this.song=song;this.songId=id;this.tuning=this.getTuning(id);this.autoGain=scoreHeadroom(song);this.applyMix();this.cursor=0;this.epoch=this.ctx.currentTime+.12-(song.notes[0]?.[0]||0)/this.tuning.tempo;this.timer=setInterval(()=>this.schedule(),50);this.schedule();this.onStatus(`${AUDIO_TRACKS.find(t=>t.id===id).label} 재생 중`);
    }catch(error){if(generation!==this.generation)return;this.onStatus('곡을 불러오지 못했습니다 · 소리 설정은 유지됩니다.');throw error;}}
  schedule(){if(!this.enabled||this.ctx.state!=='running'||!this.song)return;const until=this.ctx.currentTime+.18;let budget=256;while(budget-->0){if(this.cursor>=this.song.notes.length){if(this.epoch+this.song.duration/this.tuning.tempo>until)break;this.epoch+=this.song.duration/this.tuning.tempo;this.cursor=0;if(!this.song.notes.length)break;}const note=this.song.notes[this.cursor];if(!note||this.epoch+note[0]/this.tuning.tempo>until)break;const at=this.epoch+note[0]/this.tuning.tempo;if(at>=this.ctx.currentTime-.05)this.note(note,Math.max(at,this.ctx.currentTime));this.cursor++;}}
  note(n,at){
    if(this.voices.size>=64)return;
    const [,duration,pitch,velocity,ch,program,pan]=n,c=this.ctx,group=instrumentGroup(program,ch),profile=SYNTH_PROFILES[group];
    if(notePeak(n)<=0)return;
    const drum=ch===9,key=Math.round(pitch),kick=drum&&[35,36].includes(key),tom=drum&&[41,43,45,47,48,50].includes(key),hat=drum&&[42,44,46].includes(key),cymbal=drum&&[49,51,52,53,55,57,59].includes(key),noisy=drum&&!kick&&!tom;
    const source=noisy?c.createBufferSource():c.createOscillator(),filter=c.createBiquadFilter(),g=c.createGain(),panNode=c.createStereoPanner(),expression=c.createGain();
    const length=drum?(kick?.26:tom?.22:hat?(key===46?.22:.065):cymbal?.65:.14):Math.max(.04,Math.min(12,duration/this.tuning.tempo));
    const attack=Math.min(profile.attack,length*.3),decay=Math.min(profile.decay,length*.4),release=drum?.045:profile.release;
    if(noisy){source.buffer=this.noise;source.loop=true;filter.type='bandpass';filter.frequency.value=hat?3000:cymbal?2400:1700;filter.Q.value=.6;}
    else{const frequency=drum?(kick?130:80+(key-41)*9):440*2**((pitch-69)/12);
      if(drum)source.type='sine';else{const brightness=Math.round(this.tuning.brightness/250)*250,tilt=.85*Math.log2(brightness/4250),waveKey=group+':'+program+':'+brightness;if(!this.waves.has(waveKey)){const re=new Float32Array(33),im=new Float32Array(33);for(let i=0;i<32;i++){const h=profile.harmonics[i]??profile.harmonics.at(-1)*(profile.harmonics.length/(i+1))**1.5;im[i+1]=h*(i+1)**tilt/(1+i*(program%8)*.025);}this.waves.set(waveKey,c.createPeriodicWave(re,im));}source.setPeriodicWave(this.waves.get(waveKey));}
      source.frequency.setValueAtTime(frequency,at);if(!drum&&n[7])for(const [offset,value] of n[7].pitch){if(offset/this.tuning.tempo<=length)source.frequency.linearRampToValueAtTime(440*2**((value-69)/12),at+offset/this.tuning.tempo);}if(drum)source.frequency.exponentialRampToValueAtTime(kick?42:frequency*.55,at+length);filter.type='lowpass';filter.frequency.value=drum?750:Math.min(10000,Math.max(frequency*1.5,profile.cutoff*this.tuning.brightness/4200));filter.Q.value=.55;
    }
    const level=Math.max(.00001,(n[7]?.velocity??velocity**1.7)*(drum?(kick?.09:tom?.09:hat?.034:cymbal?.026:.085):profile.level*(group==='bass'?.8:1)));
    g.gain.setValueAtTime(.00001,at);g.gain.exponentialRampToValueAtTime(level,at+attack);g.gain.exponentialRampToValueAtTime(Math.max(.00001,level*(drum?.06:profile.sustain)),at+attack+decay);g.gain.setValueAtTime(Math.max(.00001,level*(drum?.06:profile.sustain)),at+length);g.gain.exponentialRampToValueAtTime(.00001,at+length+release);panNode.pan.value=Math.max(-1,Math.min(1,pan))*.8;
    expression.gain.setValueAtTime(n[7]?.gain[0][1]??1,at);if(n[7])for(const [offset,value] of n[7].gain.slice(1)){if(offset/this.tuning.tempo<=length)expression.gain.setTargetAtTime(value,at+offset/this.tuning.tempo,.02);}
    source.connect(filter).connect(g).connect(expression).connect(panNode).connect(this.groupBus(group));this.voiceGains.set(source,g.gain);source.onended=()=>{this.voices.delete(source);source.disconnect();filter.disconnect();g.disconnect();expression.disconnect();panNode.disconnect();this.voiceGains.delete(source);};this.voices.add(source);source.start(at);source.stop(at+length+release+.01);
  }
  async effect(event){if(!this.enabled||!REFERENCE_MEDIA.sfx[event]||this.ctx?.state!=='running'||(this.decodeFailures.get(event)||0)>=3)return;const generation=this.effectGeneration,now=this.ctx.currentTime;if(now-(this.lastEffects.get(event)??-1)<(event==='turn'?.3:.08))return;this.lastEffects.set(event,now);
    let pending;
    try{if(!this.buffers.has(event)){const bytes=Uint8Array.from(atob(REFERENCE_MEDIA.sfx[event].split(',')[1]),c=>c.charCodeAt(0));this.buffers.set(event,this.ctx.decodeAudioData(bytes.buffer));}pending=this.buffers.get(event);const buffer=await pending;this.decodeFailures.delete(event);if(!this.enabled||generation!==this.effectGeneration||this.ctx.state!=='running'||this.effects.size>=8)return;
      const source=this.ctx.createBufferSource();source.buffer=buffer;const trim=this.ctx.createGain();trim.gain.value=10**((SFX_TRIM_DB[event]??-10)/20);source.connect(trim);trim.connect(this.fx);this.effects.add(source);source.onended=()=>{this.effects.delete(source);source.disconnect();trim.disconnect();};source.start();
    }catch{if(this.buffers.get(event)===pending){this.buffers.delete(event);this.decodeFailures.set(event,(this.decodeFailures.get(event)||0)+1);}this.onEffectError((this.decodeFailures.get(event)||0)>=3?'효과음 로딩 실패 · 소리를 껐다 켜면 재시도합니다.':'효과음 로딩 실패 · 다음 요청에서 재시도합니다.');}}
  async visibility(hidden){if(!this.enabled||!this.ctx)return;if(hidden){await this.ctx.suspend();if(this.enabled)this.onStatus('소리 켜짐 · 화면 복귀 시 재생');}else await this.resume();}
}
