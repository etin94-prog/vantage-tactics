import { REFERENCE_MEDIA } from './reference-media.js';

// Standard MIDI formats 0/1, PPQN time, merged tempo map and per-channel state.
// This deliberately uses a small Web Audio synth, not an original GM sound bank.
export function parseMidi(bytes){
  const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes),v=new DataView(a.buffer,a.byteOffset,a.byteLength);
  let p=0;const need=n=>{if(p+n>a.length)throw new Error('잘린 MIDI 데이터');};
  const u8=()=>{need(1);return a[p++];},u16=()=>{need(2);const n=v.getUint16(p);p+=2;return n;},u32=()=>{need(4);const n=v.getUint32(p);p+=4;return n;};
  const tag=()=>String.fromCharCode(u8(),u8(),u8(),u8());
  const vlq=()=>{let n=0;for(let i=0;i<4;i++){const b=u8();n=n*128+(b&127);if(!(b&128))return n;}throw new Error('MIDI delta overflow');};
  if(tag()!=='MThd')throw new Error('MIDI 헤더 오류');const size=u32(),format=u16(),tracks=u16(),division=u16();
  if(size<6||format>1||!division||(division&32768))throw new Error('지원하지 않는 MIDI 시간 형식');need(size-6);p+=size-6;
  const events=[];let sequence=0;
  for(let t=0;t<tracks;t++){
    if(tag()!=='MTrk')throw new Error('MIDI 트랙 오류');const length=u32();need(length);const end=p+length;let tick=0,running=0;
    while(p<end){tick+=vlq();let status=u8();if(status<128){if(!running)throw new Error('MIDI running status 오류');p--;status=running;}else if(status<240)running=status;
      if(status===255){const type=u8(),len=vlq();need(len);if(p+len>end)throw new Error('MIDI meta 길이 오류');if(type===81&&len===3)events.push({tick,order:sequence++,tempo:a[p]*65536+a[p+1]*256+a[p+2]});p+=len;if(type===47){events.push({tick,order:sequence++,end:true});p=end;}continue;}
      if(status===240||status===247){const len=vlq();need(len);p+=len;running=0;continue;}
      if(status>=240)throw new Error('지원하지 않는 MIDI 이벤트');
      const kind=status>>4,ch=status&15,x=u8(),y=kind===12||kind===13?0:u8();
      if(x>127||y>127||p>end)throw new Error('MIDI 이벤트 길이 오류');events.push({tick,order:sequence++,kind,ch,x,y});
    }
    if(p!==end)throw new Error('MIDI 트랙 길이 오류');
  }
  events.sort((a,b)=>a.tick-b.tick||a.order-b.order);
  const channels=Array.from({length:16},()=>({program:0,volume:100,expression:127,pan:64,sustain:false,bend:0,active:new Map(),held:[]})),notes=[];
  let tick=0,time=0,tempo=500000;
  const finish=(n,at)=>{n[1]=Math.max(.01,at-n[0]);notes.push(n);};
  for(const e of events){time+=(e.tick-tick)*tempo/division/1e6;tick=e.tick;if(e.tempo){tempo=e.tempo;continue;}if(e.end)continue;const c=channels[e.ch];
    if(e.kind===12)c.program=e.x;
    else if(e.kind===14)c.bend=((e.y*128+e.x)-8192)/8192*2;
    else if(e.kind===11){if(e.x===7)c.volume=e.y;if(e.x===11)c.expression=e.y;if(e.x===10)c.pan=e.y;
      if(e.x===64){c.sustain=e.y>=64;if(!c.sustain){for(const n of c.held)finish(n,time);c.held=[];}}
      if(e.x===120||e.x===123){for(const ns of c.active.values())for(const n of ns)finish(n,time);for(const n of c.held)finish(n,time);c.active.clear();c.held=[];}
    }else if(e.kind===9&&e.y){const n=[time,0,e.x+c.bend,e.y/127*c.volume/127*c.expression/127,e.ch,c.program,(c.pan-64)/64];if(!c.active.has(e.x))c.active.set(e.x,[]);c.active.get(e.x).push(n);
    }else if(e.kind===8||(e.kind===9&&!e.y)){const ns=c.active.get(e.x),n=ns?.shift();if(n){if(c.sustain)c.held.push(n);else finish(n,time);}if(!ns?.length)c.active.delete(e.x);}
  }
  for(const c of channels){for(const ns of c.active.values())for(const n of ns)finish(n,time);for(const n of c.held)finish(n,time);}
  notes.sort((a,b)=>a[0]-b[0]);return {notes,duration:Math.max(.1,time,...notes.map(n=>n[0]+n[1]))};
}

export const AUDIO_TRACKS=REFERENCE_MEDIA.tracks.map(({id},i)=>({id,label:`원본 음악 ${String(i+1).padStart(2,'0')}`}));
export function chooseTrack(stageId){const battleTracks=AUDIO_TRACKS.filter(t=>Number(t.id.slice(2,5))>=10);return battleTracks[Math.max(0,(stageId||1)-1)%battleTracks.length]?.id||AUDIO_TRACKS[0].id;}
export const MIX_GROUPS={keys:'건반·벨',plucks:'기타·하프',bass:'베이스',strings:'현악·패드',brass:'금관',winds:'목관',synth:'신시사이저',drums:'드럼'};
export const DEFAULT_TUNING={brightness:4200,warmth:1,reverb:.16,tempo:1,gain:1,keys:1,plucks:.85,bass:.85,strings:.85,brass:.65,winds:.85,synth:.6,drums:.55};
export const AUDIO_PRESETS={tactics:{label:'편안한 전술',values:DEFAULT_TUNING},battle:{label:'선명한 전투',values:{...DEFAULT_TUNING,brightness:5800,warmth:0,reverb:.1,brass:.8,drums:.7}},night:{label:'부드러운 밤',values:{...DEFAULT_TUNING,brightness:2800,warmth:2,reverb:.25,brass:.45,drums:.35,synth:.45}}};
export function sanitizeTuning(input){const out={...DEFAULT_TUNING};if(!input||typeof input!=='object')return out;for(const k of Object.keys(out)){const bounds=k==='brightness'?[1200,8500]:k==='warmth'?[-4,4]:k==='reverb'?[0,.4]:k==='tempo'?[.75,1.25]:[0,1.5];if(typeof input[k]==='number'&&Number.isFinite(input[k]))out[k]=Math.max(bounds[0],Math.min(bounds[1],input[k]));}return out;}
export function instrumentGroup(program,ch=0){if(ch===9)return 'drums';return ['keys','keys','keys','plucks','bass','strings','strings','brass','winds','winds','synth','strings','synth','plucks','drums','synth'][Math.max(0,Math.min(15,Math.floor(program/8)))];}
export function scoreHeadroom(song){const changes=[];for(const n of song.notes){const weight=n[4]===9?.25:1;changes.push([n[0],n[3]**2*weight],[n[0]+Math.min(n[1],12),-(n[3]**2)*weight]);}changes.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);let energy=0,peak=0;for(const [_,delta] of changes){energy+=delta;peak=Math.max(peak,energy);}return Math.max(.4,Math.min(1,1.1/Math.sqrt(Math.max(1,peak))));}
const SYNTH_PROFILES={
  keys:{harmonics:[1,.32,.11,.035],attack:.008,decay:.28,sustain:.22,release:.16,level:.075,cutoff:5200},
  plucks:{harmonics:[1,.38,.15,.055,.025],attack:.009,decay:.16,sustain:.12,release:.14,level:.07,cutoff:4200},
  bass:{harmonics:[1,.2,.045],attack:.014,decay:.16,sustain:.65,release:.12,level:.09,cutoff:1300},
  strings:{harmonics:[1,.3,.13,.055,.025,.01],attack:.09,decay:.2,sustain:.7,release:.35,level:.05,cutoff:3700},
  brass:{harmonics:[1,.3,.12,.04],attack:.04,decay:.16,sustain:.55,release:.2,level:.055,cutoff:3000},
  winds:{harmonics:[1,.13,.09,.015],attack:.035,decay:.18,sustain:.65,release:.2,level:.065,cutoff:4200},
  synth:{harmonics:[1,.24,.11,.035,.018],attack:.035,decay:.2,sustain:.45,release:.25,level:.055,cutoff:3400},
  drums:{harmonics:[1,.2,.03],attack:.005,decay:.1,sustain:.08,release:.08,level:.06,cutoff:3000}
};
export class GameAudio {
  constructor(onStatus=()=>{}){this.onStatus=onStatus;this.enabled=false;this.generation=0;this.trackId=chooseTrack(1);this.bgmVolume=.35;this.sfxVolume=.55;this.cache=new Map();this.buffers=new Map();this.voices=new Set();this.effects=new Set();this.lastEffects=new Map();this.tunings={};this.tuning=sanitizeTuning();this.autoGain=1;this.waves=new Map();}
  async track(id){if(this.cache.has(id))return this.cache.get(id);const data=REFERENCE_MEDIA.tracks.find(t=>t.id===id);if(!data)throw new Error('음악을 찾을 수 없습니다.');const bytes=Uint8Array.from(atob(data.gzip),c=>c.charCodeAt(0));const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));const result=parseMidi(await new Response(stream).arrayBuffer());this.cache.set(id,result);return result;}
  context(supplied){if(!this.ctx){const Audio=globalThis.AudioContext||globalThis.webkitAudioContext;if(!supplied&&!Audio)throw new Error('이 브라우저는 오디오를 지원하지 않습니다.');const c=this.ctx=supplied||new Audio();this.master=c.createDynamicsCompressor();this.master.threshold.value=-8;this.master.knee.value=8;this.master.ratio.value=8;this.master.attack.value=.003;this.master.release.value=.18;this.master.connect(c.destination);
    this.music=c.createGain();this.music.gain.value=this.bgmVolume;this.music.connect(this.master);this.fx=c.createGain();this.fx.gain.value=this.sfxVolume;this.fx.connect(this.master);
    this.bgmBus=c.createGain();this.bgmTone=c.createBiquadFilter();this.bgmTone.type='lowpass';this.bgmTone.Q.value=.55;this.bgmWarmth=c.createBiquadFilter();this.bgmWarmth.type='lowshelf';this.bgmWarmth.frequency.value=220;this.bgmCompressor=c.createDynamicsCompressor();this.bgmCompressor.threshold.value=-18;this.bgmCompressor.knee.value=12;this.bgmCompressor.ratio.value=2.5;this.bgmCompressor.attack.value=.025;this.bgmCompressor.release.value=.22;
    this.bgmBus.connect(this.bgmWarmth).connect(this.bgmTone).connect(this.bgmCompressor);this.dry=c.createGain();this.wet=c.createGain();this.bgmCompressor.connect(this.dry).connect(this.music);this.reverb=c.createConvolver();this.bgmCompressor.connect(this.wet).connect(this.reverb).connect(this.music);
    let seed=173;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296*2-1;};this.noise=c.createBuffer(1,c.sampleRate,c.sampleRate);const noise=this.noise.getChannelData(0);for(let i=0;i<noise.length;i++)noise[i]=random();
    const impulse=c.createBuffer(2,Math.floor(c.sampleRate*.9),c.sampleRate);for(let ch=0;ch<2;ch++){const data=impulse.getChannelData(ch);let smooth=0;for(let i=0;i<data.length;i++){smooth=.65*smooth+.35*random();data[i]=i<c.sampleRate*.015?0:smooth*(1-i/data.length)**3;}}this.reverb.buffer=impulse;this.applyMix();}return this.ctx;}
  loadTunings(value){this.tunings={};if(value&&typeof value==='object')for(const {id} of AUDIO_TRACKS)if(value[id])this.tunings[id]=sanitizeTuning(value[id]);this.tuning=this.getTuning();this.applyMix();}
  getTuning(id=this.trackId){return sanitizeTuning(this.tunings[id]);}
  tune(value,all=false){const next=sanitizeTuning(value),oldTempo=this.tuning.tempo;if(all)for(const {id} of AUDIO_TRACKS)this.tunings[id]={...next};else this.tunings[this.trackId]={...next};this.tuning=next;
    // Keep the musical playhead; already scheduled 180ms retains the old speed.
    if(this.ctx&&this.song&&oldTempo!==next.tempo){const position=(this.ctx.currentTime-this.epoch)*oldTempo;this.epoch=this.ctx.currentTime-position/next.tempo;}
    this.applyMix();return structuredClone(this.tunings);}
  applyMix(){if(!this.bgmBus)return;const at=this.ctx.currentTime,t=this.tuning;this.bgmBus.gain.setTargetAtTime(this.autoGain*t.gain,at,.06);this.bgmTone.frequency.setTargetAtTime(t.brightness,at,.06);this.bgmWarmth.gain.setTargetAtTime(t.warmth,at,.06);this.dry.gain.setTargetAtTime(1-t.reverb*.3,at,.06);this.wet.gain.setTargetAtTime(t.reverb,at,.06);for(const [group,bus] of this.groupBuses||[])bus.gain.setTargetAtTime(t[group],at,.06);}
  groupBus(group){this.groupBuses??=new Map();if(!this.groupBuses.has(group)){const bus=this.ctx.createGain();bus.gain.value=this.tuning[group];bus.connect(this.bgmBus);this.groupBuses.set(group,bus);}return this.groupBuses.get(group);}
  volumes(bgm,sfx){this.bgmVolume=Math.max(0,Math.min(1,Number(bgm)||0));this.sfxVolume=Math.max(0,Math.min(1,Number(sfx)||0));if(this.ctx){this.music.gain.setTargetAtTime(this.bgmVolume,this.ctx.currentTime,.02);this.fx.gain.setTargetAtTime(this.sfxVolume,this.ctx.currentTime,.02);}}
  stopMusic(){clearInterval(this.timer);this.timer=null;for(const source of this.voices){try{source.stop();}catch{}}this.voices.clear();}
  async enable(){if(this.enabled)return;this.enabled=true;this.onStatus('음악 불러오는 중');try{await this.context().resume();if(!this.enabled)return;await this.select(this.trackId);if(this.enabled&&globalThis.document?.hidden)await this.ctx.suspend();}catch(error){this.disable();this.onStatus(error.message);throw error;}}
  disable(){this.enabled=false;this.generation++;this.stopMusic();for(const source of this.effects){try{source.stop();}catch{}}this.effects.clear();this.ctx?.suspend().catch(()=>{});this.onStatus('소리 꺼짐');}
  async select(id){if(!AUDIO_TRACKS.some(t=>t.id===id))return;this.trackId=id;this.tuning=this.getTuning(id);this.applyMix();const generation=++this.generation;this.stopMusic();if(!this.enabled)return;try{const song=await this.track(id);if(!this.enabled||generation!==this.generation)return;this.song=song;this.autoGain=scoreHeadroom(song);this.applyMix();this.cursor=0;this.epoch=this.ctx.currentTime+.12;this.timer=setInterval(()=>this.schedule(),50);this.schedule();this.onStatus(`${AUDIO_TRACKS.find(t=>t.id===id).label} 재생 중`);}catch(error){if(generation!==this.generation)return;this.disable();this.onStatus(error.message);throw error;}}
  schedule(){if(!this.enabled||this.ctx.state!=='running'||!this.song)return;const until=this.ctx.currentTime+.18;let budget=256;while(budget-->0){if(this.cursor>=this.song.notes.length){if(this.epoch+this.song.duration/this.tuning.tempo>until)break;this.epoch+=this.song.duration/this.tuning.tempo;this.cursor=0;if(!this.song.notes.length)break;}const note=this.song.notes[this.cursor];if(!note||this.epoch+note[0]/this.tuning.tempo>until)break;const at=this.epoch+note[0]/this.tuning.tempo;if(at>=this.ctx.currentTime-.05)this.note(note,Math.max(at,this.ctx.currentTime));this.cursor++;}}
  note(n,at){
    if(this.voices.size>=64)return;
    const [,duration,pitch,velocity,ch,program,pan]=n,c=this.ctx,group=instrumentGroup(program,ch),profile=SYNTH_PROFILES[group];
    if(velocity<=0)return;
    const drum=ch===9,key=Math.round(pitch),kick=drum&&[35,36].includes(key),tom=drum&&[41,43,45,47,48,50].includes(key),hat=drum&&[42,44,46].includes(key),cymbal=drum&&[49,51,52,53,55,57,59].includes(key),noisy=drum&&!kick&&!tom;
    const source=noisy?c.createBufferSource():c.createOscillator(),filter=c.createBiquadFilter(),g=c.createGain(),panNode=c.createStereoPanner();
    const length=drum?(kick?.26:tom?.22:hat?(key===46?.22:.065):cymbal?.65:.14):Math.max(.04,Math.min(12,duration/this.tuning.tempo));
    const attack=Math.min(profile.attack,length*.3),decay=Math.min(profile.decay,length*.4),release=drum?.045:profile.release;
    if(noisy){source.buffer=this.noise;source.loop=true;filter.type=hat||cymbal?'highpass':'bandpass';filter.frequency.value=hat?6500:cymbal?4800:1700;filter.Q.value=.6;}
    else{const frequency=drum?(kick?130:80+(key-41)*9):440*2**((pitch-69)/12);
      if(drum)source.type='sine';else{const waveKey=group+':'+program;if(!this.waves.has(waveKey)){const re=new Float32Array(10),im=new Float32Array(10);profile.harmonics.forEach((h,i)=>im[i+1]=h/(1+i*(program%8)*.025));this.waves.set(waveKey,c.createPeriodicWave(re,im));}source.setPeriodicWave(this.waves.get(waveKey));}
      source.frequency.setValueAtTime(frequency,at);if(drum)source.frequency.exponentialRampToValueAtTime(kick?42:frequency*.55,at+length);filter.type='lowpass';filter.frequency.value=drum?750:Math.min(10000,Math.max(frequency*1.5,profile.cutoff));filter.Q.value=.55;
    }
    const level=Math.max(.00001,velocity**1.15*(drum?(kick?.12:tom?.09:hat?.034:cymbal?.026:.085):profile.level));
    g.gain.setValueAtTime(.00001,at);g.gain.exponentialRampToValueAtTime(level,at+attack);g.gain.exponentialRampToValueAtTime(Math.max(.00001,level*(drum?.06:profile.sustain)),at+attack+decay);g.gain.setValueAtTime(Math.max(.00001,level*(drum?.06:profile.sustain)),at+length);g.gain.exponentialRampToValueAtTime(.00001,at+length+release);panNode.pan.value=Math.max(-1,Math.min(1,pan))*.8;
    source.connect(filter).connect(g).connect(panNode).connect(this.groupBus(group));source.onended=()=>{this.voices.delete(source);source.disconnect();filter.disconnect();g.disconnect();panNode.disconnect();};this.voices.add(source);source.start(at);source.stop(at+length+release+.01);
  }
  async effect(event){if(!this.enabled||!REFERENCE_MEDIA.sfx[event]||this.ctx?.state!=='running')return;const generation=this.generation,now=this.ctx.currentTime;if(now-(this.lastEffects.get(event)??-1)<.08)return;this.lastEffects.set(event,now);
    try{if(!this.buffers.has(event)){const bytes=Uint8Array.from(atob(REFERENCE_MEDIA.sfx[event].split(',')[1]),c=>c.charCodeAt(0));this.buffers.set(event,this.ctx.decodeAudioData(bytes.buffer));}const buffer=await this.buffers.get(event);if(!this.enabled||generation!==this.generation||this.ctx.state!=='running'||this.effects.size>=8)return;const source=this.ctx.createBufferSource();source.buffer=buffer;source.connect(this.fx);this.effects.add(source);source.onended=()=>{this.effects.delete(source);source.disconnect();};source.start();}catch{this.onStatus('효과음을 재생하지 못했습니다.');}}
  async visibility(hidden){if(!this.enabled||!this.ctx)return;if(hidden)await this.ctx.suspend();else await this.ctx.resume();}
}
