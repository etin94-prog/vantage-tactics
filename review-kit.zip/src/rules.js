import { V2_RULE_TABLES } from './v2-reference.js';
// Read-only reconstruction of English vmv2.exe. See docs/EXE_STATIC_ANALYSIS.md.
// Original speed domain is 0..20; custom values saturate instead of reading past the table.
export function actionMinutes(speed,extra=0,moved=false){const s=Math.max(0,Math.min(20,Math.trunc(speed))),base=30+extra+(moved?15:0);return Math.max(1,Math.floor((base*V2_RULE_TABLES.oaScale[s]+128)/256));}
export function ruleHeight(tile){return tile?.runtimeHeight??tile?.secondaryHeight??tile?.elevation??0;}
export function ruleTerrain(tile){return tile?.runtimeTerrainCode??tile?.terrainCode??({grass:0,sand:1,forest:2,marsh:3,snow:4,swamp:5,ice:6,floating:6,water:7,deep_water:8,wall:10,void:16,stone:12,rock:0,lava:0})[tile?.terrain]??16;}
export function movementType(unit){return unit.movementType??(unit.flying?4:unit.aquatic?3:0);}
export function originalMoveCost(unit,to,from=to){const type=movementType(unit),cost=V2_RULE_TABLES.moveCost[type]?.[ruleTerrain(to)]??127,rise=ruleHeight(to)-ruleHeight(from);return cost>=127||type!==4&&Math.abs(rise)>1?Infinity:cost+(type!==4&&rise>0?1:0);}
export function originalCanLand(unit,tile){return !!tile&&!!V2_RULE_TABLES.landing[movementType(unit)]?.[ruleTerrain(tile)];}
export function originalTerrainPercent(tile){return V2_RULE_TABLES.terrainPercent[ruleTerrain(tile)]??100;}
export function originalElementOffset(attacker,defender){const ids={neutral:0,earth:1,water:2,fire:3,wind:4};return V2_RULE_TABLES.element[ids[attacker]??0][ids[defender]??0];}
// Source uses doubled odd-row X (equivalently 2*q+r), not rounded hex directions.
export function originalFacingBonus(origin,target){let dx=2*(origin.q-target.q)+origin.r-target.r,dy=origin.r-target.r,facing=((target.facing??0)+3)%6;if(facing>=3){facing-=3;dx=-dx;dy=-dy;}
  if(facing===0)return dx>=3*dy&&dx>=-3*dy?8:dx>=0?7:dx>=3*dy||dx>=-3*dy?5:4;
  if(facing===1)return dx>=0&&dx<=3*dy?8:dx>=-3*dy?7:dx>=0||dx<=3*dy?5:4;
  return dx>=-3*dy&&dx<=0?8:dx<=3*dy?7:dx>=-3*dy||dx<=0?5:4;
}
export function originalDamage(score,terrainPercent=100){const table=V2_RULE_TABLES.damage,index=Math.max(0,Math.min(table.length-1,Math.trunc(score)));return Math.min(10,Math.floor((Math.trunc(table[index]*terrainPercent/100)+127)/256));}
export function originalHealing(magicAttack,power){const table=V2_RULE_TABLES.damage,index=Math.max(0,Math.min(table.length-1,Math.trunc(magicAttack+power+5)));return Math.ceil((table[index]+127)/256);}
export function originalStatusMinutes(magicAttack,power){const table=V2_RULE_TABLES.statusMinutes;return table[Math.max(0,Math.min(table.length-1,Math.trunc(magicAttack+power)))];}
// Decoded positional component at 0x44660e..0x446641, used only to break web AI ties.
// The remaining original search weights and pruning are not reconstructed.
export function originalPositionPreference(tile){return ruleHeight(tile)*8+(100-originalTerrainPercent(tile))*10;}
// 0x4100f8 / 0x41090b: two cells are checked when a ray lies on their shared edge.
export function originalRayCells(a,b){const x=2*a.q+a.r,y=a.r,dx=2*(b.q-a.q)+b.r-a.r,dy=b.r-a.r;if(!dx&&!dy)return [];
  const d=dy>0?(dx>dy?3:dx< -dy?5:4):(dx<dy?0:dx> -dy?2:1),e=(d+2)%6,vx=V2_RULE_TABLES.rayX,vy=V2_RULE_TABLES.rayY;
  const det=vx[d]*vy[e]-vy[d]*vx[e],n=Math.trunc((dx*vy[e]-dy*vx[e])/det),m=Math.trunc((dy*vx[d]-dx*vy[d])/det),cells=[];
  for(let i=1;i<n;i++){const product=m*i,edge=(2*product)%n===0&&product%n!==0,steps=edge?[Math.trunc(product/n),Math.trunc(product/n)+1]:[Math.trunc((product+Math.trunc(n/2))/n)];for(const j of steps){const ry=y+i*vy[d]+j*vy[e],rx=x+i*vx[d]+j*vx[e];cells.push({q:(rx-ry)/2,r:ry,i,n});}}return cells;
}
// 0x410499: ballistic coefficients, preserving the executable's stored float32 intermediates.
export function originalArcHeight(a,b,ah,bh,speed){const f=Math.fround,g=f(1.2),dx=(2*(b.q-a.q)+b.r-a.r)*24,dy=Math.trunc((b.r-a.r)*24*f(1.73205)),dz=(bh-ah)*12,L=dx*dx+dy*dy;
  if(!L)return ()=>ah+2;
  let v2=f(speed*speed),total=f(dz*dz+L),term=f(v2-dz*g),disc=term*term-f(1.44)*total;
  if(disc<0){v2=f(f(dz*g)+f(Math.sqrt(total))*g);term=f(v2-dz*g);disc=0;}
  const vx2=f((f(Math.sqrt(disc))+term)*f(L)/(2*total));let vz=f(Math.sqrt(Math.max(0,v2-vx2)));if(L<(-2*dz)*v2/g)vz=-vz;
  return (i,n)=>{const t2=f(L*i*i/(n*n*vx2)),t=f(Math.sqrt(t2));return Math.trunc((Math.trunc(f(-.6)*t2+vz*t)+ah*12)/12)+2;};
}
export function originalInRange(a,b,action,tileAt,unitAt=()=>null,{area=false}={}){const ah=ruleHeight(tileAt(a)),bh=ruleHeight(tileAt(b)),dist=(Math.abs(a.q-b.q)+Math.abs(a.r-b.r)+Math.abs(a.q+a.r-b.q-b.r))/2;
  const trajectory=action.trajectory??0,penalty=Math.trunc((trajectory===1?bh-ah:Math.abs(bh-ah))/2);
  if(dist+penalty>action.range)return false;if(dist<2||trajectory===0||trajectory===3)return true;
  if(![1,2].includes(trajectory))return false;
  const arcHeight=trajectory===1?originalArcHeight(a,b,ah,bh,action.arc):null;
  for(const p of originalRayCells(a,b)){const t=tileAt(p),code=ruleTerrain(t);if(code===16)return false;if(code===11)continue;const h=arcHeight?arcHeight(p.i,p.n):Math.trunc((ah*(p.n-p.i)+bh*p.i)/p.n)+(area?1:2);if(ruleHeight(t)>h)return false;if(!area&&ruleHeight(t)+4>h&&unitAt(p))return false;}
  return true;
}
export function timePeriod(minutes){const hour=Math.floor(((minutes%1440)+1440)%1440/60);return hour<4||hour>=20?'night':hour<8?'morning':hour<16?'day':'evening';}
export function periodBrightness(minutes){return ({night:0,morning:.5,day:1,evening:.5})[timePeriod(minutes)];}
export function playerLevel(exp){return Math.min(40,1+Math.floor(Math.max(0,Number(exp)||0)/100));}
export const V2_RULES={satThresholds:[0,100,250],dayBonus:2,nightPenalty:2,freezeMinutes:120,maxStep:1};
