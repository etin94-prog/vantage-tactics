// Measured OA tables: https://purose.net/~kijima/vm/m_oa.htm
// Other durations use an interpolation, pending V2 frame-by-frame confirmation.
const oaWait=[56,53,50,47,44,41,39,36,34,32,30,28,26,25,23,22,21,19,18,17,16];
const oaAction=[85,79,75,70,66,62,58,54,51,48,45,42,40,37,35,33,31,29,27,25,24];
const oaMoveAction=[113,106,99,93,88,82,77,72,68,64,60,56,53,50,47,44,41,39,36,34,32];
export function actionMinutes(speed,extra=0,moved=false){const s=Math.max(0,Math.round(speed)),base=30+extra+(moved?15:0),table=base===30?oaWait:base===45?oaAction:base===60?oaMoveAction:null;return Math.max(1,table?.[s]??Math.round(base*Math.pow(.939, s-10)));}
export function timePeriod(minutes){const hour=Math.floor(((minutes%1440)+1440)%1440/60);return hour<4||hour>=20?'night':hour<8?'morning':hour<16?'day':'evening';}
export function periodBrightness(minutes){return ({night:0,morning:.5,day:1,evening:.5})[timePeriod(minutes)];}
export function playerLevel(exp){return Math.min(40,1+Math.floor(Math.max(0,Number(exp)||0)/100));}
export const V2_RULES={satThresholds:[0,100,250],dayBonus:2,nightPenalty:2,freezeMinutes:120,maxStep:2};
