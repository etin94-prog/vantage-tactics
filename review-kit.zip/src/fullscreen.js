// Fullscreen must be requested directly from a user gesture.
export function initFullscreen(doc=document,win=window) {
  const button=doc.querySelector('#fullscreen-btn'),help=doc.querySelector('#fullscreen-help');
  const standalone=win.matchMedia('(display-mode: standalone)');
  const embeddedApp=()=>standalone.matches||win.navigator.standalone===true;
  const current=()=>doc.fullscreenElement||doc.webkitFullscreenElement;
  function sync(){
    button.hidden=embeddedApp();
    const active=!!current();
    button.setAttribute('aria-pressed',String(active));
    button.setAttribute('aria-label',active?'전체화면 종료':'전체화면으로 플레이');
    button.title=active?'전체화면 종료':'전체화면으로 플레이';
    button.textContent=active?'⛶ 닫기':'⛶';
  }
  function showHelp(){if(!help.open)help.showModal();}
  button.onclick=async()=>{
    button.disabled=true;
    try{
      if(current()){
        const exit=doc.exitFullscreen||doc.webkitExitFullscreen;
        if(exit)await exit.call(doc);
      }else{
        const root=doc.documentElement;
        if(root.requestFullscreen&&doc.fullscreenEnabled!==false)await root.requestFullscreen({navigationUI:'hide'});
        else if(root.webkitRequestFullscreen&&doc.webkitFullscreenEnabled!==false)await root.webkitRequestFullscreen();
        else showHelp();
      }
    }catch{showHelp();}
    finally{button.disabled=false;sync();}
  };
  doc.querySelector('#fullscreen-help-close').onclick=()=>help.close();
  doc.addEventListener('fullscreenchange',sync);
  doc.addEventListener('webkitfullscreenchange',sync);
  standalone.addEventListener('change',sync);
  sync();
}
