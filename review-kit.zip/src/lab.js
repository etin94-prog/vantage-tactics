import { Battle } from './engine.js';
import { MASTERS, SUMMONS } from './data.js';
import { generateStage } from './maps.js';
import { key } from './hex.js';
import { Renderer } from './renderer.js';
import { LAB_CASES, LabSession, createLabBattle, replayBundle, runLabSuite, stateHash, checkInvariants } from './lab-core.js';
import { LAB_BUILD } from './lab-build.js';

const lab$=s=>document.querySelector(s);
let session,mode='move',lastReport=null,selectedTile=null,busy=false;
const labRenderer=new Renderer(lab$('#canvas'),{click:tile=>{if(tile){selectedTile=tile;lab$('#q').value=tile.q;lab$('#r').value=tile.r;execute();}},hover:tile=>{if(tile)inspect(tile);}});
function options(select,rows){select.replaceChildren(...rows.map(([value,text])=>{const o=document.createElement('option');o.value=value;o.textContent=text;return o;}));}
options(lab$('#scenario'),LAB_CASES);options(lab$('#stage'),Array.from({length:30},(_,i)=>[i,`${i+1}. ${generateStage(i).name}`]));options(lab$('#master'),MASTERS.map(m=>[m.id,m.name]));lab$('#master').value='adol';options(lab$('#summon'),SUMMONS.map(u=>[u.id,`${u.name} · MP${u.cost}`]));
lab$('#build').textContent=`소스 빌드 ${LAB_BUILD}`;
function notice(text){lab$('#status').textContent=text;}
function guard(fn){try{return fn();}catch(e){notice('오류: '+e.message);return false;}}
function inspect(tile){const b=session.battle,u=b.at(tile);lab$('#inspect').textContent=JSON.stringify({tile:{q:tile.q,r:tile.r,terrain:tile.terrain,height:tile.elevation,sourceX:tile.sourceX,sourceY:tile.sourceY},unit:u?{id:u.id,name:u.name,team:u.team,hp:u.hp,level:u.level,sat:u.sat,facing:u.facing,nextTime:u.nextTime,attack:b.stat(u,'attack'),defense:b.stat(u,'defense'),magicAttack:b.stat(u,'magicAttack'),statuses:u.statuses}:null,damagePreview:u&&b.canAttack(b.active,u)?b.damage(b.active,u,b.active.magicAttackBasic):null},null,2);}
function refresh(){
  const b=session.battle,u=b.active;lab$('#summary').textContent=`${session.label} / ${b.stage.name} · T${b.turn} / ${b.time}분 · ${u?.team===0?'아군':'적군'} ${u?.name||'종료'} · MP ${b.mana.join(' / ')} · 상태 ${stateHash(b)}${b.winner!==null?' · 승리 팀 '+b.winner:''}`;
  const previous=lab$('#spell').value;options(lab$('#spell'),b.availableSpells().map(s=>[s.id,`${s.name} · MP${s.cost} / 범위${s.range}`]));if(b.availableSpells().some(s=>s.id===previous))lab$('#spell').value=previous;
  if(u)lab$('#facing').value=u.facing;lab$('#undo').disabled=!b.canUndoMove();
  labRenderer.mode=mode;labRenderer.highlight=new Set();labRenderer.targets=new Set();
  if(u&&b.winner===null){if(mode==='move'&&!b.moved)labRenderer.highlight=new Set(b.reachable().dist.keys());if(mode==='attack')labRenderer.targets=new Set(b.living.filter(t=>b.canAttack(u,t)).map(key));if(mode==='summon'&&b.canSummon(lab$('#summon').value))labRenderer.highlight=new Set(b.summonTiles(u,lab$('#summon').value).map(key));if(mode==='cast')labRenderer.targets=new Set(b.spellTargets(u,lab$('#spell').value).map(key));}
  labRenderer.consume(b.events.splice(0));lab$('#trace').replaceChildren(...session.steps.slice(-40).map((s,i)=>{const li=document.createElement('li');li.textContent=`${Math.max(0,session.steps.length-40)+i+1}. ${JSON.stringify(s.action)} ${s.error?'오류: '+s.error:s.accepted?'실행':'거절'} → ${s.postHash}`;return li;}));
  lab$('#hint').textContent=`현재 명령: ${{move:'이동',attack:'공격',summon:'소환',cast:'마법'}[mode]} · 타일을 누르거나 q/r 좌표로 실행하세요. 적 턴도 수동 조작합니다.`;
  document.querySelectorAll('[data-mode]').forEach(btn=>btn.classList.toggle('active',btn.dataset.mode===mode));if(u)inspect(selectedTile||b.tiles.get(key(u)));
}
function adopt(next){session=next;selectedTile=null;mode='move';labRenderer.setBattle(session.battle);refresh();}
function step(action){if(busy)return;try{const accepted=session.act(action);if(action.type==='undo')labRenderer.effects=[];refresh();notice(accepted?'행동을 기록했습니다.':'허용되지 않는 행동입니다. 거절 결과도 재현 기록에 남습니다.');return true;}catch(e){refresh();notice('오류를 기록했습니다: '+e.message+' · 재현 JSON을 내보내세요.');return false;}}
function execute(){const q=Number(lab$('#q').value),r=Number(lab$('#r').value);if(mode==='attack')step({type:'attack',target:session.battle.at({q,r})?.id??-1});else step({type:mode,q,r,...(mode==='summon'?{unit:lab$('#summon').value}:mode==='cast'?{spell:lab$('#spell').value}:{})});}
lab$('#start').onclick=()=>guard(()=>{adopt(new LabSession(createLabBattle({scenario:lab$('#scenario').value,stage:Number(lab$('#stage').value),master:lab$('#master').value,level:Number(lab$('#level').value)}),LAB_BUILD,lab$('#scenario').value));notice('새 실험을 시작했습니다.');});
lab$('#reset').onclick=()=>guard(()=>{adopt(new LabSession(Battle.restore(structuredClone(session.initial)),LAB_BUILD,session.label));notice('시작 조건으로 돌아왔습니다.');});
document.querySelectorAll('[data-mode]').forEach(btn=>btn.onclick=()=>{mode=btn.dataset.mode;refresh();});
lab$('#execute').onclick=execute;lab$('#undo').onclick=()=>step({type:'undo'});lab$('#wait').onclick=()=>step({type:'wait'});lab$('#facing').onchange=()=>step({type:'facing',facing:Number(lab$('#facing').value)});lab$('#summon').onchange=()=>{mode='summon';refresh();};lab$('#spell').onchange=()=>{mode='cast';refresh();};
lab$('#ai').onclick=()=>step({type:'ai'});lab$('#ai10').onclick=()=>{for(let i=0;i<10&&session.battle.winner===null;i++)if(!step({type:'ai'}))break;};lab$('#fit').onclick=()=>labRenderer.fit();lab$('#zoom').onclick=()=>labRenderer.zoom(1.3);
function review(){return Object.fromEntries(['reviewer','category','severity','expected','actual','evidence'].map(id=>[id,lab$('#'+id).value]));}
function download(name,text,type='application/json'){const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
lab$('#export').onclick=()=>download(`vantage-repro-${stateHash(session.battle)}.json`,JSON.stringify(session.bundle(review()),null,2));
lab$('#markdown').onclick=()=>{const r=review();download('vantage-review.md',`# Vantage Tactics 리뷰\n\n빌드: ${LAB_BUILD}\n실험: ${session.label}\n상태: ${stateHash(session.battle)}\n검토자: ${r.reviewer}\n분류: ${r.category}\n심각도: ${r.severity}\n\n## 기대 결과\n${r.expected}\n\n## 실제 결과\n${r.actual}\n\n## 근거\n${r.evidence}\n\n## 재현 행동\n\n\`\`\`json\n${JSON.stringify(session.steps.map(s=>s.action),null,2)}\n\`\`\`\n\n동일 상태의 재현 JSON을 함께 첨부하세요. 임시 규칙을 원작 확정값으로 단정하지 마세요.\n`,'text/markdown');};
lab$('#import').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>8_000_000)throw new Error('8MB 이하 JSON만 지원합니다.');const result=replayBundle(JSON.parse(await file.text()),LAB_BUILD);if(result.reproducedErrors.length)throw new Error('기록된 오류 재현 성공: '+result.reproducedErrors.map(e=>e.step+'행동 '+e.error).join(' / '));adopt(result.session);for(const id of ['reviewer','expected','actual','evidence'])lab$('#'+id).value=String(result.review[id]||'').slice(0,4000);for(const id of ['category','severity'])if([...lab$('#'+id).options].some(o=>o.value===result.review[id]))lab$('#'+id).value=result.review[id];notice(result.buildMatch?'전체 행동과 최종 상태가 일치합니다.':'행동 재현 성공 · 소스 빌드가 다릅니다. 원래 빌드와 결과를 대조하세요.');}catch(error){notice('불러오기 실패: '+error.message);}e.target.value='';};
lab$('#suite').onclick=async()=>{if(busy)return;busy=true;const controls=[...document.querySelectorAll('button,input,select,textarea')],disabled=controls.map(c=>c.disabled);controls.forEach(c=>c.disabled=true);notice('35개 실험을 실행합니다. 수 초 동안 기다려 주세요.');await new Promise(r=>setTimeout(r,30));try{lastReport=runLabSuite(LAB_BUILD);lab$('#suite-result').textContent=`통과 ${lastReport.passed} / 실패 ${lastReport.failed}\n`+lastReport.results.map(r=>`${r.status==='pass'?'✓':'✗'} ${r.name}${r.error?' · '+r.error:''}`).join('\n');notice(lastReport.scope);}catch(e){notice(e.message);}finally{busy=false;controls.forEach((c,i)=>c.disabled=disabled[i]);lab$('#suite-export').disabled=!lastReport;}};
lab$('#suite-export').onclick=()=>download('vantage-lab-results.json',JSON.stringify(lastReport,null,2));
adopt(new LabSession(createLabBattle(),LAB_BUILD));notice('실험실 준비 완료 · 일반 게임 저장은 변경하지 않습니다.');
