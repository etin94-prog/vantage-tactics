import { planPresentation, presentationRate, sampleMove, placeLabel } from './presentation.js';
import { eventVisible } from './event-visibility.js';
import { ELEMENTS, TERRAIN } from './data.js';
import { REFERENCE_MEDIA } from './reference-media.js';
import { hexToPixel, key, direction } from './hex.js';
const TAU=Math.PI*2;
const images=new Map(),portraits=new Map();
export function referenceSprite(u){return u.sprite?null:REFERENCE_MEDIA.sprites[u.type||u.id]?.[u.team===1?1:0];}
export function referenceFrame(u,state,frame){const direction=u.facing===undefined?5:(u.facing+3)%6,phase=state==='move'?[0,1,2,1][frame%4]:state==='attack'||state==='cast'?Math.min(2,Math.floor(frame/2)):0;return (state==='attack'?18:state==='cast'?36:0)+direction*3+phase;}
export function getImage(src){if(!src)return null;if(!images.has(src)){const img=new Image();img.onload=()=>window.dispatchEvent(new Event('sprite-ready'));img.src=src;images.set(src,img);}const img=images.get(src);return img.complete&&img.naturalWidth?img:null;}
/** Original pixel silhouettes, painted on an integer grid. Sprite replacement is data-driven. */
export function paintSprite(ctx,u,x,y,scale=2,animation={state:'idle',frame:0}){
  const state=animation.state||'idle',frame=animation.frame||0;
  const native=getImage(referenceSprite(u));
  if(native){const f=referenceFrame(u,state,frame),factor=scale*.8;ctx.save();ctx.imageSmoothingEnabled=false;if(state==='down')ctx.globalAlpha*=Math.max(0,1-frame/4);ctx.drawImage(native,f%6*96,Math.floor(f/6)*96,96,96,x-48*factor,y-84*factor,96*factor,96*factor);ctx.restore();return;}
  const custom=getImage(u.sprite);if(custom){const sheet=u.animation;if(sheet){const row=['idle','move','attack','cast','hit','down'].indexOf(state),count=[4,6,8,6,2,4][Math.max(0,row)],sx=(frame%count)*sheet.frameWidth,sy=Math.max(0,row)*sheet.frameHeight;ctx.drawImage(custom,sx,sy,sheet.frameWidth,sheet.frameHeight,x-12*scale,y-32*scale,24*scale,32*scale);}else{const fit=Math.min(32*scale/custom.height,32*scale/custom.width),h=custom.height*fit,w=custom.width*fit;ctx.drawImage(custom,x-w/2,y-h,w,h);}return;}
  if(state==='move')y-=Math.abs(Math.sin(frame*Math.PI/3))*2*scale;
  if(state==='attack')x+=Math.sin(frame/7*Math.PI)*5*scale;
  if(state==='cast')y-=Math.sin(frame/5*Math.PI)*2*scale;
  if(state==='down')ctx.globalAlpha*=Math.max(0,1-frame/4);
  ctx.save();ctx.translate(Math.round(x-12*scale),Math.round(y-30*scale));ctx.scale(scale,scale);const ink='#25332b',shade='#3d4b45',skin='#e8c9a0',hair=u.team===1?'#b4bec9':'#bd7552',color=u.color||ELEMENTS[u.element]?.color||'#a4be94',light='#e7e7cf';
  const p=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(x,y,w,h);};const body=(c=color)=>{p(7,13,10,12,ink);p(8,14,8,10,c);p(8,24,3,5,shade);p(13,24,3,5,shade);p(7,28,5,2,ink);p(13,28,5,2,ink);};const head=()=>{p(8,4,8,9,ink);p(9,5,6,7,skin);p(9,4,6,3,hair);p(14,8,1,2,ink);};
  switch(u.art){
    case 'golem':p(5,8,14,19,ink);p(6,9,12,16,color);p(7,5,10,9,shade);p(8,5,8,7,color);p(8,8,2,2,light);p(14,8,2,2,light);p(2,13,4,12,shade);p(18,13,4,12,shade);p(3,13,3,9,color);p(18,13,3,9,color);p(5,25,6,5,shade);p(13,25,6,5,shade);p(8,14,8,2,'#d3d4a0');p(9,18,5,4,'#7b8e5c');break;
    case 'slime':p(5,15,14,13,ink);p(3,20,18,7,ink);p(6,14,12,12,color);p(4,20,16,6,color);p(7,12,6,4,color);p(7,15,3,3,light);p(8,21,2,2,ink);p(15,21,2,2,ink);p(11,24,3,1,'#d5eff0');p(6,28,13,2,shade);break;
    case 'flame':p(9,3,3,9,'#eab578');p(12,8,4,7,'#eab578');p(6,9,5,14,color);p(4,16,16,10,color);p(7,14,10,14,'#f0bf79');p(9,19,6,9,'#fae6a1');p(7,20,2,2,ink);p(15,20,2,2,ink);p(8,28,9,2,'#9e5a3e');break;
    case 'spirit':p(9,5,7,5,color);p(7,9,11,10,color);p(5,15,15,5,color);p(8,20,8,4,color);p(10,24,4,3,color);p(11,27,2,2,light);p(8,11,2,2,ink);p(14,11,2,2,ink);p(10,7,4,2,light);p(2,14,3,3,color);p(20,12,2,3,color);break;
    case 'dragon':p(2,8,3,13,shade);p(4,10,3,12,color);p(6,14,4,8,color);p(20,7,3,13,shade);p(17,10,4,12,color);p(14,14,5,11,color);p(7,19,11,9,shade);p(8,17,8,10,color);p(11,7,7,11,color);p(13,6,2,3,light);p(15,10,5,4,color);p(16,10,2,2,ink);p(9,27,3,3,ink);p(16,27,3,3,ink);p(3,24,5,3,color);p(2,21,2,4,color);p(11,19,3,7,'#d4c5a0');break;
    case 'bird':p(1,10,3,5,shade);p(3,12,5,5,color);p(6,15,5,5,color);p(19,10,4,5,shade);p(16,12,5,6,color);p(9,13,7,13,color);p(10,8,7,9,color);p(14,11,2,2,ink);p(17,13,3,2,'#e3bf76');p(10,26,2,3,'#d6b071');p(14,26,2,3,'#d6b071');p(10,18,3,6,light);break;
    case 'beast':p(5,11,14,14,ink);p(6,12,12,12,color);p(7,5,11,9,color);p(7,3,3,5,color);p(15,3,3,5,color);p(13,9,2,2,ink);p(15,11,5,3,skin);p(3,17,4,10,color);p(17,16,4,11,color);p(3,25,5,2,light);p(18,25,4,2,light);p(7,24,4,6,shade);p(14,24,4,6,shade);p(9,15,5,7,skin);break;
    case 'mage':p(5,15,14,14,ink);p(7,13,10,15,color);p(5,26,14,3,color);head();p(7,3,10,5,color);p(10,0,5,5,color);p(5,7,14,2,color);p(9,11,6,5,'#ddd7be');p(11,16,2,12,'#d0b680');p(4,16,4,5,color);p(17,15,3,6,color);p(20,6,2,23,'#b19a6a');p(19,3,4,5,'#dac58d');p(20,2,2,3,'#e6ecd3');break;
    case 'rogue':body();p(7,4,11,10,ink);p(8,3,9,9,color);p(10,7,6,5,skin);p(8,10,9,4,color);p(14,7,1,2,ink);p(5,14,4,10,color);p(16,14,4,8,color);p(3,18,2,8,'#cad0c9');p(20,17,2,8,'#cad0c9');p(8,20,9,2,'#a89b79');break;
    case 'knight':body();p(5,12,14,6,color);p(7,4,10,10,shade);p(8,3,8,10,color);p(8,8,8,2,ink);p(12,3,2,10,light);p(2,14,5,13,ink);p(3,15,4,10,color);p(4,16,1,8,light);p(19,4,2,20,'#c7d4cd');p(17,22,6,2,'#d6bb7c');p(19,24,2,4,'#a89672');p(8,17,8,2,light);break;
    case 'ranger':body();head();p(7,3,10,4,color);p(5,6,14,2,color);p(8,0,2,4,'#d9bf8a');p(5,14,4,10,color);p(15,15,5,5,skin);p(20,9,2,17,'#af8d55');p(22,12,1,11,'#af8d55');p(18,7,2,3,'#af8d55');p(18,26,2,2,'#af8d55');p(18,10,1,16,'#d8d0b8');p(7,21,10,2,'#baa87c');break;
    default:body();head();p(5,13,4,8,color);p(16,13,4,9,color);p(5,21,3,3,skin);p(17,21,3,3,skin);p(20,8,2,15,'#d6dfd8');p(18,22,6,2,'#d6bb7c');p(20,24,2,4,'#90764f');p(8,21,9,2,'#bda675');p(8,14,2,6,'#c5d6d3');
  }
  ctx.restore();
}
export function portrait(u){
  const native=referenceSprite(u),k=JSON.stringify([u.type||u.id,u.art,u.color,u.sprite,u.animation,u.team]);
  if(u.sprite&&!u.animation)return u.sprite;
  if(!portraits.has(k)){const c=document.createElement('canvas');c.width=80;c.height=88;const ctx=c.getContext('2d');ctx.imageSmoothingEnabled=false;paintSprite(ctx,{...u,facing:undefined},40,82,2);const result=c.toDataURL();if((u.sprite&&getImage(u.sprite))||(!u.sprite&&(!native||getImage(native))))portraits.set(k,result);return result;}
  return portraits.get(k);
}
// Animation timing does not alter battle calculations or OA.
export function combatPresentation(events,battle,now,rate=1){return planPresentation(events,battle,now,rate);}
export class Renderer {
  constructor(canvas,callbacks){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.callbacks=callbacks;this.width=0;this.height=0;this.scale=1;this.pan={x:0,y:0};this.effects=[];this.playbackUntil=0;this.speed=1;this.followId=null;this.hover=null;this.focus=null;this.battle=null;this.mode='move';this.highlight=new Set();this.targets=new Set();this.pointers=new Map();this.reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;this.lastFrame=0;this.bind();new ResizeObserver(()=>this.resize()).observe(canvas);this.loop=this.loop.bind(this);requestAnimationFrame(this.loop);}
  setBattle(b){this.battle=b;this.effects=[];this.playbackUntil=0;this.followId=null;this.manualCamera=false;this.hover=null;this.focus=null;this.fit();if(matchMedia('(max-width:960px)').matches&&b.active){this.scale=Math.max(this.scale,.85);this.focusUnit(b.active,true);}}
  setSpeed(value){this.speed=presentationRate(value);}
  followActor(u,reset=false){if(reset)this.manualCamera=false;if(!this.manualCamera)this.followId=u&&this.battle.visibleUnit(u)?u.id:null;}
  motion(u,now){
    const move=this.effects.find(e=>e.type==='move'&&e.id===u.id&&now<e.start+e.duration);
    return move?sampleMove(move,now,p=>this.point(this.battle.tiles.get(key(p))),this.reduced):{...this.point(this.battle.tiles.get(key(u))),cell:u,moving:false};
  }
  screenMotion(u,now){const p=this.motion(u,now);return {...p,x:p.x*this.scale+this.pan.x,y:p.y*this.scale+this.pan.y};}
  trackCamera(now,elapsed){
    const u=this.battle.units.find(u=>u.id===this.followId);if(!u||!this.battle.visibleUnit(u))return;
    const p=this.motion(u,now);if(!this.battle.visible(p.cell))return;
    const factor=this.reduced?1:1-Math.exp(-Math.min(elapsed,100)/100);
    this.pan.x+=(this.width/2-p.x*this.scale-this.pan.x)*factor;
    this.pan.y+=(Math.max(100,(this.height-50)/2)-p.y*this.scale-this.pan.y)*factor;
  }
  focusUnit(u,force=false){if(!u)return;const t=this.battle.tiles.get(key(u)),s=this.screen(t);if(force||s.x<65||s.x>this.width-65||s.y<100||s.y>this.height-160){const p=this.point(t);this.pan={x:this.width/2-p.x*this.scale,y:Math.max(100,(this.height-50)/2)-p.y*this.scale};}}
  resize(){const previousWidth=this.width,previousHeight=this.height;const rect=this.canvas.getBoundingClientRect();this.width=rect.width;this.height=rect.height;const dpr=Math.min(2,devicePixelRatio||1);this.canvas.width=Math.round(rect.width*dpr);this.canvas.height=Math.round(rect.height*dpr);this.dpr=dpr;if(previousWidth>0&&Math.abs(previousWidth-this.width)<1){this.pan.y+=(this.height-previousHeight)/2;return;}this.fit();if(matchMedia('(max-width:960px)').matches&&this.battle?.active){this.scale=Math.max(this.scale,.85);this.focusUnit(this.battle.active,true);}}
  point(t){const p=hexToPixel(t,38);return {x:p.x,y:p.y*.74-t.elevation*10};}
  fit(){if(!this.battle||!this.width)return;const ps=this.battle.stage.tiles.filter(t=>t.terrain!=='void').map(t=>this.point(t)),xs=ps.map(p=>p.x),ys=ps.map(p=>p.y),minX=Math.min(...xs)-40,maxX=Math.max(...xs)+40,minY=Math.min(...ys)-75,maxY=Math.max(...ys)+45;this.scale=Math.min((this.width-32)/(maxX-minX),(this.height-165)/(maxY-minY),1.65);this.baseScale=this.scale;this.pan={x:this.width/2-(minX+maxX)/2*this.scale,y:(this.height-85)/2-(minY+maxY)/2*this.scale};}
  zoom(factor,at={x:this.width/2,y:this.height/2}){this.followId=null;this.manualCamera=true;const s=Math.min(2.8,Math.max(this.baseScale*.65,this.scale*factor)),ratio=s/this.scale;this.pan.x=at.x-(at.x-this.pan.x)*ratio;this.pan.y=at.y-(at.y-this.pan.y)*ratio;this.scale=s;}
  screen(t){const p=this.point(t);return {x:p.x*this.scale+this.pan.x,y:p.y*this.scale+this.pan.y};}
  pick(x,y){if(!this.battle)return null;const wx=(x-this.pan.x)/this.scale,wy=(y-this.pan.y)/this.scale;const tiles=this.battle.stage.tiles.filter(t=>t.terrain!=='void').sort((a,b)=>b.r-a.r);return tiles.find(t=>{const p=this.point(t),dx=Math.abs(wx-p.x),dy=Math.abs(wy-p.y)/.74;return dx<=32.9&&dy<=38&&Math.sqrt(3)*dy+dx<=Math.sqrt(3)*38;})||null;}
  bind(){const c=this.canvas;const point=e=>{const r=c.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};};
    c.addEventListener('pointerdown',e=>{this.followId=null;c.setPointerCapture(e.pointerId);this.pointers.set(e.pointerId,point(e));this.drag={...point(e),distance:0,panned:false};this.pinching=this.pointers.size>1;if(this.pinching)this.drag.distance=99;});
    c.addEventListener('pointermove',e=>{const p=point(e);if(this.pointers.has(e.pointerId)){const previous=this.pointers.get(e.pointerId);if(this.pointers.size===2){const other=[...this.pointers.entries()].find(([id])=>id!==e.pointerId)?.[1];if(other){const before=Math.hypot(previous.x-other.x,previous.y-other.y),after=Math.hypot(p.x-other.x,p.y-other.y);if(before>2)this.zoom(after/before,{x:(p.x+other.x)/2,y:(p.y+other.y)/2});}}else if(this.drag){const dx=p.x-previous.x,dy=p.y-previous.y;this.drag.distance+=Math.hypot(dx,dy);if(this.drag.distance>5){this.manualCamera=true;this.drag.panned=true;this.pan.x+=dx;this.pan.y+=dy;}}this.pointers.set(e.pointerId,p);}else{this.hover=this.pick(p.x,p.y);this.callbacks.hover?.(this.hover,p);}});
    c.addEventListener('pointerup',e=>{const p=point(e);if(this.drag&&!this.drag.panned&&this.drag.distance<=5&&!this.pinching){this.focus=this.pick(p.x,p.y);this.callbacks.click?.(this.focus);}this.pointers.delete(e.pointerId);if(!this.pointers.size){this.drag=null;this.pinching=false;}});
    c.addEventListener('pointercancel',e=>{this.pointers.delete(e.pointerId);this.drag=null;});c.addEventListener('pointerleave',()=>{this.hover=null;this.callbacks.hover?.(null);});
    c.addEventListener('wheel',e=>{e.preventDefault();this.zoom(Math.exp(-e.deltaY*.001),point(e));},{passive:false});
    c.addEventListener('keydown',e=>{const directions={ArrowRight:[1,0],ArrowLeft:[-1,0],ArrowUp:[0,-1],ArrowDown:[0,1]};if(directions[e.key]){e.preventDefault();const p=this.focus||this.battle?.active;if(!p)return;const [dq,dr]=directions[e.key],t=this.battle.tiles.get(`${p.q+dq},${p.r+dr}`);if(t){this.focus=t;this.hover=t;this.callbacks.hover?.(t,this.screen(t));}}if(e.key==='Enter'&&this.focus){e.preventDefault();this.callbacks.click?.(this.focus);}});
  }
  consume(events){
    const now=performance.now(),visible=events.filter(e=>e.type!=='turn'&&eventVisible(this.battle,e));
    const mover=visible.find(e=>['move','attack','spell'].includes(e.type));if(mover)this.followActor(this.battle.units.find(u=>u.id===mover.id));
    const planned=combatPresentation(visible,this.battle,now,this.speed);this.effects.push(...planned.map(e=>({...e,batchStart:now})));
    if(planned.length)this.playbackUntil=Math.max(this.playbackUntil||0,...planned.map(e=>e.start+(['damage','heal'].includes(e.type)?500/this.speed:e.duration)));
  }
  isPlaying(now=performance.now()){return now<(this.playbackUntil||0)||this.effects.some(e=>!e.presented||(['move','down','attack','spell','summon'].includes(e.type)&&this.lastFrame<e.start+e.duration));}
  preserveFrames(now){
    let maxShift=0;
    for(const e of this.effects){
      const anchor=Math.max(this.lastFrame,e.batchStart??this.lastFrame),lost=now-anchor-100;
      if(lost>80&&e.start+e.duration>this.lastFrame){e.start+=lost;maxShift=Math.max(maxShift,lost);}
    }
    if(maxShift&&this.playbackUntil>this.lastFrame)this.playbackUntil+=maxShift;
  }
  displayHp(u,now=performance.now()){const pending=this.effects.find(e=>e.type==='damage'&&e.id===u.id&&e.start>now);return pending?.hpBefore??u.hp;}
  hex(x,y,size=37,ratio=.74){const c=this.ctx;c.beginPath();for(let i=0;i<6;i++){const a=(i*60-30)*Math.PI/180,px=x+Math.cos(a)*size,py=y+Math.sin(a)*size*ratio;i?c.lineTo(px,py):c.moveTo(px,py);}c.closePath();}
  tile(t,now){const c=this.ctx,p=this.point(t),terrain=TERRAIN[t.terrain],h=12+t.elevation*5;this.hex(p.x,p.y+h);c.fillStyle=terrain.side;c.fill();c.strokeStyle='#24372c';c.lineWidth=.8;c.stroke();this.hex(p.x,p.y);c.fillStyle=terrain.color;c.fill();c.strokeStyle='#d2dba51c';c.lineWidth=1;c.stroke();
    const seed=(t.q*31+t.r*77+999);for(let j=0;j<6;j++){const dx=((seed*(j+3)*19)%47)-23,dy=((seed*(j+4)*13)%31)-15;c.fillStyle=t.terrain==='water'?'#b9e1da55':'#cdd5a333';c.fillRect(p.x+dx,p.y+dy,t.terrain==='water'?9:2,1.5);}
    if(t.terrain==='water'){c.strokeStyle='#afd9cf33';c.lineWidth=1;c.beginPath();c.moveTo(p.x-13,p.y+3);c.lineTo(p.x+12,p.y+3);c.stroke();}
    if(this.highlight.has(key(t))){this.hex(p.x,p.y,35);c.fillStyle=this.mode==='summon'?'#bcafff42':this.mode==='spell'||this.mode==='attack'?'#f39b7940':'#8bceeb38';c.fill();c.strokeStyle=this.mode==='summon'?'#d7c5f2aa':this.mode==='attack'||this.mode==='spell'?'#e8a58aaa':'#9bd5efbb';c.lineWidth=1.5;c.stroke();}
    if(this.rangeArea?.has(key(t))){this.hex(p.x,p.y,32);c.strokeStyle=this.rangeKind==='magic'?'#d8b7ff':'#ffb18e';c.fillStyle=this.rangeKind==='magic'?'#af7bf51c':'#ff936315';c.fill();c.lineWidth=1.8;c.setLineDash([4,3]);c.stroke();c.setLineDash([]);}
    if(this.effectArea?.has(key(t))){this.hex(p.x,p.y,33);c.fillStyle='#ffd45a66';c.fill();c.strokeStyle='#ffe480';c.lineWidth=2.5;c.stroke();c.save();c.clip();c.strokeStyle='#ffe99a99';c.lineWidth=1;for(let x=-55;x<55;x+=11){c.beginPath();c.moveTo(p.x+x,p.y-25);c.lineTo(p.x+x+45,p.y+25);c.stroke();}c.restore();}
    if(this.targets.has(key(t))){this.hex(p.x,p.y,34);c.strokeStyle='#ffdfd0';c.lineWidth=2.3;c.stroke();c.beginPath();c.arc(p.x,p.y+15,4,0,Math.PI*2);c.moveTo(p.x-7,p.y+15);c.lineTo(p.x+7,p.y+15);c.moveTo(p.x,p.y+8);c.lineTo(p.x,p.y+22);c.stroke();}
    if(this.previewOrigin===key(t)){this.hex(p.x,p.y,30);c.strokeStyle='#89e0ff';c.lineWidth=3;c.stroke();c.font='bold 9px system-ui';c.textAlign='center';c.fillStyle='#e7faff';c.fillText('이동 예상',p.x,p.y-10);}
    if((this.hover&&key(this.hover)===key(t))||(this.focus&&key(this.focus)===key(t))){this.hex(p.x,p.y,36);c.strokeStyle='#f3eed4';c.lineWidth=2;c.stroke();}
    if(this.battle.active&&this.battle.visibleUnit(this.battle.active)&&key(this.battle.active)===key(t)){this.hex(p.x,p.y,34);c.strokeStyle=this.battle.active.team===0?'#dbe9a2':'#edaa92';c.lineWidth=2;c.stroke();c.fillStyle='#e0e7b233';c.fill();}
    if(t.elevation>0){c.fillStyle='#27352999';c.fillRect(p.x+17,p.y+13,12,11);c.font='8px system-ui';c.textAlign='center';c.fillStyle='#e0e2bd';c.fillText(`${t.elevation}`,p.x+23,p.y+21);}
  }
  decoration(t){const c=this.ctx,p=this.point(t);if(this.battle.at(t)||this.battle.stones.some(s=>key(s)===key(t)))return;
    if(t.terrain==='forest'){const x=p.x+7,y=p.y-3;c.fillStyle='#243e3055';c.beginPath();c.ellipse(x,y+7,15,6,0,0,TAU);c.fill();c.fillStyle='#6f6550';c.fillRect(x-2,y-18,4,25);for(let j=0;j<3;j++){c.fillStyle=['#2d4f3c','#365b41','#456d49'][j];c.beginPath();c.moveTo(x,y-47+j*12);c.lineTo(x-17+j*3,y-17+j*11);c.lineTo(x+17-j*3,y-17+j*11);c.closePath();c.fill();}c.fillStyle='#84a96c88';c.fillRect(x-3,y-34,3,8);}
    if(t.terrain==='rock'){c.fillStyle='#667565';c.beginPath();c.moveTo(p.x-12,p.y+7);c.lineTo(p.x-10,p.y-5);c.lineTo(p.x,p.y-14);c.lineTo(p.x+12,p.y-6);c.lineTo(p.x+15,p.y+6);c.fill();c.fillStyle='#bcc3a7';c.beginPath();c.moveTo(p.x-10,p.y-5);c.lineTo(p.x,p.y-14);c.lineTo(p.x+12,p.y-6);c.lineTo(p.x,p.y);c.fill();}
  }
  stone(s,now){const t=this.battle.tiles.get(key(s)),p=this.point(t),c=this.ctx,col=s.owner===0?'#d5e59f':s.owner===1?'#e8a48d':'#b2cce5';c.fillStyle='#374d49';c.beginPath();c.ellipse(p.x,p.y+4,13,7,0,0,TAU);c.fill();c.strokeStyle=col+'99';c.lineWidth=1;c.beginPath();c.ellipse(p.x,p.y,17,9,0,0,TAU);c.stroke();const bob=this.reduced?0:Math.sin(now/700+s.q)*2;c.shadowBlur=14;c.shadowColor=col;c.fillStyle=col;c.beginPath();c.moveTo(p.x,p.y-32+bob);c.lineTo(p.x+8,p.y-19+bob);c.lineTo(p.x,p.y-5+bob);c.lineTo(p.x-8,p.y-19+bob);c.closePath();c.fill();c.shadowBlur=0;c.fillStyle='#ffffff99';c.beginPath();c.moveTo(p.x,p.y-32+bob);c.lineTo(p.x,p.y-5+bob);c.lineTo(p.x-8,p.y-19+bob);c.closePath();c.fill();}
  unit(u,now){const c=this.ctx,p=this.motion(u,now);const bob=this.reduced?0:Math.floor(Math.sin(now/450+u.id)*1.3);c.fillStyle='#172d2977';c.beginPath();c.ellipse(p.x,p.y+4,16,7,0,0,TAU);c.fill();c.strokeStyle=u.team===0?'#d2e6a0':'#e6a28e';c.lineWidth=2;c.beginPath();c.ellipse(p.x,p.y+3,15,6,0,0,TAU);c.stroke();const fx=this.effects.filter(e=>e.id===u.id&&e.start<=now&&now-e.start<(e.type==='damage'?220:e.duration)&&['damage','attack','spell','summon','move'].includes(e.type)).sort((a,b)=>b.start-a.start)[0];const state=fx?({damage:'hit',attack:'attack',spell:'cast',summon:'cast',move:'move'})[fx.type]:'idle',count=({idle:4,move:6,attack:8,cast:6,hit:2})[state];const frame=fx?state==='move'?Math.floor((now-fx.start)*this.speed/100)%6:Math.min(count-1,Math.floor((now-fx.start)/fx.duration*count)):Math.floor(now/220)%4;c.save();if(!referenceSprite(u)&&[2,3,4].includes(u.facing)){c.translate(p.x*2,0);c.scale(-1,1);}paintSprite(c,p.moving?{...u,facing:direction(p.from,p.to)}:u,p.x,p.y+2+bob,1.65,{state,frame});c.restore();if(state==='hit'&&now-fx.start<220){c.fillStyle='#ffffff77';c.fillRect(p.x-12,p.y-35,24,27);}if(u.master){c.fillStyle='#e6c886';c.font='13px Georgia';c.textAlign='center';c.fillText('♛',p.x,p.y-54+bob);}if(u.element!=='neutral'){c.fillStyle=ELEMENTS[u.element].color;c.font='10px system-ui';c.textAlign='center';c.fillText(ELEMENTS[u.element].glyph,p.x+20,p.y-19);}}
  effect(e,now){if(e.type==='damage'||e.type==='heal')return;const c=this.ctx,progress=(now-e.start)/e.duration;let p=e.q!==undefined?this.point(this.battle.tiles.get(key(e))):null;c.globalAlpha=Math.max(0,1-progress);if(e.type==='down'){paintSprite(c,e.unit,p.x,p.y+2,1.65,{state:'down',frame:Math.min(3,Math.floor(progress*4))});}else if(e.type==='summon'||e.type==='capture'||e.type==='spell'){const color=ELEMENTS[e.element]?.color||'#d6e5ad';c.strokeStyle=color;c.lineWidth=3;c.beginPath();c.ellipse(p.x,p.y,14+progress*60,8+progress*35,0,0,TAU);c.stroke();for(let i=0;i<8;i++){const a=i*TAU/8+progress*2;c.fillStyle=color;c.fillRect(p.x+Math.cos(a)*progress*45,p.y-20+Math.sin(a)*progress*35,3,3);}}else if(e.type==='attack'){const a=this.point(this.battle.tiles.get(key(e.from))),b=this.point(this.battle.tiles.get(key(e.to)));c.strokeStyle=ELEMENTS[e.element]?.color||'#f0d4a5';c.lineWidth=3;c.beginPath();c.moveTo(a.x,a.y-23);c.lineTo(a.x+(b.x-a.x)*Math.min(1,progress*3),a.y-23+(b.y-a.y)*Math.min(1,progress*3));c.stroke();}c.globalAlpha=1;}
  healthOverlay(now){
    const c=this.ctx,bounds={x:5,y:46,width:this.width-10,height:Math.max(0,this.height-122)};
    const units=this.battle.units.filter(u=>this.displayHp(u,now)>0&&this.battle.visibleUnit(u)&&this.battle.visible(this.motion(u,now).cell));
    const occupied=units.map(u=>{const p=this.screenMotion(u,now);return {x:p.x-14*this.scale,y:p.y-43*this.scale,width:28*this.scale,height:46*this.scale};});
    c.save();c.textAlign='center';
    // One HP badge per character; no repeated HP line attached to damage numbers.
    for(const u of units.sort((a,b)=>Number(b.id===this.battle.activeId)-Number(a.id===this.battle.activeId)||a.id-b.id)){
      const p=this.screenMotion(u,now);if(p.x<0||p.x>this.width||p.y<0||p.y>this.height)continue;
      const rect=placeLabel({x:p.x,y:p.y+9*this.scale},36,17,occupied,bounds);if(!rect)continue;
      c.fillStyle='#101e19f2';c.fillRect(rect.x,rect.y,rect.width,rect.height);
      const hp=this.displayHp(u,now);c.fillStyle=hp<=3?'#ffb6a0':u.team===0?'#e0f3b2':'#ffd0c2';c.font='bold 11px system-ui';c.fillText(`${hp}/${u.maxHp}`,rect.x+18,rect.y+12);
    }
    const latest=new Map();for(const e of this.effects)if(e.start<=now&&['damage','heal'].includes(e.type))latest.set(e.id,e);
    for(const e of latest.values()){
      const tile=this.battle.tiles.get(key(e));if(!tile)continue;
      const u=this.battle.units.find(u=>u.id===e.id),p=u?this.screenMotion(u,now):this.screen(tile),progress=(now-e.start)/e.duration;
      const text=e.type==='heal'?`+${e.amount}`:e.amount===0?'피해 없음':`${e.kind==='반격'?'반격 ':''}−${e.amount}`;
      c.font='bold 17px system-ui';const width=Math.ceil(c.measureText(text).width)+12;
      const rect=placeLabel({x:p.x,y:Math.max(bounds.y,p.y-65*this.scale)},width,24,occupied,bounds);if(!rect)continue;
      c.globalAlpha=Math.min(1,Math.max(0,(1-progress)*4));c.fillStyle='#101a17ed';c.fillRect(rect.x,rect.y,width,24);
      c.strokeStyle=e.kind==='반격'?'#ffce7580':'#eee3c880';c.lineWidth=1;c.beginPath();c.moveTo(rect.x+width/2,rect.y+24);c.lineTo(p.x,p.y-38*this.scale);c.stroke();
      c.fillStyle=e.type==='heal'?'#c7ffa9':e.kind==='반격'?'#ffce75':'#fff2df';c.fillText(text,rect.x+width/2,rect.y+18);
    }
    c.globalAlpha=1;
    const active=this.battle.active;
    if(active?.team===0&&!this.isPlaying(now)&&this.battle.winner===null){
      const p=this.screenMotion(active,now),text=this.battle.moved?'행동 선택':'내 차례',rect=placeLabel({x:p.x,y:Math.max(bounds.y,p.y-68*this.scale)},64,22,occupied,bounds);
      if(rect){c.fillStyle='#e8f8a8';c.fillRect(rect.x,rect.y,64,22);c.fillStyle='#163523';c.font='bold 12px system-ui';c.fillText(text,rect.x+32,rect.y+15);}
    }
    c.restore();
  }
  activeHalo(u,now){
    if(u.id!==this.battle.activeId||u.team!==0||this.battle.winner!==null||this.isPlaying(now))return;
    const c=this.ctx,p=this.motion(u,now),pulse=this.reduced?0:Math.sin(now/260)*2;
    c.save();c.strokeStyle='#edff9c';c.lineWidth=3/this.scale;c.shadowColor='#d9ff7d';c.shadowBlur=10;
    c.beginPath();c.ellipse(p.x,p.y+3,22+pulse,12+pulse*.5,0,0,TAU);c.stroke();c.shadowBlur=0;
    c.fillStyle='#edff9c';c.beginPath();c.moveTo(p.x,p.y-57-pulse);c.lineTo(p.x-6,p.y-66-pulse);c.lineTo(p.x+6,p.y-66-pulse);c.closePath();c.fill();c.restore();
  }
  loop(now){requestAnimationFrame(this.loop);if(now-this.lastFrame<32||document.hidden)return;const elapsed=now-this.lastFrame;this.preserveFrames(now);this.lastFrame=now;const c=this.ctx;c.setTransform(this.dpr||1,0,0,this.dpr||1,0,0);c.clearRect(0,0,this.width,this.height);if(!this.battle)return;this.trackCamera(now,elapsed);for(const e of this.effects){if(e.start<=now&&!e.presented){e.presented=true;this.callbacks.effect?.(e,now-e.start<250);}}this.effects=this.effects.filter(e=>now-e.start<e.duration);if(this.playbackUntil&&now>=this.playbackUntil){this.playbackUntil=0;this.callbacks.complete?.();}c.save();c.translate(this.pan.x,this.pan.y);c.scale(this.scale,this.scale);c.imageSmoothingEnabled=false;
    const tiles=this.battle.stage.tiles.filter(t=>t.terrain!=='void').sort((a,b)=>a.r-b.r||a.q-b.q);for(const t of tiles)this.tile(t,now);
    for(const t of tiles){if(!this.battle.visible(t)){const p=this.point(t);this.hex(p.x,p.y);c.fillStyle='#10201ddb';c.fill();continue;}this.decoration(t);const s=this.battle.stones.find(s=>key(s)===key(t));if(s)this.stone(s,now);for(const pair of this.battle.stage.portals||[])if(pair.some(x=>key(x)===key(t))){const p=this.point(t);c.strokeStyle='#c2a4ee';c.lineWidth=2;c.beginPath();c.ellipse(p.x,p.y,20,11,0,0,TAU);c.stroke();}}
    const visibleUnits=this.battle.units.filter(u=>this.displayHp(u,now)>0&&this.battle.visibleUnit(u)&&this.battle.visible(this.motion(u,now).cell));
    visibleUnits.sort((a,b)=>this.motion(a,now).y-this.motion(b,now).y);for(const u of visibleUnits){this.activeHalo(u,now);this.unit(u,now);}
    this.effects=this.effects.filter(e=>now-e.start<e.duration);for(const e of this.effects)if(e.start<=now&&e.type!=='move')this.effect(e,now);c.restore();if(this.battle.brightness()<1){c.fillStyle=`rgba(7,12,30,${(1-this.battle.brightness())*.22})`;c.fillRect(0,0,this.width,this.height);}
    this.healthOverlay(now);
    if(!this.reduced){for(let i=0;i<12;i++){const x=(i*173+Math.sin(now/7000+i)*35+this.width*2)%this.width,y=(i*97-now/150+this.height*20)%this.height;c.globalAlpha=.15+Math.sin(now/1600+i)*.12;c.fillStyle='#d8e5b4';c.fillRect(x,y,2,2);}c.globalAlpha=1;}
  }
}
