
export function audibleEvents(battle,events){return events.filter(e=>e.type==='turn'?e.team===0:eventVisible(battle,e));}
export function eventVisible(battle,e){return e.q!==undefined?battle.visible(e):!e.from||battle.visible(e.from)||battle.visible(e.to);}
