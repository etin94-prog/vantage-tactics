import { Battle } from './engine.js';
import { generateStage } from './maps.js';
import { SUMMONS } from './data.js';
import { key } from './hex.js';

// Shared by the browser lab and CLI. No DOM, storage, network, or eval.
export const LAB_SCHEMA='vantage-lab-v1';
export const LAB_CASES=[['campaign','원본 캠페인'],['undo','이동·취소·마석'],['healing','회복·SAT'],['freeze','동결·시간'],['area','범위·아군 피해'],['tide','수위·지형'],['zoc','길목·ZOC']];
export function labArena(){return {id:1,custom:true,name:'규칙 실험장',gridWidth:11,gridHeight:7,startMinutes:480,playerMasterStart:{q:1,r:3},enemyMasterStart:{q:9,r:3,classId:'duke'},manaStones:[{q:2,r:3}],tiles:Array.from({length:77},(_,i)=>({q:i%11,r:Math.floor(i/11),terrain:'grass',elevation:0}))};}
export function createLabBattle({scenario='campaign',stage=0,master='adol',level=1}={}){
  if(!LAB_CASES.some(c=>c[0]===scenario)||!Number.isInteger(stage)||stage<0||stage>29||!Number.isInteger(level)||level<1||level>40)throw new Error('시나리오·스테이지·레벨 범위를 확인하세요.');
  const map=scenario==='campaign'?generateStage(stage):labArena();
  if(scenario==='tide')Object.assign(map.tiles.find(t=>key(t)==='3,3'),{terrain:'water',terrainCode:7,elevation:1,secondaryHeight:0});
  const b=new Battle(map,master,{playerLevel:level,unlocked:SUMMONS.map(s=>s.id),extraSpells:['v2-10','v2-11','v2-12','v2-13','v2-14','v2-15']});
  if(scenario==='undo')b.active.facing=4;
  const caster={healing:'d-alma',freeze:'zamilpen',area:'currier-bell'}[scenario];
  if(caster){const u=b.addUnit(caster,0,{q:3,r:3});b.activeId=u.id;u.nextTime=b.time;}
  if(scenario==='healing'){const u=b.addUnit('fa-rancell',0,{q:4,r:3});u.hp=5;}
  if(scenario==='freeze')b.addUnit('fa-rancell',1,{q:4,r:3});
  if(scenario==='area'){b.addUnit('fa-rancell',0,{q:4,r:2});b.addUnit('reque',1,{q:4,r:3});}
  if(scenario==='zoc'){b.units[1].q=5;}
  // Rebuild the scheduler after arranging a fixture, retaining the chosen active unit.
  return Battle.restore(structuredClone(b.serialize()));
}
export function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).filter(k=>value[k]!==undefined).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';return JSON.stringify(value);}
export function stateHash(b){const value=canonical(typeof b.serialize==='function'?b.serialize():b);let h=2166136261;for(let i=0;i<value.length;i++)h=Math.imul(h^value.charCodeAt(i),16777619);return (h>>>0).toString(16).padStart(8,'0');}
export function checkInvariants(b){
  const errors=[],positions=new Set();
  if(!Number.isFinite(b.time)||b.time<0)errors.push('게임 시각 오류');
  for(const u of b.living){if(!b.tiles.has(key(u)))errors.push(`유닛 ${u.id}: 맵 밖`);if(positions.has(key(u)))errors.push(`유닛 ${u.id}: 위치 중복`);positions.add(key(u));if(!Number.isFinite(u.hp)||u.hp>u.maxHp)errors.push(`유닛 ${u.id}: HP 범위 오류`);}
  if(b.mana.some((n,i)=>!Number.isFinite(n)||n<0||n>b.maxMana(i)))errors.push('마나 범위 오류');
  if(b.winner===null&&!b.active)errors.push('현재 행동 유닛 없음');
  for(const u of b.living)if(u.id!==b.activeId&&u.nextTime<b.time)errors.push(`유닛 ${u.id}: 과거에 예약된 행동`);
  return errors;
}
export function labAction(b,a){
  if(!a||typeof a!=='object')throw new Error('행동 객체가 필요합니다.');
  if(['move','summon','cast'].includes(a.type)&&(!Number.isInteger(a.q)||!Number.isInteger(a.r)||!b.tiles.has(key(a))))throw new Error('잘못된 목표 좌표입니다.');
  const before=b.time;let ok;
  switch(a.type){
    case 'move':ok=b.move(a);break;
    case 'undo':ok=b.undoMove();break;
    case 'attack':ok=b.attack(a.target);break;
    case 'summon':ok=b.summon(a.unit,a);break;
    case 'cast':ok=b.cast(a.spell,a);break;
    case 'facing':ok=b.setFacing(a.facing);break;
    case 'wait':ok=b.wait();break;
    case 'ai':if(!b.active||b.winner!==null)return false;b.aiTurn();ok=true;break;
    default:throw new Error('허용하지 않는 행동입니다: '+a.type);
  }
  if(b.time<before)throw new Error('행동 후 시간이 역행했습니다.');
  const errors=checkInvariants(b);if(errors.length)throw new Error(errors.join(' / '));
  return !!ok;
}
export class LabSession {
  constructor(b,build='development',label='experiment'){this.battle=b;this.build=build;this.label=label;this.initial=structuredClone(b.serialize());this.steps=[];}
  act(action){
    if(this.steps.length>=500)throw new Error('기록은 500행동까지입니다. 새 실험을 시작하세요.');
    const preHash=stateHash(this.battle);let accepted=false,error;
    try{accepted=labAction(this.battle,action);}catch(e){error=e.message;}
    this.steps.push({action:structuredClone(action),accepted,preHash,postHash:stateHash(this.battle),time:this.battle.time,turn:this.battle.turn,...(error?{error}:{})});
    if(error)throw new Error(error);return accepted;
  }
  bundle(review={}){return {schema:LAB_SCHEMA,build:this.build,label:this.label,initial:structuredClone(this.initial),steps:structuredClone(this.steps),finalHash:stateHash(this.battle),review:structuredClone(review)};}
}
export function replayBundle(input,build='development'){
  if(!input||input.schema!==LAB_SCHEMA||!Array.isArray(input.steps)||input.steps.length>500||typeof input.build!=='string'||typeof input.finalHash!=='string')throw new Error('지원하지 않는 실험 JSON입니다.');
  if(JSON.stringify(input).length>8_000_000)throw new Error('실험 JSON은 8MB 이하만 지원합니다.');
  const b=Battle.restore(structuredClone(input.initial)),session=new LabSession(b,build,String(input.label||'imported').slice(0,120));
  const errors=checkInvariants(b);if(errors.length)throw new Error(errors.join(' / '));
  const reproducedErrors=[];
  for(let i=0;i<input.steps.length;i++){
    const expected=input.steps[i];if(stateHash(b)!==expected.preHash)throw new Error(`${i+1}행동 직전 상태 불일치`);
    let accepted=false,error;try{accepted=session.act(expected.action);}catch(e){error=e.message;}
    if(error!==expected.error)throw new Error(`${i+1}행동 예외 불일치: ${error||'예외 없음'}`);
    if(error)reproducedErrors.push({step:i+1,error});
    if(accepted!==expected.accepted||stateHash(b)!==expected.postHash||b.time!==expected.time||b.turn!==expected.turn)throw new Error(`${i+1}행동 재현 불일치 (${expected.action.type})`);
  }
  if(stateHash(b)!==input.finalHash)throw new Error('최종 상태 불일치');
  return {session,buildMatch:input.build===build,review:input.review||{},reproducedErrors};
}
export function runLabSuite(build='development',onResult=()=>{}){
  const results=[];
  function check(name,scenario,run){let session;try{session=new LabSession(createLabBattle({scenario}),build,name);const require=(v,message)=>{if(!v)throw new Error(message);};run(session,require);replayBundle(session.bundle(),build);results.push({name,status:'pass',actions:session.steps.length,hash:stateHash(session.battle)});}catch(e){results.push({name,status:'fail',error:e.message,reproduction:session?.bundle()});}onResult(results.at(-1));}
  check('이동 취소와 마석 확정','undo',(s,ok)=>{const original=stateHash(s.battle);ok(s.act({type:'move',q:2,r:3}),'이동 실패');ok(s.battle.stones[0].owner===null,'이동 중 점령');ok(s.act({type:'undo'}),'취소 실패');ok(stateHash(s.battle)===original,'취소 후 상태 차이');s.act({type:'move',q:2,r:3});s.act({type:'wait'});ok(!s.act({type:'undo'}),'확정 후 취소됨');ok(s.battle.stones[0].owner===0,'점령 실패');});
  check('회복과 실회복량 SAT','healing',(s,ok)=>{const u=s.battle.active,t=s.battle.at({q:4,r:3});ok(s.act({type:'cast',spell:'v2-23',q:4,r:3}),'회복 실패');ok(t.hp===8&&u.sat===30,'회복/SAT 불일치');});
  check('동결과 저장 재현','freeze',(s,ok)=>{const t=s.battle.at({q:4,r:3});ok(s.act({type:'cast',spell:'v2-26',q:4,r:3}),'동결 실패');ok(s.battle.hasStatus(t,'freeze'),'동결 상태 누락');});
  check('범위 마법 아군 피해','area',(s,ok)=>{const units=[s.battle.active,s.battle.at({q:4,r:2}),s.battle.at({q:4,r:3})];ok(s.act({type:'cast',spell:'v2-20',q:4,r:3}),'마법 실패');ok(units.every(u=>u.hp<10),'범위 대상 피해 누락');});
  check('수위 만료와 원상 복구','tide',(s,ok)=>{const before=s.battle.stage.tiles.map(t=>[t.terrain,t.elevation]);ok(s.act({type:'cast',spell:'v2-10',q:1,r:3}),'업타이드 실패');ok(!!s.battle.tide,'수위 변화 누락');for(let i=0;i<30&&s.battle.tide;i++)s.act({type:'wait'});ok(!s.battle.tide,'수위 만료 실패');ok(canonical(before)===canonical(s.battle.stage.tiles.map(t=>[t.terrain,t.elevation])),'원래 지형 복구 실패');});
  for(let stage=0;stage<30;stage++){
    let session;try{session=new LabSession(createLabBattle({stage}),build,`stage-${stage+1}`);for(let i=0;i<18&&session.battle.winner===null;i++)session.act({type:'ai'});replayBundle(session.bundle(),build);results.push({name:`전장 ${stage+1} · AI 18행동 + 재현`,status:'pass',actions:session.steps.length,hash:stateHash(session.battle)});}catch(e){results.push({name:`전장 ${stage+1}`,status:'fail',error:e.message,reproduction:session?.bundle()});}onResult(results.at(-1));
  }
  return {schema:LAB_SCHEMA,build,kind:'suite',results,passed:results.filter(r=>r.status==='pass').length,failed:results.filter(r=>r.status==='fail').length,scope:'구현 회귀·상태 재현 검사. 원작 일치율·캠페인 완주·밸런스 검증이 아님.'};
}
