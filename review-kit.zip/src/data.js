import { V2_MASTERS, V2_NATIALS, V2_ACTIONS, V2_MAPS, V2_PLAYLIST_ORDER } from './v2-reference.js';
import { v2SpellId } from './spells.js';
export const ELEMENTS={earth:{name:'지(地)',glyph:'◆',color:'#b5bb65',beats:'water'},water:{name:'수(水)',glyph:'◈',color:'#79c7db',beats:'fire'},fire:{name:'화(火)',glyph:'✦',color:'#e48b68',beats:'wind'},wind:{name:'천(天)',glyph:'❋',color:'#d1c991',beats:'earth'},neutral:{name:'무속성',glyph:'◇',color:'#e9dec3'}};
export const TERRAIN={
 floating:{name:'부유 발판',cost:1,color:'#a39571',side:'#5c6653',defense:0},
 marsh:{name:'습지',cost:2,color:'#77876a',side:'#43533e',defense:0},snow:{name:'눈',cost:2,color:'#c6d8d7',side:'#829b9c',defense:0},grass:{name:'평지',cost:1,color:'#758664',side:'#46563f',defense:0},forest:{name:'수풀 / 갈대',cost:2,color:'#4c6c57',side:'#344b3b',defense:1},water:{name:'얕은 물',cost:2,color:'#548f95',side:'#365e66',defense:0},deep_water:{name:'깊은 물',cost:Infinity,color:'#366c84',side:'#25465f',defense:0},rock:{name:'암반',cost:1,color:'#96968a',side:'#64685e',defense:2},sand:{name:'모래',cost:2,color:'#baaa79',side:'#7e7454',defense:0},wall:{name:'돌담',cost:Infinity,color:'#555e53',side:'#353c33',defense:4},void:{name:'낭떠러지',cost:Infinity,color:'#253b42',side:'#19272e',defense:0},ice:{name:'빙판',cost:1,color:'#a1c6cd',side:'#6a939f',defense:-1},lava:{name:'용암',cost:1,color:'#b76341',side:'#793b2b',defense:0},stone:{name:'마정석 제단',cost:1,color:'#879b88',side:'#516459',defense:1},swamp:{name:'독 늪',cost:2,color:'#627754',side:'#3b4934',defense:0},
};
const masterVisuals={fighter:['sword','#729cbb'],knight:['knight','#aab6ba'],paladin:['knight','#e1d4a3'],swordsman:['sword','#617a9f'],duke:['ranger','#ab92b6'],sorcerer:['mage','#738fc1'],witch:['mage','#c880aa'],sister:['mage','#e1e4d9'],bard:['ranger','#80ab82'],thief:['rogue','#a49173'],ranger:['ranger','#9bad77'],monk:['beast','#dba678'],beast:['beast','#b8aa8e'],spirit:['spirit','#9dd7cd'],shadow:['rogue','#787087'],savage:['beast','#bc9777'],nightmare:['knight','#9c85b0'],fraulein:['mage','#d5a7ae']};

export function masterStats(definition,level=1){const row=definition.levels[Math.max(0,Math.min(39,level-1))];return Object.fromEntries(['maxMana','attack','defense','magicAttack','magicDefense','speed','move'].map((key,i)=>[key,row[i]]));}
export const MASTERS=V2_MASTERS.map(m=>{const [art,color]=masterVisuals[m.id]||['sword','#86a9bd'];const stats=masterStats(m);return {...m,...stats,hp:10,range:1,art,color,element:'neutral',description:m.sourceIndex<18?'V2 기본 직업 · 원본 성장 수치':'V2 추가 캐릭터 · 원본 성장 수치',gait:m.id==='spirit'?'비행':'보행',movementType:m.id==='spirit'?4:1,flying:m.id==='spirit',delay:Math.floor(6000/stats.speed),spells:[]};});
export const BOSSES=[];
const natialArt=['beast','golem','golem','golem','spirit','beast','slime','knight','slime','bird','spirit','golem','flame','beast','ranger','slime','dragon','dragon','spirit','bird','ranger','spirit','mage','dragon'];
// Scroll rewards are a temporary web campaign progression, not decoded original rewards.
const unlockAfter=[0,6,1,5,3,11,0,3,7,2,8,18,0,8,4,10,16,23,2,6,4,0,20,22];
export const SUMMONS=V2_NATIALS.map((s,i)=>{const [attack,defense,magicAttack,magicDefense,speed,move]=s.levels[0];return {...s,hp:10,attack,defense,magicAttack,magicDefense,speed,move,range:V2_ACTIONS[s.attackType].range,attackProfile:V2_ACTIONS[s.attackType],rangeVerified:true,upkeep:Math.trunc(s.cost/8),upkeepVerified:true,art:natialArt[i],color:ELEMENTS[s.element].color,tier:Math.min(3,Math.ceil(s.cost/32)),delay:Math.floor(6000/speed),unlockAfter:unlockAfter[i],flying:s.movementType===4,aquatic:[2,3].includes(s.movementType),gait:['보행','보행2','수영','수영2','비행'][s.movementType],subtitle:s.spellIndex?'원본 수치 · 고유 마법':'원본 수치 · 물리 공격',spells:s.spellIndex?[v2SpellId(s.spellIndex)]:[],ignoreSight:false,ignoreHeight:false};});
export const STAGE_NAMES=V2_PLAYLIST_ORDER.map(i=>V2_MAPS[i].name);
// These rules remain provisional pending controlled original-game measurements.
export const LIMITS={maxMana:200,startMana:60,maxSummons:6,summonRadius:1,stoneIncome:3,baseIncome:14,economyMinutes:60,ticksPerMinute:1};
export const ACTION_COSTS={wait:30,move:40,attack:60,moveAttack:90,summon:80,moveSummon:110,spell:90,moveSpell:120};

for(const m of MASTERS){m.attackType=m.id==='ranger'?6:m.id==='savage'?7:1;m.attackProfile=V2_ACTIONS[m.attackType];m.range=m.attackProfile.range;}
