import { V2_MAPS, V2_PLAYLIST_ORDER } from './v2-reference.js';
import { TERRAIN, SUMMONS } from './data.js';
import { v2SpellId } from './spells.js';
import { key } from './hex.js';
export function offsetToAxial(x,y){return {q:x-Math.floor(y/2),r:y};}
const referenceTerrains=['grass','sand','forest','marsh','snow','swamp','floating','water','deep_water','deep_water','wall','void','stone','water','deep_water','deep_water','void'];
export function generateStage(index=0){
  const source=V2_MAPS[V2_PLAYLIST_ORDER[index]];
  if(!source)throw new Error('존재하지 않는 스테이지');
  const tiles=[],manaStones=[];
  for(let y=0;y<32;y++)for(let x=0;x<32;x++){
    const at=(y*32+x)*4,[elevation,terrainCode,secondaryHeight,flags]=source.cells.slice(at,at+4);
    const pos=offsetToAxial(x,y);
    tiles.push({...pos,elevation,terrain:referenceTerrains[terrainCode],sourceX:x,sourceY:y,terrainCode,secondaryHeight,sourceFlags:flags});
    if(terrainCode>=12&&terrainCode<=15)manaStones.push({...pos,owner:source.owners.find(s=>s[0]===x&&s[1]===y)?.[2]??null});
  }
  const spawn=([x,y,facing])=>({...offsetToAxial(x,y),sourceX:x,sourceY:y,sourceFacing:facing});
  return {id:index+1,stageId:`V2_MAP_${String(source.sourceIndex).padStart(3,'0')}`,name:source.name,
    sourceName:source.sourceName,sourceIndex:source.sourceIndex,gridWidth:32,gridHeight:32,coordinateSystem:'odd-r-to-axial',
    theme:'reference',defaultLighting:1,startMinutes:source.startMinutes,fixedBrightness:source.dynamicLighting?undefined:[.5,1,0][source.fixedPeriod],
    playerMasterStart:{...spawn(source.player),level:1},enemyMasterStart:{...spawn(source.enemy),classId:source.enemyClass,level:source.enemyLevel,name:source.enemyName},
    enemyRoster:source.enemyRoster,enemySpells:source.enemySpells.map(v2SpellId),tideAI:!!source.tideAI,tiles,manaStones,stoneCount:manaStones.length,portals:[],generatedLayout:false,
    provenance:{layout:'DATA10 SC/MD/MP numeric records',stats:'English VMOnline; first playlist Adol/Duke matched',rules:'partial; see V2_RESTORATION_STATUS.md'},
    clearRewards:{exp:100,unlockStage:Math.min(30,index+2),unlockedNaitials:SUMMONS.filter(s=>s.unlockAfter===index+1).map(s=>s.id),unlockedSpells:[]}};
}
const terrainAliases={plains:'grass',bush:'forest',reeds:'forest',gravel:'rock',highland_rock:'rock',shallow_water:'water',ice_sheet:'ice',stone_pedestal:'stone'};
export function normalizeStage(raw){
  if(!raw||typeof raw!=='object')throw new Error('맵 JSON 객체가 필요합니다.');
  const s=structuredClone(raw),id=s.id||Number(String(s.stageId||'').match(/_(\d+)$/)?.[1])||1;
  s.id=id;s.name=s.stageName||s.name||'사용자 전장';s.gridWidth??=s.width;s.gridHeight??=s.height;s.playerMasterStart??=s.playerSpawnPos;s.enemyMasterStart??=s.enemyMaster?{...s.enemyMaster.spawnPos,classId:s.enemyMaster.classId,level:s.enemyMaster.level}:undefined;s.clearRewards??=s.rewards;s.defaultLighting??=s.lighting??1;
  if(!Array.isArray(s.tiles)||s.tiles.length<s.gridWidth*s.gridHeight){if(!Number.isInteger(s.gridWidth)||!Number.isInteger(s.gridHeight)||s.gridWidth<1||s.gridHeight<1||s.gridWidth>40||s.gridHeight>40)throw new Error('유효한 gridWidth/gridHeight가 필요합니다.');const supplied=s.tiles||[],seen=new Set(supplied.map(key));s.tiles=[...supplied];for(let r=0;r<s.gridHeight;r++)for(let q=0;q<s.gridWidth;q++)if(!seen.has(`${q},${r}`))s.tiles.push({q,r,terrain:'grass',height:2});s.filledUnspecifiedTiles=true;}
  s.tiles=s.tiles.map(t=>({...t,terrain:terrainAliases[t.terrain]||t.terrain,elevation:t.elevation??t.height??2}));s.manaStones=s.manaStones||[];
  for(const stone of s.manaStones){const t=s.tiles.find(t=>key(t)===key(stone));if(t){if(t.terrainCode===undefined)t.terrain='stone';if(stone.height!==undefined)t.elevation=stone.height;}}
  return validateStage(s);
}
export function validateStage(stage){
  if(!stage||!Array.isArray(stage.tiles)||stage.tiles.length<6||stage.tiles.length>1600)throw new Error('tiles는 6~1600개의 타일이어야 합니다.');
  if(!Number.isInteger(stage.gridWidth)||!Number.isInteger(stage.gridHeight)||stage.gridWidth<1||stage.gridHeight<1||stage.gridWidth>40||stage.gridHeight>40)throw new Error('gridWidth/gridHeight는 1~40의 정수여야 합니다.');
  const seen=new Set();for(const t of stage.tiles){if(!Number.isInteger(t.q)||!Number.isInteger(t.r)||Math.abs(t.q)>60||Math.abs(t.r)>60||!Object.hasOwn(TERRAIN,t.terrain)||!Number.isInteger(t.elevation)||t.elevation<0||t.elevation>31||seen.has(key(t)))throw new Error('좌표·지형·높이(0~31)·중복 타일을 확인하세요.');seen.add(key(t));}
  for(const s of [stage.playerMasterStart,stage.enemyMasterStart,...(stage.enemyAllies||[])])if(!s||!Number.isInteger(s.q)||!Number.isInteger(s.r)||!seen.has(key(s))||stage.tiles.find(t=>key(t)===key(s)).terrain==='wall')throw new Error('소환사의 유효한 시작 좌표가 필요합니다.');
  if(key(stage.playerMasterStart)===key(stage.enemyMasterStart))throw new Error('시작 지점은 서로 달라야 합니다.');
  if(!Array.isArray(stage.manaStones)||stage.manaStones.length>30)throw new Error('manaStones는 최대 30개의 배열이어야 합니다.');
  const stones=new Set();for(const s of stage.manaStones){if(!s||!Number.isInteger(s.q)||!Number.isInteger(s.r)||!seen.has(key(s))||['wall','void'].includes(stage.tiles.find(t=>key(t)===key(s)).terrain)||stones.has(key(s))||s.income!==undefined&&(!Number.isFinite(s.income)||s.income<0||s.income>12))throw new Error('마석 좌표 또는 수입이 유효하지 않습니다.');stones.add(key(s));}
  if(stage.portals!==undefined&&(!Array.isArray(stage.portals)||stage.portals.length>20||stage.portals.some(pair=>!Array.isArray(pair)||pair.length!==2||pair.some(p=>!p||!seen.has(key(p))))))throw new Error('워프 포탈 좌표 오류');
  return stage;
}
