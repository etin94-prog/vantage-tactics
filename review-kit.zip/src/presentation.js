export const PRESENTATION_SPEEDS=[.75,1,2,3];
export function presentationRate(value){return PRESENTATION_SPEEDS.includes(Number(value))?Number(value):1;}

export function planPresentation(events,battle,now,rate=1){
  const speed=presentationRate(rate),planned=[];let walkEnd=0;
  for(const e of events.filter(e=>e.type==='move')){
    const path=e.path?.length>1?e.path:[e.from,e.to];
    const duration=Math.max(280,(path.length-1)*260)/speed;
    planned.push({...e,path,start:now+walkEnd,duration});walkEnd+=duration;
  }
  const attack=events.some(e=>e.type==='attack'),spell=events.some(e=>e.type==='spell');
  const impact=walkEnd+(attack?300:spell?400:0)/speed;
  let lastImpact=impact;
  for(const e of events){
    if(e.type==='move'||e.type==='turn')continue;
    let at=walkEnd,duration=700/speed;
    if(e.type==='damage'||e.type==='heal'){
      at=e.kind==='반격'?walkEnd+1100/speed:impact;lastImpact=at;duration=Math.max(700,1600/speed);
      if(e.kind==='반격'){
        const source=battle.units.find(u=>u.id===e.sourceId);
        if(source)planned.push({type:'attack',kind:'반격',id:source.id,from:{q:source.q,r:source.r},to:{q:e.q,r:e.r},element:source.element,start:now+walkEnd+800/speed,duration:650/speed});
      }
    }else if(e.type==='down')at=lastImpact;
    else if(e.type==='capture')at=walkEnd+(attack||spell?1500/speed:0);
    planned.push({...e,start:now+at,duration});
  }
  return planned.sort((a,b)=>a.start-b.start);
}

export function sampleMove(event,now,point,reduced=false){
  const path=event.path?.length>1?event.path:[event.from,event.to];
  const progress=Math.max(0,Math.min(1,(now-event.start)/event.duration));
  const step=Math.min(path.length-2,Math.floor(progress*(path.length-1))),fraction=progress===1?1:progress*(path.length-1)-step;
  const from=path[step],to=path[step+1],a=point(from),b=point(to);
  const jump=to.warp||reduced,k=jump?(fraction<1?0:1):fraction;
  return {x:a.x+(b.x-a.x)*k,y:a.y+(b.y-a.y)*k,cell:k<.5?from:to,from,to,moving:progress<1};
}

export function overlaps(a,b,gap=3){return a.x<b.x+b.width+gap&&a.x+a.width+gap>b.x&&a.y<b.y+b.height+gap&&a.y+a.height+gap>b.y;}
// Prefer a nearby free slot. Dense, zoomed-out views may omit a badge rather than overlap it.
export function placeLabel(anchor,width,height,occupied,bounds){
  for(const dy of [0,-22,22,-44,44,-66,66,-88,88])for(const dx of [0,-24,24,-48,48,-72,72]){
    const rect={x:Math.max(bounds.x,Math.min(bounds.x+bounds.width-width,anchor.x-width/2+dx)),y:anchor.y+dy,width,height};
    if(rect.y<bounds.y||rect.y+height>bounds.y+bounds.height||occupied.some(r=>overlaps(rect,r)))continue;
    occupied.push(rect);return rect;
  }
  return null;
}
