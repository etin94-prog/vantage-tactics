// Move the existing controls, rather than maintaining a second battle UI.
export function initMobileUI({onClose}) {
  const find=selector=>document.querySelector(selector);
  const media=matchMedia('(max-width: 960px)');
  const sheet=find('#mobile-sheet'), body=find('#mobile-sheet-body');
  const actions=find('#action-bar'), resources=find('#mobile-resources'),report=find('#combat-report');
  const reportHome=report.parentElement;
  const range=find('#range-panel'),rangeHome=document.createComment('range panel home');
  range.before(rangeHome);
  const actionHome=actions.parentElement, resourceHome=resources.parentElement;
  let mounted=[], opener=null;
  function restore(){for(const {node,marker} of mounted){marker.replaceWith(node);}mounted=[];}
  function close(){restore();if(sheet.open)sheet.close();}
  function open(kind){
    if(!media.matches)return;
    close();opener=document.activeElement;
    const definitions={unit:['유닛 상세',['#unit-panel']],summons:['정령 선택',['.summon-panel']],info:['전황과 기록',['.left-panel','.journal']],menu:['게임 메뉴',['#mobile-menu']]};
    const [title,selectors]=definitions[kind];
    find('#mobile-sheet-title').textContent=title;
    for(const selector of selectors){const node=find(selector),marker=document.createComment('mobile panel home');node.before(marker);mounted.push({node,marker});body.append(node);}
    sheet.dataset.kind=kind;sheet.showModal();
  }
  sheet.addEventListener('close',()=>{if(sheet.open)return;restore();opener?.focus();onClose();});
  sheet.addEventListener('cancel',event=>{event.preventDefault();close();});
  find('#mobile-sheet-close').onclick=close;
  find('#fullscreen-help').addEventListener('close',onClose);
  sheet.addEventListener('click',event=>{if(event.target===sheet){const r=sheet.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)close();}});
  document.querySelectorAll('[data-mobile-panel]').forEach(button=>button.onclick=()=>open(button.dataset.mobilePanel));
  document.querySelectorAll('[data-menu-target]').forEach(button=>button.onclick=()=>{close();find('#'+button.dataset.menuTarget).click();});
  function layout(){close();if(media.matches){find('.field-top').prepend(range);find('#mobile-unit-summary').after(report);find('#mobile-action-slot').append(actions);find('#mobile-resource-slot').append(resources);}else{rangeHome.after(range);reportHome.prepend(report);actionHome.append(actions);resourceHome.append(resources);}}
  media.addEventListener('change',layout);layout();
  return {open,close,get active(){return media.matches;},get isOpen(){return sheet.open||find('#fullscreen-help').open;}};
}
