import { V2_ACTIONS } from './v2-reference.js';
// Legacy custom spells remain available to imported/custom scenarios.
export const SPELLS=Object.fromEntries([
 ['v2-blitz','브릿츠',4,4,'damage','wind',{ignoreSight:true}],
 ['flame','플레임',4,3,'damage','fire',{power:2}],['medicine','메디슨',3,2,'heal','neutral',{amount:2}],
 ['shield','포스 쉴드',4,0,'buff','neutral',{status:'shield',duration:3}],['ice-blast','아이스 블래스트',5,3,'damage','water',{delay:40,power:2}],
 ['holy-light','홀리 라이트',6,4,'damage','wind',{power:3}],['great-cure','그레이트 큐어',5,3,'heal','neutral',{amount:3,cleanse:true}],
 ['wind-slash','윈드 슬래시',5,3,'damage','wind',{shape:'line',power:1}],['earthquake','어스 퀘이크',6,0,'damage','earth',{radius:1,power:2,selfArea:true}],
 ['thrust','레이피어 쓰러스트',4,2,'damage','neutral',{physical:true,ignoreDefense:.3}],['command','커맨드 오더',6,4,'command','neutral',{}],
 ['meteor','메테오 폴',8,5,'damage','fire',{radius:1,power:3}],['blizzard','블리자드',7,4,'damage','water',{radius:1,status:'freeze',duration:1}],
 ['poison-mist','포이즌 미스트',5,4,'status','neutral',{status:'poison',duration:3}],['thunderbolt','썬더볼트',6,4,'damage','wind',{power:4}],
 ['sanctuary','생추어리',6,0,'buff','neutral',{status:'sanctuary',duration:2,allAllies:true}],['divine-heal','디바인 힐',4,4,'heal','neutral',{amount:4}],
 ['lullaby','자장가',6,3,'status','neutral',{status:'sleep',duration:1,radius:1}],['sonic-boom','소닉 붐',5,4,'damage','neutral',{power:2}],
 ['hide','쉐도우 하이드',4,0,'buff','neutral',{status:'hidden',duration:1}],['poison-dagger','포이즌 대거',3,1,'damage','neutral',{physical:true,status:'poison',duration:3,silence:2}],
 ['sniping','스나이핑',5,5,'damage','neutral',{physical:true,ignoreHeight:true,power:3}],['trap','바인드 트랩',4,3,'trap','earth',{duration:2}],
 ['qi-blast','기공파',4,3,'damage','neutral',{shape:'line',power:2}],['chakra','차크라',3,0,'heal','neutral',{amount:2,cleanse:true}],
 ['war-cry','워 크라이',5,0,'status','neutral',{radius:2,selfArea:true,status:'weaken',duration:2,delay:30}],['rage','블러드 레이지',4,0,'buff','neutral',{status:'rage',duration:2}],
 ['blink','블링크',5,4,'blink','neutral',{}],['pulse','스피릿 펄스',6,4,'damage','neutral',{ignoreDefense:1}],
 ['decoy','환영분신',6,2,'decoy','neutral',{}],['shuriken-storm','수리검 난사',5,3,'damage','neutral',{shape:'fan',physical:true}],
 ['earth-bash','어스 배쉬',5,1,'damage','earth',{physical:true,status:'stun',duration:1,knockback:true}],['drain','소울 드레인',6,3,'damage','neutral',{drain:true,power:1}],
 ['charm','참',7,3,'charm','neutral',{duration:1}],['healing','힐링',0,4,'heal','water',{amount:3}],
 ['armageddon','카오스 아마게돈',12,5,'damage','fire',{radius:2,power:3}],['dispel','앱솔루트 디스펠',8,4,'dispel','neutral',{radius:1}],
].map(([id,name,cost,range,kind,element,extra])=>[id,{id,name,cost,range,kind,element,...extra}]));
export const MASTER_SPELLS={fighter:['flame','medicine'],knight:['shield','ice-blast'],paladin:['holy-light','great-cure'],swordsman:['wind-slash','earthquake'],duke:['thrust','command'],sorcerer:['meteor','blizzard'],witch:['poison-mist','thunderbolt'],sister:['sanctuary','divine-heal'],bard:['lullaby','sonic-boom'],thief:['hide','poison-dagger'],ranger:['sniping','trap'],monk:['qi-blast','chakra'],beast:['war-cry','rage'],spirit:['blink','pulse'],shadow:['decoy','shuriken-storm'],savage:['earth-bash'],nightmare:['drain'],fraulein:['charm'],'gid-kahn':['armageddon','dispel'],melet:['meteor','blizzard','thunderbolt']};
export const STATUS_NAMES={poison:'중독',silence:'침묵',sleep:'수면',freeze:'동결',stun:'기절',root:'속박',shield:'방어 +2',sanctuary:'마방 +4',rage:'공격 +4 / 방어 -3',weaken:'공격 -2',hidden:'은신',charm:'매혹'};
export const v2SpellId=index=>index===31?'v2-blitz':`v2-${index}`;
const v2SpellNames={10:'업타이드',11:'다운타이드',12:'배니시',13:'블레스',14:'메딕',15:'콘쥬레이트',20:'썬더',21:'인퍼널',22:'리커버리',23:'큐어',24:'힐',25:'실버리',26:'프리즈',27:'그레네이드',28:'익스플로전',29:'메딕',30:'머스톰',31:'브릿츠',32:'디스트럭션',33:'아이스베인'};
for(const a of V2_ACTIONS.filter(a=>a.sourceIndex>=10&&a.sourceIndex<=15||a.sourceIndex>=20)){
  const id=v2SpellId(a.sourceIndex),kind=({0:'damage',1:'heal',2:'status',3:'cleanse',4:'tide',5:'heal'})[a.effectType];
  SPELLS[id]={...a,id,name:v2SpellNames[a.sourceIndex],kind,element:a.sourceIndex<20?'neutral':'caster',
    power:a.power,amount:a.sourceIndex===13?1:a.power,allAllies:a.sourceIndex===13,natialsOnly:a.sourceIndex===13,
    selfArea:a.trajectory===4,friendlyFire:kind==='damage'&&a.radius>0,ignoreSight:[3,5].includes(a.trajectory),
    status:kind==='status'?(a.sourceIndex===26?'freeze':'petrify'):undefined,durationMinutes:kind==='status'?120:undefined,
    tideDelta:a.sourceIndex===10?2:-2,duration:kind==='tide'?120:undefined,verified:'static EXE: cost/range/trajectory/damage/healing; status/tide effects partly provisional'};
}
STATUS_NAMES.petrify='석화';
