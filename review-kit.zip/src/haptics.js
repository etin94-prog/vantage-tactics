
export class GameHaptics {
  constructor({enabled=true,nav=navigator,doc=document}={}){this.enabled=enabled;this.nav=nav;this.doc=doc;this.lastPulse=-Infinity;}
  get supported(){return typeof this.nav.vibrate==='function';}
  setEnabled(value){this.enabled=!!value;if(!this.enabled)this.cancel();}
  cancel(){if(this.supported)try{this.nav.vibrate(0);}catch{/* Optional device feature. */}}
  pulse(pattern=25,now=performance.now()){
    if(!this.enabled||!this.supported||this.doc.hidden||this.nav.userActivation?.hasBeenActive===false||now-this.lastPulse<100)return false;
    try{const accepted=this.nav.vibrate(pattern);if(accepted)this.lastPulse=now;return accepted;}catch{return false;}
  }
  impact(event,now=performance.now()){
    if(event.type!=='damage'||!(event.amount>0))return false;
    return this.pulse(event.hpAfter===0?[35,45,55]:event.kind==='반격'?30:20,now);
  }
}
