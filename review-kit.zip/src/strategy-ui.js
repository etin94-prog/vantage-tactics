import { STRATEGIES, OPPONENTS, runStrategyBenchmark, summarizeMatches } from './strategy-lab.js';

export function mountStrategyLab({select,build,adopt,replay,download}){
  let report=null,running=false,stop=false;
  const label=(items,id)=>items.find(x=>x[0]===id)?.[1]||id;
  const statusLabel={win:'승리',loss:'패배',limit:'행동 제한',error:'오류',cancelled:'중단'};
  const render=()=>{
    const summary=summarizeMatches(report.results,report.planned);
    select('#strategy-progress').textContent=`${summary.recorded} / ${summary.planned}판 · 승 ${summary.wins} / 패 ${summary.losses} / 제한 ${summary.limits} / 오류 ${summary.errors} / 중단 ${summary.cancelled} · 승률 ${summary.winRate===null?'—':(summary.winRate*100).toFixed(1)+'%'} (승리 ÷ 승·패·제한)`;
    const body=select('#strategy-rows');body.replaceChildren();
    report.results.forEach((r,i)=>{
      const row=document.createElement('tr');
      for(const text of [r.stage,label(STRATEGIES,r.strategy),label(OPPONENTS,r.opponent),r.seed,statusLabel[r.status],r.actions,r.stones.join(' : ')]){const td=document.createElement('td');td.textContent=text;row.append(td);}
      const td=document.createElement('td');
      for(const [text,fn] of [['전장 열기',()=>{adopt(replay(r.bundle,build).session);select('#status').textContent=`자동 대전 ${i+1}번 · ${statusLabel[r.status]} · 마지막 상태. 처음으로 버튼으로 시작 상태를 볼 수 있습니다.`;}],['재현 JSON',()=>download(`strategy-${r.stage}-${r.strategy}-${r.opponent}-${r.seed}.json`,JSON.stringify(r.bundle,null,2))]]){
        const button=document.createElement('button');button.textContent=text;button.disabled=running;button.onclick=()=>{try{fn();}catch(e){select('#strategy-progress').textContent=e.message;}};td.append(button);
      }
      row.append(td);body.append(row);
    });
    const groups=report.groups||[];
    select('#strategy-groups').textContent=groups.map(g=>`${label(STRATEGIES,g.strategy)} / ${label(OPPONENTS,g.opponent)}: 승 ${g.wins}, 패 ${g.losses}, 제한 ${g.limits}, 오류 ${g.errors}, 승률 ${g.winRate===null?'—':(g.winRate*100).toFixed(1)+'%'}`).join('\n');
  };
  select('#strategy-stop').onclick=()=>{stop=true;select('#strategy-progress').textContent='현재 행동을 마친 뒤 중단합니다. 완료된 결과는 보존합니다.';};
  select('#strategy-run').onclick=async()=>{
    if(running)return;stop=false;running=true;report=null;
    const controls=[...document.querySelectorAll('button,input,select,textarea')],disabled=controls.map(c=>c.disabled);
    const input={stages:select('#strategy-scope').value==='all'?Array.from({length:30},(_,i)=>i):[Number(select('#stage').value)],strategies:select('#strategy-policy').value==='all'?STRATEGIES.map(s=>s[0]):[select('#strategy-policy').value],opponents:select('#strategy-opponent').value==='both'?OPPONENTS.map(s=>s[0]):[select('#strategy-opponent').value],seeds:Array.from({length:Math.max(1,Math.min(10,Number(select('#strategy-repeats').value)||1))},(_,i)=>i+1),master:select('#master').value,level:Number(select('#level').value),loadout:select('#strategy-loadout').value,maxActions:Number(select('#strategy-limit').value)};
    controls.forEach(c=>c.disabled=true);select('#strategy-stop').disabled=false;select('#strategy-progress').textContent='자동 대전 준비 중…';
    try{report=await runStrategyBenchmark(input,build,{cancelled:()=>stop,yield:()=>new Promise(r=>setTimeout(r,0)),onMatch:(r,p)=>{report=p;render();}});}
    catch(e){select('#strategy-progress').textContent='실행 오류: '+e.message;}
    finally{running=false;controls.forEach((c,i)=>c.disabled=disabled[i]);select('#strategy-stop').disabled=true;select('#strategy-export').disabled=!report;if(report)render();}
  };
  select('#strategy-export').onclick=()=>{
    const summary={...report,results:report.results.map(({bundle,...r})=>({...r,finalHash:bundle.finalHash}))};
    download('vantage-strategy-results.json',JSON.stringify(summary,null,2));
  };
}
