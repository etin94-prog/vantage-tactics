import { MASTERS, BOSSES, SUMMONS, ELEMENTS, TERRAIN, LIMITS, ACTION_COSTS, masterStats } from './data.js';
import { SPELLS, STATUS_NAMES } from './spells.js';
import { actionMinutes, timePeriod, periodBrightness, V2_RULES } from './rules.js';
import { MinHeap, DIRECTIONS, key, distance, direction, reachable, findPath } from './hex.js';
import { validateStage } from './maps.js';

export class Battle {
  constructor(stage,masterId='fighter',options={}) {
    this.stage=structuredClone(validateStage(stage));this.tiles=new Map(this.stage.tiles.map(t=>[key(t),t]));
    this.tide=null;this.units=[];this.stones=this.stage.manaStones.map(s=>({...s,owner:s.owner??null}));this.mana=[LIMITS.startMana,LIMITS.startMana];
    this.time=0;this.turn=0;this.round=[0,0];this.nextId=1;this.activeId=null;this.winner=null;this.log=[];this.events=[];this.traps=[];this.queue=new MinHeap();this.moved=false;this.moveCost=0;this.moveUndo=null;this.difficulty=options.difficulty||'normal';this.custom=options.custom||{};
    this.unlocked=options.unlocked||SUMMONS.filter(s=>s.unlockAfter<(stage.id||1)).map(s=>s.id);
    this.extraSpells=options.extraSpells||[];
    this.addUnit(masterId,0,{...stage.playerMasterStart,level:options.playerLevel||stage.playerMasterStart.level||1},true);
    this.addUnit(options.enemyMaster||stage.enemyMasterStart.classId||stage.enemyMaster||'swordsman',1,stage.enemyMasterStart,true);
    for(const ally of stage.enemyAllies||[])this.addUnit(ally.classId,1,ally,true,40);
    this.mana=[this.maxMana(0),this.maxMana(1)];
    this.note('원정',`${stage.name} · 전투를 시작합니다.`,'system');this.advance();
  }
  get active(){return this.units.find(u=>u.id===this.activeId&&u.hp>0);}
  canUndoMove(){const s=this.moveUndo;return !!(this.moved&&s&&this.winner===null&&this.active?.id===s.id&&this.turn===s.turn&&this.time===s.time);}
  undoMove(){
    if(!this.canUndoMove())return false;
    const u=this.active,s=this.moveUndo,from={q:u.q,r:u.r};
    Object.assign(u,structuredClone(s.unit));this.traps=structuredClone(s.traps);this.log=structuredClone(s.log);
    this.moved=false;this.moveCost=0;this.moveUndo=null;
    this.events=[{type:'move',id:u.id,from,to:{q:u.q,r:u.r}}];return true;
  }
  get living(){return this.units.filter(u=>u.hp>0);}
  period(){return timePeriod(this.clockMinutes());}
  brightness(){return this.stage.fixedBrightness??periodBrightness(this.clockMinutes());}
  setFacing(facing){const u=this.active;if(!u||this.winner!==null||!Number.isInteger(facing)||facing<0||facing>5)return false;u.facing=facing;return true;}
  gainSat(u,amount){
    if(!u||u.master||u.hp<=0||amount<=0)return;
    u.sat=Math.max(0,u.sat||0)+Math.floor(amount);let next=u.level||1;
    while(next<3&&u.sat>=V2_RULES.satThresholds[next])next++;
    if(next===u.level)return;
    u.level=next;const row=u.levels[next-1];
    ['attack','defense','magicAttack','magicDefense','speed','move'].forEach((name,i)=>u[name]=row[i]);
    this.note('정령 성장',`${u.name}: Lv.${next} · SAT ${u.sat}`,'good');
  }
  inflict(attacker,target,amount){const actual=Math.min(target.hp,Math.max(0,amount));const killed=target.hp>0&&actual>=target.hp;this.hurt(target,actual);if(attacker.team!==target.team){const advantage=ELEMENTS[attacker.element]?.beats===target.element?0.8:ELEMENTS[target.element]?.beats===attacker.element?1.25:1;this.gainSat(attacker,(actual*10+(killed?80:0))*advantage);}return actual;}
  changeTide(delta,duration=120){
    const expiresAt=this.tide?.delta===delta&&this.tide.expiresAt>this.time?this.tide.expiresAt+duration:this.time+duration;
    this.tide={delta,expiresAt};this.applyTide();this.note('수위 변화',`${delta>0?'상승':'하강'} · ${expiresAt-this.time}분 지속`,'system');
  }
  applyTide(){
    const water=this.stage.tiles.filter(t=>[6,7,8,9,13,14,15].includes(t.terrainCode));
    const baseline=water.length?water.map(t=>t.baseElevation??t.elevation).sort((a,b)=>a-b)[Math.floor(water.length/2)]:null;
    for(const t of this.stage.tiles){
      t.baseTerrain??=t.terrain;t.baseElevation??=t.elevation;t.terrain=t.baseTerrain;t.elevation=t.baseElevation;
      if(!this.tide||baseline===null)continue;
      if(t.terrainCode===6){t.elevation=Math.max(0,t.baseElevation+this.tide.delta);continue;}
      if(['void','wall','marsh','swamp'].includes(t.baseTerrain))continue;
      const wasWater=['water','deep_water'].includes(t.baseTerrain),ground=wasWater?(t.secondaryHeight??t.baseElevation-1):t.baseElevation;
      const surface=baseline+this.tide.delta,depth=surface-ground;
      if(depth>0){t.terrain=depth>=2?'deep_water':'water';t.elevation=Math.max(0,surface);}
      else if(wasWater){t.terrain=this.stones.some(s=>key(s)===key(t))?'stone':'grass';t.elevation=Math.max(0,ground);}
    }
  }
  expireWorld(){
    if(this.tide&&this.time>=this.tide.expiresAt){this.tide=null;this.applyTide();this.note('수위 복귀','원래 수위로 돌아왔습니다.','system');}
    for(const u of this.living)for(const [id,status] of Object.entries(u.statuses))if(status.expiresAt!==undefined&&status.expiresAt<=this.time)delete u.statuses[id];
  }
  definition(id,master=false){const base=(master?[...MASTERS,...BOSSES]:SUMMONS).find(d=>d.id===id);if(!base)throw new Error(`알 수 없는 캐릭터: ${id}`);const c=this.custom[id]||{};return {...base,...Object.fromEntries(['name','color','sprite','animation'].filter(k=>c[k]!==undefined).map(k=>[k,c[k]]))};}
  addUnit(type,team,pos,master=false,time=null){const d=this.definition(type,master);if(master)Object.assign(d,masterStats(d,pos.level||1));if(pos.name)d.name=pos.name;time??=this.time+actionMinutes(d.speed,15);const u={...d,type,id:this.nextId++,team,q:pos.q,r:pos.r,hp:d.hp,maxHp:d.hp,master,level:master?(pos.level||1):1,sat:0,sourceFacing:pos.sourceFacing,facing:pos.sourceFacing===undefined?(team===0?0:3):(pos.sourceFacing+3)%6,nextTime:time,statuses:{}};this.units.push(u);this.queue.push({id:u.id,time});return u;}
  note(title,text,type='action'){this.log.unshift({turn:this.turn,time:this.time,title,text,type});this.log=this.log.slice(0,70);}
  at(pos){return this.units.find(u=>u.hp>0&&key(u)===key(pos));}
  owned(team){return this.stones.filter(s=>s.owner===team).length;}
  maxMana(team){return this.units.find(u=>u.master&&u.team===team)?.maxMana||LIMITS.startMana;}
  income(team){const master=this.living.find(u=>u.master&&u.team===team);return master?(2+this.owned(team))*this.stat(master,'magicAttack'):0;}
  clockMinutes(){return (this.stage.startMinutes||0)+Math.floor(this.time/LIMITS.ticksPerMinute);}
  settleClock(nextTime){const start=this.stage.startMinutes||0,period=LIMITS.economyMinutes;const before=Math.floor((start+this.time/LIMITS.ticksPerMinute)/period),after=Math.floor((start+nextTime/LIMITS.ticksPerMinute)/period);for(let i=before;i<after;i++)for(const team of [0,1])this.economy(team);}
  upkeep(team){return this.living.filter(u=>(u.originalTeam??u.team)===team&&!u.master).reduce((n,u)=>n+(u.upkeep||0),0);}
  unlockedFor(u,s){return u.team===0?this.unlocked.includes(s.id):(this.stage.enemyRoster?.includes(s.id)??(s.unlockAfter<(this.stage.id||1)));}
  hasStatus(u,id){const status=u?.statuses?.[id];return !!status&&(status.expiresAt!==undefined?status.expiresAt>this.time:status.remaining>0);}
  setStatus(u,id,duration){if(u.hp>0)u.statuses[id]={remaining:duration,appliedTurn:this.turn};}
  stat(u,id){let value=u[id]||0;if(!u.master&&u.dayNight&&['attack','defense','magicAttack','magicDefense'].includes(id)){const light=this.brightness(),favored=u.dayNight===1?light===1:light===0,opposed=u.dayNight===1?light===0:light===1;value+=favored?V2_RULES.dayBonus:opposed?-V2_RULES.nightPenalty:0;}if(id==='attack')value+=(this.hasStatus(u,'rage')?4:0)-(this.hasStatus(u,'weaken')?2:0);if(id==='defense')value+=(this.hasStatus(u,'shield')?2:0)-(this.hasStatus(u,'rage')?3:0);if(id==='magicDefense')value+=this.hasStatus(u,'sanctuary')?4:0;return Math.max(0,value);}
  visible(pos,team=0){return !this.stage.vision||this.living.some(u=>u.team===team&&distance(u,pos)<=this.stage.vision);}
  visibleUnit(u,team=0){return u.team===team||this.visible(u,team)&&!this.hasStatus(u,'hidden');}
  blocked(unit){return new Set(this.living.filter(u=>u.id!==unit.id).map(key));}
  terrainCost(unit){return (t,from)=>{
    if(t.terrain==='void')return Infinity;
    if(t.terrain==='wall')return unit.flying&&t.terrainCode===10?1:Infinity;
    if(unit.flying)return 1;
    const wet=['water','deep_water','marsh'].includes(t.terrain),type=unit.movementType??(unit.aquatic?3:0);
    if(type===2&&!wet||type===0&&wet)return Infinity;
    const rise=t.elevation-(from?.elevation??t.elevation);if(Math.abs(rise)>V2_RULES.maxStep)return Infinity;
    let cost=['sand','snow','forest','marsh','swamp'].includes(t.terrain)?2:1;
    if(type===1&&wet||type===3&&!wet)cost=2;
    return cost+Math.max(0,rise);
  };}
  canLand(unit,t){return !!t&&!['void','wall'].includes(t.terrain)&&!(unit.flying&&['water','deep_water','marsh'].includes(t.terrain))&&Number.isFinite(this.terrainCost(unit)(t,t));}
  reachable(unit=this.active){if(!unit)return {dist:new Map(),parents:new Map()};
    const stop=p=>!unit.flying&&this.living.some(e=>e.team!==unit.team&&distance(e,p)===1);
    const result=reachable(unit,this.hasStatus(unit,'root')?0:unit.move,this.tiles,this.terrainCost(unit),this.blocked(unit),stop);
    for(const k of result.dist.keys())if(!this.canLand(unit,this.tiles.get(k))&&k!==key(unit))result.dist.delete(k);return result;
  }
  capture(u){if(u.isDecoy)return;const s=this.stones.find(s=>key(s)===key(u));if(s&&s.owner!==u.team){s.owner=u.team;this.note('마석 점령',`${u.name}: 마석을 점령했습니다.`,u.team===0?'good':'enemy');this.events.push({type:'capture',q:u.q,r:u.r,team:u.team});}}
  economy(team){const gain=this.income(team),available=this.mana[team]+gain;let fee=this.upkeep(team);const dissolved=[];
    for(const u of this.living.filter(u=>(u.originalTeam??u.team)===team&&!u.master).sort((a,b)=>b.cost-a.cost||b.id-a.id)){if(fee<=available)break;fee-=u.upkeep||0;dissolved.push(u.name);this.hurt(u,u.hp);}
    this.mana[team]=Math.min(this.maxMana(team),Math.max(0,available-fee));this.note('마나 정산',`${team===0?'아군':'적군'} +${gain} 수입 / −${fee} 유지비`,'mana');if(dissolved.length)this.note('강제 소멸',`유지비 부족: ${dissolved.join(', ')} 소멸`,'enemy');
  }
  worldTick(team){this.round[team]++;if(team!==0)return;if(this.stage.theme==='chaos'&&this.round[0]%5===0){const cycle=['grass','water','lava','ice'];for(const t of this.stage.tiles)if(!this.stones.some(s=>key(s)===key(t))&&!this.at(t))t.terrain=cycle[(Math.floor(this.round[0]/5)+t.q+t.r)%4];this.note('차원 변이','원소 지형이 예고된 순서대로 변이했습니다.','system');}}
  advance(){if(this.winner!==null)return;for(let safety=0;safety<1000;safety++){
    let entry;while(this.queue.size){const candidate=this.queue.pop(),u=this.units.find(x=>x.id===candidate.id);if(u?.hp>0&&u.nextTime===candidate.time){entry=candidate;break;}}if(!entry)return;
    this.settleClock(entry.time);this.time=entry.time;this.expireWorld();if(!this.units.some(u=>u.id===entry.id&&u.hp>0))continue;this.activeId=entry.id;this.turn++;this.moved=false;this.moveCost=0;this.moveUndo=null;const u=this.active;
    if(this.hasStatus(u,'hidden')&&u.statuses.hidden.appliedTurn<this.turn)delete u.statuses.hidden;
    if(u.master)this.worldTick(u.team);
    if(this.stones.some(s=>s.owner===u.team&&key(s)===key(u)))u.hp=Math.min(u.maxHp,u.hp+1);
    if(this.hasStatus(u,'poison'))this.hurt(u,1);
    if(u.hp<=0){if(this.winner!==null)return;continue;}
    if(['sleep','freeze','petrify','stun'].some(id=>this.hasStatus(u,id))){this.note('행동 불능',`${u.name}: 상태이상으로 행동을 건너뜁니다.`);this.hazards(u);if(this.winner!==null)return;this.endStatuses(u);if(u.hp>0){u.nextTime=this.time+actionMinutes(u.speed);this.queue.push({id:u.id,time:u.nextTime});}continue;}
    this.events.push({type:'turn',team:u.team});return;
  }throw new Error('턴 스케줄러 안전 한도 초과');}
  endStatuses(u){for(const [id,status] of Object.entries(u.statuses)){if(status.expiresAt!==undefined){if(status.expiresAt<=this.time)delete u.statuses[id];continue;}if(status.appliedTurn===this.turn)continue;if(--status.remaining<=0){delete u.statuses[id];if(id==='charm'){u.team=u.originalTeam;delete u.originalTeam;}}}}
  actionDelay(u,action='attack',moved=this.moved,spell=null){const extra=action==='wait'?0:action==='move'?15:action==='summon'?15:action==='spell'?(spell?.oaExtra??25):(u.attackProfile?.oaExtra??15);return actionMinutes(u.speed,extra,action==='move'?false:moved);}
  hazards(u){const tile=this.tiles.get(key(u));if(tile.terrain==='swamp'||!this.canLand(u,tile))this.hurt(u,3);else if(tile.terrain==='lava'&&u.element!=='fire'&&!u.flying)this.hurt(u,2);}
  finish(action='attack',spell=null){const u=this.active;if(!u||this.winner!==null)return;this.moveUndo=null;this.capture(u);this.hazards(u);if(this.winner!==null)return;this.endStatuses(u);if(u.hp>0){u.nextTime=this.time+this.actionDelay(u,action,this.moved,spell);this.queue.push({id:u.id,time:u.nextTime});}this.activeId=null;this.advance();}
  arrival(u,from){let tile=this.tiles.get(key(u));if(tile.terrain==='ice'&&u.element!=='water'&&!u.flying){const d=DIRECTIONS[direction(from,u)],next={q:u.q+d.q,r:u.r+d.r},nt=this.tiles.get(key(next));if(nt&&!this.at(next)&&Number.isFinite(this.terrainCost(u)(nt,tile))){u.q=next.q;u.r=next.r;tile=nt;this.note('빙판',`${u.name}: 한 칸 미끄러졌습니다.`);}}
    const pair=this.stage.portals?.find(pair=>pair.some(p=>key(p)===key(u)));if(pair){const dest=pair.find(p=>key(p)!==key(u));if(dest&&!this.at(dest)&&Number.isFinite(this.terrainCost(u)(this.tiles.get(key(dest)),tile))){u.q=dest.q;u.r=dest.r;this.note('워프',`${u.name}: 포탈을 통과했습니다.`);}}
    const trap=this.traps.find(t=>key(t)===key(u)&&t.team!==u.team);if(trap){this.setStatus(u,'root',trap.duration);this.traps=this.traps.filter(t=>t!==trap);this.note('덫',`${u.name}: 이동이 봉쇄되었습니다.`);}
  }
  move(pos){const u=this.active;if(!u||this.winner!==null||this.moved||key(pos)===key(u)||u.isDecoy)return false;const paths=this.reachable(u),cost=paths.dist.get(key(pos));if(cost===undefined||this.at(pos))return false;this.moveUndo=structuredClone({id:u.id,turn:this.turn,time:this.time,unit:{q:u.q,r:u.r,facing:u.facing,statuses:u.statuses},traps:this.traps,log:this.log});const from={q:u.q,r:u.r};u.facing=direction(u,pos);u.q=pos.q;u.r=pos.r;this.moved=true;this.moveCost=cost;this.arrival(u,this.tiles.get(paths.parents.get(key(pos)))||from);this.events.push({type:'move',id:u.id,from,to:{q:u.q,r:u.r}});return true;}
  hasSight(a,b){if(a.ignoreSight)return true;const n=distance(a,b);if(n<=1)return true;const ah=this.tiles.get(key(a))?.elevation||0,bh=this.tiles.get(key(b))?.elevation||0;for(let i=1;i<n;i++){const f=i/n,q=a.q+(b.q-a.q)*f,r=a.r+(b.r-a.r)*f;let x=Math.round(q),z=Math.round(r),y=Math.round(-q-r);const dx=Math.abs(x-q),dz=Math.abs(z-r),dy=Math.abs(y+q+r);if(dx>dz&&dx>dy)x=-y-z;else if(dz>dy)z=-x-y;const t=this.tiles.get(`${x},${z}`);if(!t||t.terrain==='wall'||t.elevation>ah+(bh-ah)*f+1)return false;}return true;}
  range(a,b,base=a.range,ignoreHeight=false){const h=(this.tiles.get(key(a))?.elevation||0)-(this.tiles.get(key(b))?.elevation||0);return Math.max(0,base+(base>1&&!ignoreHeight?Math.floor(h/2):0));}
  canAttack(a,b){if(!a||!b)return false;const height=Math.abs((this.tiles.get(key(a))?.elevation||0)-(this.tiles.get(key(b))?.elevation||0));return !!a&&!!b&&!a.isDecoy&&!a.healerOnly&&a.hp>0&&b.hp>0&&a.team!==b.team&&this.visibleUnit(b,a.team)&&distance(a,b)<=this.range(a,b)&&(a.range>1||height<=2)&&this.hasSight(a,b);}
  terrainDefense(unit){const t=this.tiles.get(key(unit));if(this.stones.some(s=>key(s)===key(unit)))return .3;if(t.terrain==='forest')return .2;if(['water','deep_water'].includes(t.terrain))return Math.min(.4,.1*Math.max(1,t.elevation-(t.secondaryHeight??t.elevation-1)));return 0;}
  damage(a,b,magic=false,spell={}){
    const h=(this.tiles.get(key(a))?.elevation||0)-(this.tiles.get(key(b))?.elevation||0),height=magic?0:Math.max(-4,Math.min(4,h));
    const element=spell.element&&spell.element!=='caster'?spell.element:a.element;
    const advantage=ELEMENTS[element]?.beats===b.element?1.5:ELEMENTS[b.element]?.beats===element?0.5:element!=='neutral'&&element===b.element?.trim()?.toLowerCase()?.replace('','')?.toString()?0.75:1;
    const attribute=advantage===1.5?6:advantage===.5?-9:advantage===.75?-4:0;
    const angle=(direction(b,a)-b.facing+6)%6,back=angle===3?2:angle===2||angle===4?1:0;
    const facingBonus=magic?0:angle===0?2:angle===1||angle===5?3:angle===3?6:5;
    const attack=this.stat(a,magic?'magicAttack':'attack')+(spell.power||0);
    const defense=this.stat(b,magic?'magicDefense':'defense')*(1+this.terrainDefense(b));
    // Attribute/facing offsets have published measurements; final conversion is provisional.
    const amount=Math.max(1,Math.min(10,Math.floor((attack-defense+attribute+height+facingBonus)/2)+1));
    return {amount,advantage,height,back,attribute};
  }
  hurt(u,amount){if(u.hp<=0)return;const actual=Math.min(u.hp,amount);u.hp=Math.max(0,u.hp-amount);delete u.statuses.sleep;this.events.push({type:'damage',id:u.id,q:u.q,r:u.r,amount:actual});if(u.hp===0){this.events.push({type:'down',unit:structuredClone(u),q:u.q,r:u.r});this.note('전투 불능',`${u.name}: 전투 불능`,u.team===1?'good':'enemy');if(u.master&&!this.living.some(x=>x.master&&x.team===u.team)){this.winner=1-u.team;this.note(this.winner===0?'승리':'패배',this.winner===0?'적 소환사를 모두 제압했습니다.':'아군 소환사가 쓰러졌습니다.','system');}}}
  attack(targetId){const u=this.active,t=this.units.find(x=>x.id===targetId);if(this.winner!==null||!this.canAttack(u,t))return false;this.moveUndo=null;u.facing=direction(u,t);const d=this.damage(u,t,u.magicAttackBasic);const victims=this.living.filter(x=>x.team!==u.team&&(x.id===t.id||u.attackRadius&&distance(x,t)<=u.attackRadius||u.attackFan&&distance(x,u)<=1&&[(u.facing+5)%6,u.facing,(u.facing+1)%6].includes(direction(u,x))));
    this.events.push({type:'attack',id:u.id,from:{q:u.q,r:u.r},to:{q:t.q,r:t.r},element:u.element});for(const v of victims){this.inflict(u,v,this.damage(u,v,u.magicAttackBasic).amount);if(u.attackStatus&&v.hp>0)this.setStatus(v,u.attackStatus,2);}
    this.note('공격',`${u.name} → ${t.name} · ${d.amount} 피해${d.advantage>1?' / 상성 우위':''}${d.back?' / 측후방':''}`);
    if(this.winner===null&&t.hp>0&&distance(u,t)===1&&d.back!==2&&this.canAttack(t,u)&&!['freeze','petrify','sleep','stun'].some(s=>this.hasStatus(t,s))){const counter=this.damage(t,u,t.magicAttackBasic);this.inflict(t,u,counter.amount);this.note('반격',`${t.name} → ${u.name} · ${counter.amount} 반격 피해`);}
    if(!this.active&&this.winner===null)this.advance();else this.finish('attack');return true;
  }
  canSummon(type,u=this.active){const d=SUMMONS.find(s=>s.id===type);return !!(u?.master&&d&&this.unlockedFor(u,d)&&!this.hasStatus(u,'silence')&&this.mana[u.team]>=d.cost&&this.living.filter(s=>s.team===u.team&&!s.master).length<LIMITS.maxSummons);}
  summonTiles(u=this.active,type=null){if(!u?.master)return [];const d=type?this.definition(type):{flying:true};return this.stage.tiles.filter(t=>distance(t,u)<=LIMITS.summonRadius&&distance(t,u)>0&&!this.at(t)&&this.canLand(d,t)&&this.hasSight(u,t));}
  summon(type,pos,finish=true){const u=this.active;if(this.winner!==null||!this.canSummon(type,u)||!this.summonTiles(u,type).some(t=>key(t)===key(pos)))return false;const d=this.definition(type);this.moveUndo=null;this.mana[u.team]-=d.cost;const created=this.addUnit(type,u.team,pos);this.events.push({type:'summon',id:u.id,q:pos.q,r:pos.r,element:d.element});this.note('소환',`${u.name} → ${d.name} 소환`,u.team===0?'good':'enemy');if(finish)this.finish('summon');return true;}
  availableSpells(u=this.active){if(!u||u.isDecoy)return [];const ids=[...(u.spells||[]),...(u.master?(u.team===0?this.extraSpells:this.stage.enemySpells||[]):[])];return [...new Set(ids)].map(id=>SPELLS[id]).filter(Boolean);}
  spellTargets(u=this.active,id=null){if(!u)return [];const spell=id?SPELLS[id]:this.availableSpells(u)[0];if(!spell)return [];
    if(spell.selfArea||spell.allAllies||spell.kind==='tide'||spell.range===0)return [u];
    const inRange=t=>{const h=Math.abs((this.tiles.get(key(u))?.elevation||0)-(this.tiles.get(key(t))?.elevation||0));const range=spell.sourceIndex!==undefined&&spell.trajectory!==0?Math.max(0,spell.range-Math.floor(h/2)):spell.range;return distance(u,t)<=range&&(spell.trajectory!==0||h<=2)&&(spell.ignoreSight||this.hasSight(u,t));};
    if(spell.kind==='damage'&&spell.radius)return this.stage.tiles.filter(t=>t.terrain!=='void'&&inRange(t));
    return this.living.filter(t=>{const ally=['heal','cleanse','command'].includes(spell.kind);if(ally?t.team!==u.team:t.team===u.team)return false;if(spell.natialsOnly&&t.master)return false;if(spell.kind==='heal'&&t.hp===t.maxHp)return false;if(spell.kind==='cleanse'&&!Object.keys(t.statuses).some(id=>this.hasStatus(t,id)))return false;return inRange(t);});
  }
  affected(u,spell,pos){if(spell.allAllies)return this.living.filter(t=>t.team===u.team&&(!spell.natialsOnly||!t.master));if(spell.selfArea||spell.radius)return this.living.filter(t=>(spell.friendlyFire||t.team!==u.team)&&(!spell.selfArea||t.id!==u.id)&&distance(t,pos)<=spell.radius&&Math.abs((this.tiles.get(key(t))?.elevation||0)-(this.tiles.get(key(pos))?.elevation||0))<=2*spell.radius&&(spell.ignoreSight||this.hasSight(pos,t)));const target=this.at(pos);return target?[target]:[];}
  reschedule(u,time){u.nextTime=Math.max(this.time+1,time);this.queue.push({id:u.id,time:u.nextTime});}
  cast(id,pos){const u=this.active,s=SPELLS[id];if(!u||this.winner!==null||!s||!this.availableSpells(u).some(x=>x.id===id)||this.hasStatus(u,'silence')||this.mana[u.team]<s.cost||!this.spellTargets(u,id).some(t=>key(t)===key(pos)))return false;
    if(s.kind==='decoy'&&this.living.filter(x=>x.team===u.team&&!x.master).length>=LIMITS.maxSummons)return false;
    this.moveUndo=null;this.mana[u.team]-=s.cost;if(s.kind==='tide')this.changeTide(s.tideDelta,s.duration);const victims=this.affected(u,s,pos);let drained=0;
    if(s.kind==='blink'){const from={q:u.q,r:u.r};u.q=pos.q;u.r=pos.r;this.arrival(u,from);}
    if(s.kind==='trap')this.traps.push({q:pos.q,r:pos.r,team:u.team,duration:s.duration});
    if(s.kind==='decoy'){const clone={...structuredClone(u),q:pos.q,r:pos.r,id:this.nextId++,name:`${u.name} 분신`,master:false,isDecoy:true,hp:1,maxHp:1,attack:0,move:0,upkeep:0,cost:0,spells:[],statuses:{},nextTime:this.time+u.delay};this.units.push(clone);this.queue.push({id:clone.id,time:clone.nextTime});}
    for(const t of victims){if(s.kind==='heal'){const amount=Math.min(s.amount,t.maxHp-t.hp);t.hp+=amount;this.gainSat(u,amount*10);if(s.cleanse)for(const status of ['poison','silence','sleep','freeze','stun','root','weaken'])delete t.statuses[status];this.events.push({type:'heal',q:t.q,r:t.r,amount});}
      if(s.kind==='damage'){const amount=this.damage(u,t,!s.physical,s).amount;drained+=Math.min(t.hp,amount);this.inflict(u,t,amount);}
      if(s.kind==='cleanse'){for(const status of ['poison','silence','sleep','freeze','petrify','stun','root','weaken'])delete t.statuses[status];this.gainSat(u,10);}if(s.status){if(s.durationMinutes){if(!this.hasStatus(t,s.status))this.gainSat(u,10);t.statuses[s.status]={expiresAt:this.time+s.durationMinutes};}else this.setStatus(t,s.status,s.duration);}if(s.silence)this.setStatus(t,'silence',s.silence);if(s.delay&&t.hp>0&&t.id!==u.id)this.reschedule(t,t.nextTime+s.delay);
      if(s.kind==='command')this.reschedule(t,this.time+Math.floor((t.nextTime-this.time)*.6));
      if(s.kind==='charm'&&t.hp>0){t.originalTeam??=t.team;t.team=u.team;this.setStatus(t,'charm',1);}
      if(s.kind==='dispel')for(const status of ['shield','sanctuary','rage','hidden'])delete t.statuses[status];
      if(s.knockback&&t.hp>0){const d=DIRECTIONS[direction(u,t)],dest={q:t.q+d.q,r:t.r+d.r},tile=this.tiles.get(key(dest));if(tile&&!this.at(dest)&&Number.isFinite(this.terrainCost(t)(tile,this.tiles.get(key(t))))){t.q=dest.q;t.r=dest.r;this.capture(t);}}
    }
    if(s.drain)u.hp=Math.min(u.maxHp,u.hp+drained);this.events.push({type:'spell',id:u.id,q:pos.q,r:pos.r,element:s.element});this.note(s.name,`${u.name}: ${s.name} 시전`);if(!this.active&&this.winner===null)this.advance();else this.finish('spell',s);return true;
  }
  spell(pos,id=null){const s=id||this.availableSpells().find(s=>['damage','status'].includes(s.kind))?.id;return s?this.cast(s,pos):false;}
  heal(targetId){const t=this.units.find(x=>x.id===targetId),s=this.availableSpells().find(s=>s.kind==='heal'&&this.spellTargets(this.active,s.id).some(p=>p.id===targetId));return !!(s&&t&&this.cast(s.id,t));}
  wait(){if(!this.active||this.winner!==null)return false;this.note('대기',`${this.active.name}: 다음 기회를 기다립니다.`);this.finish('wait');return true;}
  order(count=8){const h=new MinHeap();for(const u of this.living)h.push({id:u.id,time:u.id===this.activeId?this.time:u.nextTime});const result=[];while(h.size&&result.length<count){const e=h.pop(),u=this.units.find(x=>x.id===e.id);result.push({...e,unit:u});h.push({id:e.id,time:e.time+this.actionDelay(u,'attack',false)});}return result;}
  aiTurn(){const u=this.active;if(!u||this.winner!==null)return;if(u.isDecoy){this.wait();return;}let enemies=this.living.filter(t=>t.team!==u.team&&this.visibleUnit(t,u.team));
    const tryMagic=()=>{let best=null,bestScore=0;for(const s of this.availableSpells(u)){if(this.mana[u.team]<s.cost||this.hasStatus(u,'silence'))continue;for(const p of this.spellTargets(u,s.id)){let score=0;const affected=this.affected(u,s,p);
        for(const t of affected){if(s.kind==='heal')score+=Math.min(s.amount,t.maxHp-t.hp)*(t.master?3:1.3);if(s.kind==='damage'){const dmg=this.damage(u,t,!s.physical,s).amount;score+=(t.team===u.team?-2:1)*(Math.min(dmg,t.hp)+(t.master?3:0)+(dmg>=t.hp?8:0));}if(s.kind==='cleanse')score+=Object.keys(t.statuses).length*8;if(s.kind==='status'&&!this.hasStatus(t,s.status))score+=s.status==='poison'?3:5;if(s.kind==='charm')score+=t.master?0:8;if(s.kind==='command'&&t.id!==u.id)score+=3;if(s.kind==='dispel')score+=Object.keys(t.statuses).length*2;}
        if(s.kind==='buff'&&!this.hasStatus(u,s.status)&&enemies.some(t=>distance(u,t)<5))score+=4;if(score>s.cost*.45+2&&score>bestScore){best={s,p};bestScore=score;}}
      }if(best){this.cast(best.s.id,best.p);return true;}return false;};
    let targets=enemies.filter(t=>this.canAttack(u,t));const kill=targets.find(t=>t.master&&this.damage(u,t,u.magicAttackBasic).amount>=t.hp);if(kill){this.attack(kill.id);return;}
    if(u.hp<=4&&tryMagic())return;
    const capturable=this.stones.filter(s=>s.owner!==u.team&&!this.at(s)).sort((a,b)=>distance(u,a)-distance(u,b));let goal=capturable[0];const nearest=enemies.sort((a,b)=>distance(u,a)-distance(u,b))[0];if(!goal||!u.master&&nearest&&distance(u,nearest)<u.move+u.range)goal=nearest||this.living.find(t=>t.master&&t.team!==u.team);
    if(!this.moved&&goal){const reach=this.reachable(u),blocked=this.blocked(u);blocked.delete(key(goal));const path=findPath(u,goal,this.tiles,this.terrainCost(u),blocked);let best=null,bestScore=-Infinity;
      for(const [k,cost] of reach.dist){if(k===key(u))continue;const p=this.tiles.get(k),proxy={...u,q:p.q,r:p.r};let score=-distance(p,goal)*2-cost*.15;const routeIndex=path.findIndex(t=>key(t)===k);if(routeIndex>0)score+=routeIndex*.6;
        if(this.stones.some(s=>s.owner!==u.team&&key(s)===k))score+=26;
        for(const t of enemies)if(this.canAttack(proxy,t))score=Math.max(score,10+this.damage(proxy,t,u.magicAttackBasic).amount+(t.master?12:0));
        if(u.master&&u.hp<=4&&this.difficulty!=='easy')score-=enemies.filter(t=>distance(t,p)<=t.range+2).length*12;
        if(['lava','swamp'].includes(p.terrain)&&u.element!=='fire'&&!u.flying)score-=10;
        if(score>bestScore){bestScore=score;best=p;}
      }if(best&&(!targets.length||bestScore>20))this.move(best);
    }
    if(tryMagic())return;targets=enemies.filter(t=>this.canAttack(u,t)).sort((a,b)=>Number(b.master)-Number(a.master)||a.hp-b.hp);if(targets.length){this.attack(targets[0].id);return;}
    if(u.master){const nearestSpirit=enemies.find(t=>!t.master)||nearest,desired=Object.keys(ELEMENTS).find(e=>ELEMENTS[e].beats===nearestSpirit?.element);const options=SUMMONS.filter(s=>this.canSummon(s.id,u)&&s.upkeep<=Math.max(1,this.income(u.team)-this.upkeep(u.team))).sort((a,b)=>(b.element===desired?8:0)+b.cost/12-((a.element===desired?8:0)+a.cost/12));
      let count=0;const cheapest=Math.min(...options.map(s=>s.cost));for(const type of options){if(u.type==='gid-kahn'&&count===0&&this.mana[u.team]>=cheapest*2&&type.cost+cheapest>this.mana[u.team])continue;const places=this.summonTiles(u,type.id).sort((a,b)=>{const value=p=>(this.stones.some(s=>s.owner!==u.team&&key(s)===key(p))?-100:0)+distance(p,goal||u);return value(a)-value(b);});if(places.length&&this.canSummon(type.id,u)){this.summon(type.id,places[0],false);if(++count>=(u.type==='gid-kahn'?2:1))break;}}
      if(count){this.finish('summon');return;}
    }this.wait();
  }
  serialize(){return {version:4,stage:this.stage,tide:this.tide,units:this.units,stones:this.stones,mana:this.mana,time:this.time,turn:this.turn,round:this.round,nextId:this.nextId,activeId:this.activeId,winner:this.winner,log:this.log,moved:this.moved,moveCost:this.moveCost,moveUndo:this.moveUndo??null,difficulty:this.difficulty,custom:this.custom,traps:this.traps,unlocked:this.unlocked,extraSpells:this.extraSpells};}
  static restore(data){
    const validStatuses=value=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length<=32&&Object.entries(value).every(([id,s])=>Object.hasOwn(STATUS_NAMES,id)&&s&&typeof s==='object'&&!Array.isArray(s)&&(s.expiresAt!==undefined?Number.isFinite(s.expiresAt)&&s.expiresAt>=0:Number.isInteger(s.remaining)&&s.remaining>=0)&&(s.appliedTurn===undefined||Number.isInteger(s.appliedTurn)&&s.appliedTurn>=0));
    if(data?.version!==4||!Array.isArray(data.units)||data.units.length>2000||!Array.isArray(data.mana)||data.mana.length!==2||data.mana.some(m=>!Number.isFinite(m)||m<0||m>LIMITS.maxMana))throw new Error('이전 규칙의 전투 저장은 새 전투로 시작해야 합니다.');
    validateStage(data.stage);const tiles=new Map(data.stage.tiles.map(t=>[key(t),t])),ids=new Set(),positions=new Set();
    for(const u of data.units){const base=(u.master||u.isDecoy?[...MASTERS,...BOSSES]:SUMMONS).find(d=>d.id===u.type);if(!base||!Number.isInteger(u.id)||ids.has(u.id)||![0,1].includes(u.team)||!tiles.has(key(u))||!Number.isFinite(u.hp)||u.hp<0||u.hp>u.maxHp||!Number.isFinite(u.nextTime)||!Number.isFinite(u.speed)||u.speed<=0||!validStatuses(u.statuses))throw new Error('유닛 저장 데이터 오류');ids.add(u.id);if(u.hp>0){if(positions.has(key(u)))throw new Error('유닛 위치 중복');positions.add(key(u));}}
    if(!Number.isFinite(data.time)||!Number.isInteger(data.turn)||!Number.isInteger(data.nextId)||data.nextId<=Math.max(...ids)||![null,0,1].includes(data.winner)||data.winner===null&&!data.units.some(u=>u.id===data.activeId&&u.hp>0)||!Array.isArray(data.stones)||data.stones.length!==data.stage.manaStones.length||data.stones.some((s,i)=>key(s)!==key(data.stage.manaStones[i])||![null,0,1].includes(s.owner))||!Array.isArray(data.round)||!Array.isArray(data.traps)||!Array.isArray(data.unlocked)||!Array.isArray(data.extraSpells))throw new Error('전장 저장 데이터 오류');
    const b=Object.create(Battle.prototype);Object.assign(b,structuredClone(data));b.tiles=new Map(b.stage.tiles.map(t=>[key(t),t]));b.events=[];b.moveUndo??=null;if(b.moveUndo&&(!b.canUndoMove()||!tiles.has(key(b.moveUndo.unit))||b.living.some(u=>u.id!==b.activeId&&key(u)===key(b.moveUndo.unit))||!Array.isArray(b.moveUndo.traps)||!Array.isArray(b.moveUndo.log)||!validStatuses(b.moveUndo.unit.statuses)))throw new Error("이동 취소 저장 데이터 오류");b.log=Array.isArray(b.log)?b.log.slice(0,70):[];b.queue=new MinHeap();for(const u of b.living)if(u.id!==b.activeId)b.queue.push({id:u.id,time:u.nextTime});return b;
  }
}
