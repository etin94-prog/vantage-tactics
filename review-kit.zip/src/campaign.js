import { playerLevel } from './rules.js';
// Original clear rewards per campaign stage (stage = playlist episode), read from each episode's reward screen.
// Source table with quotes and timestamps: data/lab/original-rewards.json · docs/CAMPAIGN_STAGE_LESSONS.md
//  1 마암 — confirmed · irDM3getf_0 18:32
//  2 아·페리온 — confirmed · BclY6xM4hiA 11:09
//  3 다룬다라 — confirmed · 2vEfTlThXUk 8:21
//  4 블레스 — confirmed · H01_DpLQrM0 9:53
//  5 펠리트 — confirmed · Shj3KznBzmc 16:15
//  6 자밀펜 — confirmed · mpZtIqca9kk 12:27
//  7 다·알마 — confirmed · EQ2XdnvK-zY 16:36
//  8 메딕 — confirmed · taflCrI2AqA 17:15
//  9 브릭스 — confirmed · UgcXHpRj6AE 18:47
// 10 기아·브로 — confirmed · NxbIQpH9jv4 21:39
// 11 큐리어·벨 — confirmed · Fq5AtrLiW8o 14:18
// 12 업타이드 — confirmed · cRtodWB1zGU 23:59
// 13 다운타이드 — confirmed · Hyv4c-uevps 32:52
// 14 아모르타미스 — confirmed · rW3ni0cf9O0 32:30
// 15 타브스 — confirmed · HEv2NhdHm6E 31:25
// 16 오네비에르 — confirmed · _NXdzn6hpCM 20:08
// 17 피프넬 — confirmed · orZbGbnzAFM 34:37
// 18 넵튜노 — confirmed · fKfAR3YrSbE 20:53
// 19 다·콤 — confirmed · uV67epym6gk 45:46
// 20 그리온 — confirmed · ED5zbme3PWs 55:32
// 21 배니시 — confirmed · SX_NAZbA6M8 77:18
// 22 바·마도 — confirmed · DqPXkjMcjD8 30:27
// 23 콘쥬레이트 — confirmed · Z7-EEEsJtig 21:21
// 24 레그너·크록스 — confirmed · IWbK3Cx-KSE 84:16
// 25 텐타크 — confirmed · mFaL7LeVkNM 42:36
// 26 제노스브리드 — confirmed · LixCfwUWRNk 44:11
// 27 보상 없음 — none-inferred · voucSv2CXns 57:26
// 28 보상 없음 — none · ANcikeR03MY 29:58
// 29 보상 없음 — none · KVMOMyhrKxw 48:30
// 30 보상 없음 — none · ySJcXV8Vm1k 59:17
export const STARTER_SUMMONS=['fa-rancell','reque','hepitus','guene-foss'];
export const ORIGINAL_REWARDS={1:{summons:['marme'],spells:[]},2:{summons:['ae-ferrion'],spells:[]},3:{summons:['dullmdaler'],spells:[]},4:{summons:[],spells:['v2-13']},5:{summons:['pelitt'],spells:[]},6:{summons:['zamilpen'],spells:[]},7:{summons:['d-alma'],spells:[]},8:{summons:[],spells:['v2-14']},9:{summons:['blexe'],spells:[]},10:{summons:['gia-bro'],spells:[]},11:{summons:['currier-bell'],spells:[]},12:{summons:[],spells:['v2-10']},13:{summons:[],spells:['v2-11']},14:{summons:['amoltamiss'],spells:[]},15:{summons:['tarbss'],spells:[]},16:{summons:['oonevievle'],spells:[]},17:{summons:['fifenall'],spells:[]},18:{summons:['neptjunoue'],spells:[]},19:{summons:['da-colm'],spells:[]},20:{summons:['greon'],spells:[]},21:{summons:[],spells:['v2-12']},22:{summons:['ba-mado'],spells:[]},23:{summons:[],spells:['v2-15']},24:{summons:['regna-croxe'],spells:[]},25:{summons:['tentarch'],spells:[]},26:{summons:['zenosblead'],spells:[]},27:{summons:[],spells:[]},28:{summons:[],spells:[]},29:{summons:[],spells:[]},30:{summons:[],spells:[]}};
export function campaignInventory(cleared=[]){
  const summons=new Set(STARTER_SUMMONS),spells=new Set();
  for(const id of cleared){if(!Number.isInteger(id)||id<1||id>30)continue;const reward=ORIGINAL_REWARDS[id];reward.summons.forEach(s=>summons.add(s));reward.spells.forEach(s=>spells.add(s));}
  return {unlocked:[...summons],extraSpells:[...spells]};
}
// Campaign stage whose victory unlocks this summon (0 = available from the start, null = never).
export function summonUnlockStage(id){if(STARTER_SUMMONS.includes(id))return 0;for(let n=1;n<=30;n++)if(ORIGINAL_REWARDS[n].summons.includes(id))return n;return null;}
export function spellUnlockStage(id){for(let n=1;n<=30;n++)if(ORIGINAL_REWARDS[n].spells.includes(id))return n;return null;}
export function recordVictory(progress,stage){
  if(stage.custom||progress.cleared.includes(stage.id))return {...progress,cleared:[...progress.cleared]};
  const cleared=[...progress.cleared,stage.id];return {...progress,cleared,exp:cleared.length*100,unlocked:Math.max(progress.unlocked,Math.min(30,stage.id+1)),level:playerLevel(cleared.length*100)};
}
