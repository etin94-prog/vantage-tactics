import { V2_MAPS, V2_PLAYLIST_ORDER } from './v2-reference.js';
import { v2SpellId } from './spells.js';
import { playerLevel } from './rules.js';
export function campaignInventory(cleared=[]){
  const summons=new Set(['fa-rancell','reque','hepitus','guene-foss']),spells=new Set();
  // Web progression uses the next battle's enemy repertoire as a documented proxy.
  for(const id of cleared){if(!Number.isInteger(id)||id<1||id>30)continue;const source=V2_MAPS[V2_PLAYLIST_ORDER[Math.min(29,id)]];source.enemyRoster.forEach(s=>summons.add(s));source.enemySpells.forEach(s=>spells.add(v2SpellId(s)));}
  return {unlocked:[...summons],extraSpells:[...spells]};
}
export function recordVictory(progress,stage){
  if(stage.custom||progress.cleared.includes(stage.id))return {...progress,cleared:[...progress.cleared]};
  const cleared=[...progress.cleared,stage.id];return {...progress,cleared,exp:cleared.length*100,unlocked:Math.max(progress.unlocked,Math.min(30,stage.id+1)),level:playerLevel(cleared.length*100)};
}
