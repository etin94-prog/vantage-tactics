import { key, distance } from './hex.js';
import { SPELLS } from './spells.js';

/** Pure display model. Every colored cell uses the battle's actual legality functions. */
export function targetArea(b,u,{mode='move',spellId=null,view='current',origin=null,target=null}={}){
  const out={movement:new Set(),range:new Set(),targets:new Set(),effect:new Set(),victims:[],origin:null};
  if(!u||u.hp<=0)return out;
  const canMove=u.id!==b.activeId||!b.moved,reach=canMove?b.reachable(u).dist:new Map([[key(u),0]]);
  if(mode==='move'||view!=='current')out.movement=new Set(reach.keys());
  let actor=u;
  if(origin&&reach.has(key(origin))&&!b.at(origin)){actor={...u,q:origin.q,r:origin.r};out.origin=key(origin);}
  const magic=mode==='spell'||mode==='heal'||view==='move-magic',s=magic?SPELLS[spellId]:null;
  const starts=view==='current'?[actor]:[...reach.keys()].map(k=>({...u,...b.tiles.get(k)}));
  for(const start of starts){
    if(magic&&!s)continue;
    for(const t of b.stage.tiles){if(t.terrain==='void'||!b.visible(t,0))continue;
      let inside;
      if(s)inside=s.selfArea||s.allAllies||s.range===0?key(start)===key(t):s.sourceIndex!==undefined?b.actionInRange(start,t,s):distance(start,t)<=s.range&&(s.ignoreSight||b.hasSight(start,t));
      else inside=!u.healerOnly&&key(start)!==key(t)&&b.actionInRange(start,t,{...u.attackProfile,range:u.range});
      if(inside)out.range.add(key(t));
    }
    const legal=s?b.spellTargets(start,s.id):b.living.filter(t=>b.canAttack(start,t));
    for(const t of legal)if(b.visible(t,0))out.targets.add(key(t));
  }
  if(target&&s&&view==='current'&&out.targets.has(key(target))){
    out.effect=new Set(b.effectTiles(actor,s,target).filter(t=>b.visible(t,0)).map(key));
    out.victims=b.affected(actor,s,target).filter(t=>b.visibleUnit(t,0)).map(t=>({id:t.id,name:t.name,friendly:t.team===u.team,amount:s.kind==='damage'?b.damage(actor,t,!s.physical,s,target).amount:s.kind==='heal'?Math.min(b.healing(actor,s),t.maxHp-t.hp):null}));
  }
  return out;
}
